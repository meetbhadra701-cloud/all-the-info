module top( x0 , x1 , x2 , x3 , x4 , y0 , y1 );
  input x0 , x1 , x2 , x3 , x4 ;
  output y0 , y1 ;
  wire n7 ;
  NAND2x1_ASAP7_75t_R  g0( .A (x1), .B (x3), .Y (n7) );
  AO22x1_ASAP7_75t_R   g1( .A1 (n7), .A2 (x2), .B1 (x1), .B2 (x0), .Y (y0) );
  OA21x2_ASAP7_75t_R   g2( .A1 (x2), .A2 (x4), .B (n7), .Y (y1) );
endmodule
