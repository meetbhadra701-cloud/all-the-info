// Benchmark "/w/experiments/inputs/c1/c2/c17" written by ABC on Fri Sep 25 10:26:17 2026

module \/w/experiments/inputs/c1/c2/c17  ( 
    pi0, pi1, pi2, pi3, pi4,
    po0, po1  );
  input  pi0, pi1, pi2, pi3, pi4;
  output po0, po1;
  wire new_n8, new_n9;
  AND2x2_ASAP7_75t_R   g0(.A(pi0), .B(pi1), .Y(new_n8));
  NAND2x1_ASAP7_75t_R  g1(.A(pi1), .B(pi3), .Y(new_n9));
  AO21x1_ASAP7_75t_R   g2(.A1(new_n9), .A2(pi2), .B(new_n8), .Y(po0));
  OA21x2_ASAP7_75t_R   g3(.A1(pi2), .A2(pi4), .B(new_n9), .Y(po1));
endmodule


