module top( x0 , x1 , x2 , x3 , x4 , y0 , y1 );
  input x0 , x1 , x2 , x3 , x4 ;
  output y0 , y1 ;
  wire n7 , n8 , n9 ;
  INVx1_ASAP7_75t_R    g0( .A (x2), .Y (n7) );
  AOI21x1_ASAP7_75t_R  g1( .A1 (x1), .A2 (x3), .B (n7), .Y (n9) );
  AO21x1_ASAP7_75t_R   g2( .A1 (x0), .A2 (x1), .B (n9), .Y (y0) );
  NAND2x1_ASAP7_75t_R  g3( .A (x1), .B (x3), .Y (n8) );
  AO21x1_ASAP7_75t_R   g4( .A1 (n8), .A2 (x4), .B (n9), .Y (y1) );
endmodule
