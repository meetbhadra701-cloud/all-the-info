// Benchmark "/w/experiments/inputs/c1/c2/c1355" written by ABC on Fri Sep 25 10:26:46 2026

module \/w/experiments/inputs/c1/c2/c1355  ( 
    pi00, pi01, pi02, pi03, pi04, pi05, pi06, pi07, pi08, pi09, pi10, pi11,
    pi12, pi13, pi14, pi15, pi16, pi17, pi18, pi19, pi20, pi21, pi22, pi23,
    pi24, pi25, pi26, pi27, pi28, pi29, pi30, pi31, pi32, pi33, pi34, pi35,
    pi36, pi37, pi38, pi39, pi40,
    po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10, po11,
    po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22, po23,
    po24, po25, po26, po27, po28, po29, po30, po31  );
  input  pi00, pi01, pi02, pi03, pi04, pi05, pi06, pi07, pi08, pi09,
    pi10, pi11, pi12, pi13, pi14, pi15, pi16, pi17, pi18, pi19, pi20, pi21,
    pi22, pi23, pi24, pi25, pi26, pi27, pi28, pi29, pi30, pi31, pi32, pi33,
    pi34, pi35, pi36, pi37, pi38, pi39, pi40;
  output po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10,
    po11, po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22,
    po23, po24, po25, po26, po27, po28, po29, po30, po31;
  wire new_n74, new_n75, new_n76, new_n77, new_n78, new_n79, new_n80,
    new_n81, new_n82, new_n83, new_n84, new_n85, new_n86, new_n87, new_n88,
    new_n89, new_n90, new_n91, new_n92, new_n93, new_n94, new_n95, new_n96,
    new_n97, new_n98, new_n99, new_n100, new_n101, new_n102, new_n103,
    new_n104, new_n105, new_n106, new_n107, new_n108, new_n109, new_n110,
    new_n111, new_n112, new_n113, new_n114, new_n115, new_n116, new_n117,
    new_n118, new_n119, new_n120, new_n121, new_n122, new_n123, new_n124,
    new_n125, new_n126, new_n127, new_n128, new_n129, new_n130, new_n131,
    new_n132, new_n133, new_n134, new_n135, new_n136, new_n137, new_n138,
    new_n139, new_n140, new_n141, new_n142, new_n143, new_n144, new_n145,
    new_n146, new_n147, new_n148, new_n149, new_n150, new_n151, new_n152,
    new_n153, new_n154, new_n155, new_n156, new_n157, new_n158, new_n159,
    new_n160, new_n161, new_n162, new_n163, new_n164, new_n165, new_n166,
    new_n167, new_n168, new_n169, new_n170, new_n171, new_n172, new_n173,
    new_n174, new_n175, new_n176, new_n177, new_n178, new_n179, new_n180,
    new_n181, new_n182, new_n183, new_n184, new_n185, new_n186, new_n187,
    new_n188, new_n189, new_n190, new_n191, new_n192, new_n193, new_n194,
    new_n195, new_n196, new_n197, new_n198, new_n199, new_n200, new_n201,
    new_n202, new_n203, new_n204, new_n205, new_n206, new_n207, new_n208,
    new_n209, new_n210, new_n211, new_n212, new_n213, new_n214, new_n215,
    new_n216, new_n217, new_n218, new_n219, new_n220, new_n221, new_n222,
    new_n223, new_n224, new_n225, new_n226, new_n227, new_n228, new_n229,
    new_n230, new_n231, new_n232, new_n233, new_n234, new_n235, new_n236,
    new_n237, new_n238, new_n239, new_n240, new_n241, new_n242, new_n243,
    new_n244, new_n245, new_n246, new_n247, new_n248, new_n249, new_n250,
    new_n251, new_n252, new_n253, new_n254, new_n255, new_n256, new_n257,
    new_n258, new_n259, new_n260, new_n261, new_n262, new_n263, new_n264,
    new_n265, new_n266, new_n267, new_n268, new_n269, new_n270, new_n271,
    new_n272, new_n273, new_n274, new_n275, new_n276, new_n277, new_n278,
    new_n279, new_n280, new_n281, new_n282, new_n283, new_n284, new_n285,
    new_n286, new_n287, new_n288, new_n289, new_n290, new_n291, new_n292,
    new_n293, new_n294, new_n295, new_n296, new_n297, new_n298, new_n299,
    new_n301, new_n302, new_n303, new_n304, new_n305, new_n306, new_n307,
    new_n308, new_n309, new_n310, new_n311, new_n312, new_n313, new_n314,
    new_n315, new_n316, new_n317, new_n319, new_n320, new_n322, new_n323,
    new_n325, new_n326, new_n328, new_n329, new_n330, new_n331, new_n333,
    new_n335, new_n336, new_n338, new_n339, new_n340, new_n341, new_n342,
    new_n343, new_n345, new_n346, new_n348, new_n349, new_n350, new_n351,
    new_n353, new_n354, new_n356, new_n357, new_n359, new_n360, new_n362,
    new_n363, new_n364, new_n366, new_n368, new_n369, new_n371, new_n372,
    new_n374, new_n376, new_n378, new_n379, new_n381, new_n382, new_n384,
    new_n385, new_n387, new_n388, new_n390, new_n391, new_n392, new_n393,
    new_n395, new_n397, new_n398, new_n400, new_n401, new_n403, new_n404,
    new_n405, new_n406, new_n407, new_n409, new_n410, new_n412, new_n413,
    new_n415, new_n416;
  INVx1_ASAP7_75t_R    g000(.A(pi00), .Y(new_n74));
  INVx1_ASAP7_75t_R    g001(.A(pi02), .Y(new_n75));
  INVx1_ASAP7_75t_R    g002(.A(pi08), .Y(new_n76));
  INVx1_ASAP7_75t_R    g003(.A(pi09), .Y(new_n77));
  INVx1_ASAP7_75t_R    g004(.A(pi10), .Y(new_n78));
  INVx1_ASAP7_75t_R    g005(.A(pi11), .Y(new_n79));
  INVx1_ASAP7_75t_R    g006(.A(pi12), .Y(new_n80));
  INVx1_ASAP7_75t_R    g007(.A(pi13), .Y(new_n81));
  INVx1_ASAP7_75t_R    g008(.A(pi14), .Y(new_n82));
  INVx1_ASAP7_75t_R    g009(.A(pi15), .Y(new_n83));
  INVx1_ASAP7_75t_R    g010(.A(pi16), .Y(new_n84));
  INVx1_ASAP7_75t_R    g011(.A(pi17), .Y(new_n85));
  INVx1_ASAP7_75t_R    g012(.A(pi19), .Y(new_n86));
  INVx1_ASAP7_75t_R    g013(.A(pi20), .Y(new_n87));
  INVx1_ASAP7_75t_R    g014(.A(pi21), .Y(new_n88));
  INVx1_ASAP7_75t_R    g015(.A(pi22), .Y(new_n89));
  INVx1_ASAP7_75t_R    g016(.A(pi23), .Y(new_n90));
  INVx1_ASAP7_75t_R    g017(.A(pi24), .Y(new_n91));
  INVx1_ASAP7_75t_R    g018(.A(pi25), .Y(new_n92));
  INVx1_ASAP7_75t_R    g019(.A(pi26), .Y(new_n93));
  INVx1_ASAP7_75t_R    g020(.A(pi30), .Y(new_n94));
  INVx1_ASAP7_75t_R    g021(.A(pi31), .Y(new_n95));
  INVx1_ASAP7_75t_R    g022(.A(pi32), .Y(new_n96));
  INVx1_ASAP7_75t_R    g023(.A(pi34), .Y(new_n97));
  AND2x2_ASAP7_75t_R   g024(.A(pi04), .B(pi05), .Y(new_n98));
  XOR2x2_ASAP7_75t_R   g025(.A(pi00), .B(pi01), .Y(new_n99));
  XOR2x2_ASAP7_75t_R   g026(.A(new_n98), .B(new_n99), .Y(new_n100));
  XOR2x2_ASAP7_75t_R   g027(.A(pi02), .B(pi03), .Y(new_n101));
  XOR2x2_ASAP7_75t_R   g028(.A(pi12), .B(pi13), .Y(new_n102));
  NAND2x1_ASAP7_75t_R  g029(.A(pi10), .B(new_n79), .Y(new_n103));
  NAND2x1_ASAP7_75t_R  g030(.A(pi11), .B(new_n78), .Y(new_n104));
  XNOR2x2_ASAP7_75t_R  g031(.A(pi10), .B(pi11), .Y(new_n105));
  NAND2x1_ASAP7_75t_R  g032(.A(new_n102), .B(new_n105), .Y(new_n106));
  AO21x1_ASAP7_75t_R   g033(.A1(new_n103), .A2(new_n104), .B(new_n102), .Y(new_n107));
  AND3x1_ASAP7_75t_R   g034(.A(new_n106), .B(new_n107), .C(new_n101), .Y(new_n108));
  AOI21x1_ASAP7_75t_R  g035(.A1(new_n106), .A2(new_n107), .B(new_n101), .Y(new_n109));
  NAND2x1_ASAP7_75t_R  g036(.A(new_n76), .B(new_n77), .Y(new_n110));
  NAND2x1_ASAP7_75t_R  g037(.A(pi08), .B(pi09), .Y(new_n111));
  XOR2x2_ASAP7_75t_R   g038(.A(pi08), .B(pi09), .Y(new_n112));
  XNOR2x2_ASAP7_75t_R  g039(.A(pi06), .B(pi07), .Y(new_n113));
  NAND2x1_ASAP7_75t_R  g040(.A(new_n112), .B(new_n113), .Y(new_n114));
  AO21x1_ASAP7_75t_R   g041(.A1(new_n110), .A2(new_n111), .B(new_n113), .Y(new_n115));
  AND2x2_ASAP7_75t_R   g042(.A(new_n114), .B(new_n115), .Y(new_n116));
  AOI211x1_ASAP7_75t_R g043(.A1(new_n114), .A2(new_n115), .B(new_n108), .C(new_n109), .Y(new_n117));
  OA21x2_ASAP7_75t_R   g044(.A1(new_n108), .A2(new_n109), .B(new_n116), .Y(new_n118));
  OR3x1_ASAP7_75t_R    g045(.A(new_n117), .B(new_n118), .C(new_n100), .Y(new_n119));
  OAI21x1_ASAP7_75t_R  g046(.A1(new_n117), .A2(new_n118), .B(new_n100), .Y(new_n120));
  AND2x2_ASAP7_75t_R   g047(.A(new_n119), .B(new_n120), .Y(new_n121));
  NAND2x1_ASAP7_75t_R  g048(.A(new_n119), .B(new_n120), .Y(new_n122));
  NAND2x1_ASAP7_75t_R  g049(.A(new_n84), .B(new_n85), .Y(new_n123));
  NAND2x1_ASAP7_75t_R  g050(.A(pi16), .B(pi17), .Y(new_n124));
  AND2x2_ASAP7_75t_R   g051(.A(new_n123), .B(new_n124), .Y(new_n125));
  AND4x2_ASAP7_75t_R   g052(.A(new_n106), .B(new_n107), .C(pi05), .D(pi18), .Y(new_n126));
  AOI22x1_ASAP7_75t_R  g053(.A1(pi05), .A2(pi18), .B1(new_n106), .B2(new_n107), .Y(new_n127));
  OA21x2_ASAP7_75t_R   g054(.A1(new_n126), .A2(new_n127), .B(new_n125), .Y(new_n128));
  OAI21x1_ASAP7_75t_R  g055(.A1(new_n126), .A2(new_n127), .B(new_n125), .Y(new_n129));
  AOI211x1_ASAP7_75t_R g056(.A1(new_n123), .A2(new_n124), .B(new_n126), .C(new_n127), .Y(new_n130));
  AO211x2_ASAP7_75t_R  g057(.A1(new_n123), .A2(new_n124), .B(new_n126), .C(new_n127), .Y(new_n131));
  XNOR2x2_ASAP7_75t_R  g058(.A(pi21), .B(pi22), .Y(new_n132));
  XOR2x2_ASAP7_75t_R   g059(.A(pi19), .B(pi20), .Y(new_n133));
  OR2x4_ASAP7_75t_R    g060(.A(new_n132), .B(new_n133), .Y(new_n134));
  NAND2x1_ASAP7_75t_R  g061(.A(new_n132), .B(new_n133), .Y(new_n135));
  XOR2x2_ASAP7_75t_R   g062(.A(new_n132), .B(new_n133), .Y(new_n136));
  XOR2x2_ASAP7_75t_R   g063(.A(pi14), .B(pi15), .Y(new_n137));
  XOR2x2_ASAP7_75t_R   g064(.A(new_n136), .B(new_n137), .Y(new_n138));
  XNOR2x2_ASAP7_75t_R  g065(.A(new_n136), .B(new_n137), .Y(new_n139));
  AND3x1_ASAP7_75t_R   g066(.A(new_n129), .B(new_n131), .C(new_n138), .Y(new_n140));
  OR3x1_ASAP7_75t_R    g067(.A(new_n128), .B(new_n130), .C(new_n139), .Y(new_n141));
  OA21x2_ASAP7_75t_R   g068(.A1(new_n128), .A2(new_n130), .B(new_n139), .Y(new_n142));
  AO21x1_ASAP7_75t_R   g069(.A1(new_n129), .A2(new_n131), .B(new_n138), .Y(new_n143));
  NOR2x1_ASAP7_75t_R   g070(.A(new_n140), .B(new_n142), .Y(new_n144));
  NAND2x1_ASAP7_75t_R  g071(.A(new_n141), .B(new_n143), .Y(new_n145));
  NAND2x1_ASAP7_75t_R  g072(.A(new_n92), .B(new_n93), .Y(new_n146));
  NAND2x1_ASAP7_75t_R  g073(.A(pi25), .B(pi26), .Y(new_n147));
  AND2x2_ASAP7_75t_R   g074(.A(new_n146), .B(new_n147), .Y(new_n148));
  AND2x2_ASAP7_75t_R   g075(.A(pi05), .B(pi27), .Y(new_n149));
  AND3x1_ASAP7_75t_R   g076(.A(new_n114), .B(new_n115), .C(new_n149), .Y(new_n150));
  AOI21x1_ASAP7_75t_R  g077(.A1(new_n114), .A2(new_n115), .B(new_n149), .Y(new_n151));
  OA21x2_ASAP7_75t_R   g078(.A1(new_n150), .A2(new_n151), .B(new_n148), .Y(new_n152));
  OAI21x1_ASAP7_75t_R  g079(.A1(new_n150), .A2(new_n151), .B(new_n148), .Y(new_n153));
  AOI211x1_ASAP7_75t_R g080(.A1(new_n146), .A2(new_n147), .B(new_n150), .C(new_n151), .Y(new_n154));
  AO211x2_ASAP7_75t_R  g081(.A1(new_n146), .A2(new_n147), .B(new_n150), .C(new_n151), .Y(new_n155));
  XNOR2x2_ASAP7_75t_R  g082(.A(pi30), .B(pi31), .Y(new_n156));
  XOR2x2_ASAP7_75t_R   g083(.A(pi28), .B(pi29), .Y(new_n157));
  OR2x4_ASAP7_75t_R    g084(.A(new_n156), .B(new_n157), .Y(new_n158));
  NAND2x1_ASAP7_75t_R  g085(.A(new_n156), .B(new_n157), .Y(new_n159));
  XOR2x2_ASAP7_75t_R   g086(.A(new_n156), .B(new_n157), .Y(new_n160));
  XNOR2x2_ASAP7_75t_R  g087(.A(pi23), .B(pi24), .Y(new_n161));
  XNOR2x2_ASAP7_75t_R  g088(.A(new_n160), .B(new_n161), .Y(new_n162));
  XOR2x2_ASAP7_75t_R   g089(.A(new_n160), .B(new_n161), .Y(new_n163));
  AND3x1_ASAP7_75t_R   g090(.A(new_n162), .B(new_n155), .C(new_n153), .Y(new_n164));
  OR3x1_ASAP7_75t_R    g091(.A(new_n163), .B(new_n154), .C(new_n152), .Y(new_n165));
  OA21x2_ASAP7_75t_R   g092(.A1(new_n152), .A2(new_n154), .B(new_n163), .Y(new_n166));
  AO21x1_ASAP7_75t_R   g093(.A1(new_n153), .A2(new_n155), .B(new_n162), .Y(new_n167));
  NOR2x1_ASAP7_75t_R   g094(.A(new_n164), .B(new_n166), .Y(new_n168));
  NAND2x1_ASAP7_75t_R  g095(.A(new_n165), .B(new_n167), .Y(new_n169));
  AND4x2_ASAP7_75t_R   g096(.A(new_n141), .B(new_n143), .C(new_n165), .D(new_n167), .Y(new_n170));
  OR4x2_ASAP7_75t_R    g097(.A(new_n140), .B(new_n142), .C(new_n164), .D(new_n166), .Y(new_n171));
  XNOR2x2_ASAP7_75t_R  g098(.A(pi32), .B(pi33), .Y(new_n172));
  AND3x1_ASAP7_75t_R   g099(.A(new_n172), .B(pi36), .C(pi05), .Y(new_n173));
  AOI21x1_ASAP7_75t_R  g100(.A1(pi05), .A2(pi36), .B(new_n172), .Y(new_n174));
  NOR2x1_ASAP7_75t_R   g101(.A(new_n173), .B(new_n174), .Y(new_n175));
  OR2x4_ASAP7_75t_R    g102(.A(new_n173), .B(new_n174), .Y(new_n176));
  XOR2x2_ASAP7_75t_R   g103(.A(pi34), .B(pi35), .Y(new_n177));
  AND3x1_ASAP7_75t_R   g104(.A(new_n158), .B(new_n159), .C(new_n177), .Y(new_n178));
  AOI21x1_ASAP7_75t_R  g105(.A1(new_n158), .A2(new_n159), .B(new_n177), .Y(new_n179));
  OA21x2_ASAP7_75t_R   g106(.A1(new_n178), .A2(new_n179), .B(new_n136), .Y(new_n180));
  OAI21x1_ASAP7_75t_R  g107(.A1(new_n178), .A2(new_n179), .B(new_n136), .Y(new_n181));
  AOI211x1_ASAP7_75t_R g108(.A1(new_n134), .A2(new_n135), .B(new_n178), .C(new_n179), .Y(new_n182));
  AO211x2_ASAP7_75t_R  g109(.A1(new_n134), .A2(new_n135), .B(new_n178), .C(new_n179), .Y(new_n183));
  AND3x1_ASAP7_75t_R   g110(.A(new_n183), .B(new_n175), .C(new_n181), .Y(new_n184));
  OR3x1_ASAP7_75t_R    g111(.A(new_n182), .B(new_n176), .C(new_n180), .Y(new_n185));
  OA21x2_ASAP7_75t_R   g112(.A1(new_n180), .A2(new_n182), .B(new_n176), .Y(new_n186));
  AO21x1_ASAP7_75t_R   g113(.A1(new_n181), .A2(new_n183), .B(new_n175), .Y(new_n187));
  NOR2x1_ASAP7_75t_R   g114(.A(new_n184), .B(new_n186), .Y(new_n188));
  NAND2x1_ASAP7_75t_R  g115(.A(new_n185), .B(new_n187), .Y(new_n189));
  OA211x2_ASAP7_75t_R  g116(.A1(new_n184), .A2(new_n186), .B(new_n119), .C(new_n120), .Y(new_n190));
  AOI211x1_ASAP7_75t_R g117(.A1(new_n119), .A2(new_n120), .B(new_n184), .C(new_n186), .Y(new_n191));
  OA21x2_ASAP7_75t_R   g118(.A1(new_n190), .A2(new_n191), .B(new_n170), .Y(new_n192));
  OAI21x1_ASAP7_75t_R  g119(.A1(new_n190), .A2(new_n191), .B(new_n170), .Y(new_n193));
  OA21x2_ASAP7_75t_R   g120(.A1(new_n140), .A2(new_n142), .B(new_n169), .Y(new_n194));
  AO22x1_ASAP7_75t_R   g121(.A1(new_n141), .A2(new_n143), .B1(new_n165), .B2(new_n167), .Y(new_n195));
  AOI22x1_ASAP7_75t_R  g122(.A1(new_n119), .A2(new_n120), .B1(new_n185), .B2(new_n187), .Y(new_n196));
  AO22x1_ASAP7_75t_R   g123(.A1(new_n119), .A2(new_n120), .B1(new_n185), .B2(new_n187), .Y(new_n197));
  AO21x1_ASAP7_75t_R   g124(.A1(new_n144), .A2(new_n168), .B(new_n197), .Y(new_n198));
  AND3x1_ASAP7_75t_R   g125(.A(new_n171), .B(new_n195), .C(new_n196), .Y(new_n199));
  OA21x2_ASAP7_75t_R   g126(.A1(new_n198), .A2(new_n194), .B(new_n193), .Y(new_n200));
  NAND2x1_ASAP7_75t_R  g127(.A(new_n89), .B(new_n95), .Y(new_n201));
  NAND2x1_ASAP7_75t_R  g128(.A(pi22), .B(pi31), .Y(new_n202));
  AND2x2_ASAP7_75t_R   g129(.A(new_n201), .B(new_n202), .Y(new_n203));
  AND2x2_ASAP7_75t_R   g130(.A(pi05), .B(pi37), .Y(new_n204));
  OR2x4_ASAP7_75t_R    g131(.A(pi15), .B(pi24), .Y(new_n205));
  NAND2x1_ASAP7_75t_R  g132(.A(pi15), .B(pi24), .Y(new_n206));
  XOR2x2_ASAP7_75t_R   g133(.A(pi15), .B(pi24), .Y(new_n207));
  XNOR2x2_ASAP7_75t_R  g134(.A(pi01), .B(pi33), .Y(new_n208));
  NAND2x1_ASAP7_75t_R  g135(.A(new_n207), .B(new_n208), .Y(new_n209));
  AO21x1_ASAP7_75t_R   g136(.A1(new_n205), .A2(new_n206), .B(new_n208), .Y(new_n210));
  AND2x2_ASAP7_75t_R   g137(.A(new_n209), .B(new_n210), .Y(new_n211));
  AND3x1_ASAP7_75t_R   g138(.A(new_n209), .B(new_n210), .C(new_n204), .Y(new_n212));
  AOI21x1_ASAP7_75t_R  g139(.A1(new_n209), .A2(new_n210), .B(new_n204), .Y(new_n213));
  OA21x2_ASAP7_75t_R   g140(.A1(new_n212), .A2(new_n213), .B(new_n203), .Y(new_n214));
  AOI211x1_ASAP7_75t_R g141(.A1(new_n201), .A2(new_n202), .B(new_n212), .C(new_n213), .Y(new_n215));
  XOR2x2_ASAP7_75t_R   g142(.A(pi17), .B(pi26), .Y(new_n216));
  XNOR2x2_ASAP7_75t_R  g143(.A(pi03), .B(pi35), .Y(new_n217));
  AND2x2_ASAP7_75t_R   g144(.A(new_n216), .B(new_n217), .Y(new_n218));
  INVx1_ASAP7_75t_R    g145(.A(new_n218), .Y(new_n219));
  NOR2x1_ASAP7_75t_R   g146(.A(new_n216), .B(new_n217), .Y(new_n220));
  INVx1_ASAP7_75t_R    g147(.A(new_n220), .Y(new_n221));
  NOR2x1_ASAP7_75t_R   g148(.A(new_n218), .B(new_n220), .Y(new_n222));
  NAND2x1_ASAP7_75t_R  g149(.A(pi09), .B(new_n81), .Y(new_n223));
  NAND2x1_ASAP7_75t_R  g150(.A(pi13), .B(new_n77), .Y(new_n224));
  AND2x2_ASAP7_75t_R   g151(.A(new_n223), .B(new_n224), .Y(new_n225));
  AO211x2_ASAP7_75t_R  g152(.A1(new_n223), .A2(new_n224), .B(new_n218), .C(new_n220), .Y(new_n226));
  OAI21x1_ASAP7_75t_R  g153(.A1(new_n218), .A2(new_n220), .B(new_n225), .Y(new_n227));
  NAND2x1_ASAP7_75t_R  g154(.A(new_n226), .B(new_n227), .Y(new_n228));
  NOR3x1_ASAP7_75t_R   g155(.A(new_n214), .B(new_n215), .C(new_n228), .Y(new_n229));
  OR3x1_ASAP7_75t_R    g156(.A(new_n214), .B(new_n215), .C(new_n228), .Y(new_n230));
  OA21x2_ASAP7_75t_R   g157(.A1(new_n214), .A2(new_n215), .B(new_n228), .Y(new_n231));
  OAI21x1_ASAP7_75t_R  g158(.A1(new_n214), .A2(new_n215), .B(new_n228), .Y(new_n232));
  AND2x2_ASAP7_75t_R   g159(.A(new_n230), .B(new_n232), .Y(new_n233));
  NAND2x1_ASAP7_75t_R  g160(.A(new_n230), .B(new_n232), .Y(new_n234));
  OA21x2_ASAP7_75t_R   g161(.A1(new_n192), .A2(new_n199), .B(new_n233), .Y(new_n235));
  AND2x2_ASAP7_75t_R   g162(.A(pi05), .B(pi38), .Y(new_n236));
  XOR2x2_ASAP7_75t_R   g163(.A(pi08), .B(pi12), .Y(new_n237));
  XOR2x2_ASAP7_75t_R   g164(.A(new_n236), .B(new_n237), .Y(new_n238));
  XOR2x2_ASAP7_75t_R   g165(.A(pi21), .B(pi30), .Y(new_n239));
  XOR2x2_ASAP7_75t_R   g166(.A(pi16), .B(pi25), .Y(new_n240));
  NAND2x1_ASAP7_75t_R  g167(.A(pi02), .B(new_n97), .Y(new_n241));
  NAND2x1_ASAP7_75t_R  g168(.A(pi34), .B(new_n75), .Y(new_n242));
  XNOR2x2_ASAP7_75t_R  g169(.A(pi02), .B(pi34), .Y(new_n243));
  NAND2x1_ASAP7_75t_R  g170(.A(new_n240), .B(new_n243), .Y(new_n244));
  AO21x1_ASAP7_75t_R   g171(.A1(new_n241), .A2(new_n242), .B(new_n240), .Y(new_n245));
  AND3x1_ASAP7_75t_R   g172(.A(new_n244), .B(new_n245), .C(new_n239), .Y(new_n246));
  AOI21x1_ASAP7_75t_R  g173(.A1(new_n244), .A2(new_n245), .B(new_n239), .Y(new_n247));
  XOR2x2_ASAP7_75t_R   g174(.A(pi14), .B(pi23), .Y(new_n248));
  NAND2x1_ASAP7_75t_R  g175(.A(pi00), .B(new_n96), .Y(new_n249));
  NAND2x1_ASAP7_75t_R  g176(.A(pi32), .B(new_n74), .Y(new_n250));
  XNOR2x2_ASAP7_75t_R  g177(.A(pi00), .B(pi32), .Y(new_n251));
  NAND2x1_ASAP7_75t_R  g178(.A(new_n248), .B(new_n251), .Y(new_n252));
  AO21x1_ASAP7_75t_R   g179(.A1(new_n249), .A2(new_n250), .B(new_n248), .Y(new_n253));
  AND2x2_ASAP7_75t_R   g180(.A(new_n252), .B(new_n253), .Y(new_n254));
  AOI211x1_ASAP7_75t_R g181(.A1(new_n252), .A2(new_n253), .B(new_n246), .C(new_n247), .Y(new_n255));
  OA21x2_ASAP7_75t_R   g182(.A1(new_n246), .A2(new_n247), .B(new_n254), .Y(new_n256));
  NOR3x1_ASAP7_75t_R   g183(.A(new_n255), .B(new_n256), .C(new_n238), .Y(new_n257));
  OR3x1_ASAP7_75t_R    g184(.A(new_n255), .B(new_n256), .C(new_n238), .Y(new_n258));
  OA21x2_ASAP7_75t_R   g185(.A1(new_n255), .A2(new_n256), .B(new_n238), .Y(new_n259));
  OAI21x1_ASAP7_75t_R  g186(.A1(new_n255), .A2(new_n256), .B(new_n238), .Y(new_n260));
  AND2x2_ASAP7_75t_R   g187(.A(new_n258), .B(new_n260), .Y(new_n261));
  NAND2x1_ASAP7_75t_R  g188(.A(new_n258), .B(new_n260), .Y(new_n262));
  AND2x2_ASAP7_75t_R   g189(.A(pi05), .B(pi39), .Y(new_n263));
  XOR2x2_ASAP7_75t_R   g190(.A(pi07), .B(pi11), .Y(new_n264));
  XOR2x2_ASAP7_75t_R   g191(.A(new_n263), .B(new_n264), .Y(new_n265));
  XOR2x2_ASAP7_75t_R   g192(.A(pi20), .B(pi29), .Y(new_n266));
  AND3x1_ASAP7_75t_R   g193(.A(new_n244), .B(new_n245), .C(new_n266), .Y(new_n267));
  AOI21x1_ASAP7_75t_R  g194(.A1(new_n244), .A2(new_n245), .B(new_n266), .Y(new_n268));
  OA21x2_ASAP7_75t_R   g195(.A1(new_n267), .A2(new_n268), .B(new_n222), .Y(new_n269));
  AOI211x1_ASAP7_75t_R g196(.A1(new_n219), .A2(new_n221), .B(new_n267), .C(new_n268), .Y(new_n270));
  NOR3x1_ASAP7_75t_R   g197(.A(new_n270), .B(new_n265), .C(new_n269), .Y(new_n271));
  OR3x1_ASAP7_75t_R    g198(.A(new_n270), .B(new_n265), .C(new_n269), .Y(new_n272));
  OA21x2_ASAP7_75t_R   g199(.A1(new_n269), .A2(new_n270), .B(new_n265), .Y(new_n273));
  OAI21x1_ASAP7_75t_R  g200(.A1(new_n269), .A2(new_n270), .B(new_n265), .Y(new_n274));
  AND2x2_ASAP7_75t_R   g201(.A(new_n272), .B(new_n274), .Y(new_n275));
  NAND2x1_ASAP7_75t_R  g202(.A(new_n272), .B(new_n274), .Y(new_n276));
  XNOR2x2_ASAP7_75t_R  g203(.A(pi06), .B(pi10), .Y(new_n277));
  AND3x1_ASAP7_75t_R   g204(.A(new_n277), .B(pi40), .C(pi05), .Y(new_n278));
  AOI21x1_ASAP7_75t_R  g205(.A1(pi05), .A2(pi40), .B(new_n277), .Y(new_n279));
  NOR2x1_ASAP7_75t_R   g206(.A(new_n278), .B(new_n279), .Y(new_n280));
  OR2x4_ASAP7_75t_R    g207(.A(new_n278), .B(new_n279), .Y(new_n281));
  XOR2x2_ASAP7_75t_R   g208(.A(pi19), .B(pi28), .Y(new_n282));
  AND3x1_ASAP7_75t_R   g209(.A(new_n252), .B(new_n253), .C(new_n282), .Y(new_n283));
  AOI21x1_ASAP7_75t_R  g210(.A1(new_n252), .A2(new_n253), .B(new_n282), .Y(new_n284));
  OA21x2_ASAP7_75t_R   g211(.A1(new_n283), .A2(new_n284), .B(new_n211), .Y(new_n285));
  OAI21x1_ASAP7_75t_R  g212(.A1(new_n283), .A2(new_n284), .B(new_n211), .Y(new_n286));
  AOI211x1_ASAP7_75t_R g213(.A1(new_n209), .A2(new_n210), .B(new_n283), .C(new_n284), .Y(new_n287));
  OR3x1_ASAP7_75t_R    g214(.A(new_n211), .B(new_n283), .C(new_n284), .Y(new_n288));
  AND3x1_ASAP7_75t_R   g215(.A(new_n288), .B(new_n280), .C(new_n286), .Y(new_n289));
  OR3x1_ASAP7_75t_R    g216(.A(new_n287), .B(new_n281), .C(new_n285), .Y(new_n290));
  OA21x2_ASAP7_75t_R   g217(.A1(new_n285), .A2(new_n287), .B(new_n281), .Y(new_n291));
  AO21x1_ASAP7_75t_R   g218(.A1(new_n286), .A2(new_n288), .B(new_n280), .Y(new_n292));
  AND2x2_ASAP7_75t_R   g219(.A(new_n290), .B(new_n292), .Y(new_n293));
  NAND2x1_ASAP7_75t_R  g220(.A(new_n290), .B(new_n292), .Y(new_n294));
  AO211x2_ASAP7_75t_R  g221(.A1(new_n272), .A2(new_n274), .B(new_n289), .C(new_n291), .Y(new_n295));
  NOR2x1_ASAP7_75t_R   g222(.A(new_n262), .B(new_n295), .Y(new_n296));
  OR3x1_ASAP7_75t_R    g223(.A(new_n262), .B(new_n294), .C(new_n275), .Y(new_n297));
  AO31x2_ASAP7_75t_R   g224(.A1(new_n121), .A2(new_n235), .A3(new_n296), .B(new_n74), .Y(new_n298));
  OR5x1_ASAP7_75t_R    g225(.A(pi00), .B(new_n200), .C(new_n234), .D(new_n297), .E(new_n122), .Y(new_n299));
  AND2x2_ASAP7_75t_R   g226(.A(new_n298), .B(new_n299), .Y(po00));
  AND2x2_ASAP7_75t_R   g227(.A(new_n233), .B(new_n262), .Y(new_n301));
  AO211x2_ASAP7_75t_R  g228(.A1(new_n258), .A2(new_n260), .B(new_n229), .C(new_n231), .Y(new_n302));
  AO211x2_ASAP7_75t_R  g229(.A1(new_n290), .A2(new_n292), .B(new_n271), .C(new_n273), .Y(new_n303));
  AOI21x1_ASAP7_75t_R  g230(.A1(new_n295), .A2(new_n303), .B(new_n302), .Y(new_n304));
  AO21x1_ASAP7_75t_R   g231(.A1(new_n295), .A2(new_n303), .B(new_n302), .Y(new_n305));
  AND2x2_ASAP7_75t_R   g232(.A(new_n234), .B(new_n261), .Y(new_n306));
  AO211x2_ASAP7_75t_R  g233(.A1(new_n230), .A2(new_n232), .B(new_n257), .C(new_n259), .Y(new_n307));
  AOI22x1_ASAP7_75t_R  g234(.A1(new_n272), .A2(new_n274), .B1(new_n290), .B2(new_n292), .Y(new_n308));
  OAI21x1_ASAP7_75t_R  g235(.A1(new_n261), .A2(new_n234), .B(new_n308), .Y(new_n309));
  AND3x1_ASAP7_75t_R   g236(.A(new_n302), .B(new_n307), .C(new_n308), .Y(new_n310));
  OAI21x1_ASAP7_75t_R  g237(.A1(new_n309), .A2(new_n306), .B(new_n305), .Y(new_n311));
  OAI21x1_ASAP7_75t_R  g238(.A1(new_n304), .A2(new_n310), .B(new_n145), .Y(new_n312));
  AND2x2_ASAP7_75t_R   g239(.A(new_n168), .B(new_n190), .Y(new_n313));
  NAND2x1_ASAP7_75t_R  g240(.A(new_n168), .B(new_n190), .Y(new_n314));
  OA211x2_ASAP7_75t_R  g241(.A1(new_n304), .A2(new_n310), .B(new_n313), .C(new_n145), .Y(new_n315));
  AOI21x1_ASAP7_75t_R  g242(.A1(new_n293), .A2(new_n315), .B(new_n78), .Y(new_n316));
  AND5x1_ASAP7_75t_R   g243(.A(new_n293), .B(new_n311), .C(new_n313), .D(new_n145), .E(new_n78), .Y(new_n317));
  NOR2x1_ASAP7_75t_R   g244(.A(new_n316), .B(new_n317), .Y(po01));
  AO31x2_ASAP7_75t_R   g245(.A1(new_n188), .A2(new_n235), .A3(new_n296), .B(new_n96), .Y(new_n319));
  OR5x1_ASAP7_75t_R    g246(.A(pi32), .B(new_n200), .C(new_n234), .D(new_n297), .E(new_n189), .Y(new_n320));
  AND2x2_ASAP7_75t_R   g247(.A(new_n319), .B(new_n320), .Y(po02));
  AO31x2_ASAP7_75t_R   g248(.A1(new_n169), .A2(new_n235), .A3(new_n296), .B(new_n90), .Y(new_n322));
  OR5x1_ASAP7_75t_R    g249(.A(new_n234), .B(new_n200), .C(new_n168), .D(pi23), .E(new_n297), .Y(new_n323));
  AND2x2_ASAP7_75t_R   g250(.A(new_n322), .B(new_n323), .Y(po03));
  AO31x2_ASAP7_75t_R   g251(.A1(new_n145), .A2(new_n235), .A3(new_n296), .B(new_n82), .Y(new_n325));
  OR5x1_ASAP7_75t_R    g252(.A(new_n234), .B(new_n200), .C(new_n144), .D(pi14), .E(new_n297), .Y(new_n326));
  AND2x2_ASAP7_75t_R   g253(.A(new_n325), .B(new_n326), .Y(po04));
  OA21x2_ASAP7_75t_R   g254(.A1(new_n192), .A2(new_n199), .B(new_n234), .Y(new_n328));
  NOR2x1_ASAP7_75t_R   g255(.A(new_n261), .B(new_n295), .Y(new_n329));
  AO21x1_ASAP7_75t_R   g256(.A1(new_n258), .A2(new_n260), .B(new_n295), .Y(new_n330));
  AND5x1_ASAP7_75t_R   g257(.A(new_n189), .B(new_n329), .C(new_n234), .D(new_n121), .E(new_n170), .Y(new_n331));
  XNOR2x2_ASAP7_75t_R  g258(.A(pi01), .B(new_n331), .Y(po05));
  OR5x1_ASAP7_75t_R    g259(.A(new_n171), .B(new_n189), .C(new_n330), .D(new_n233), .E(new_n121), .Y(new_n333));
  XOR2x2_ASAP7_75t_R   g260(.A(pi33), .B(new_n333), .Y(po06));
  AO31x2_ASAP7_75t_R   g261(.A1(new_n169), .A2(new_n328), .A3(new_n329), .B(new_n91), .Y(new_n335));
  OR5x1_ASAP7_75t_R    g262(.A(new_n168), .B(new_n200), .C(new_n330), .D(new_n233), .E(pi24), .Y(new_n336));
  AND2x2_ASAP7_75t_R   g263(.A(new_n335), .B(new_n336), .Y(po07));
  OAI21x1_ASAP7_75t_R  g264(.A1(new_n304), .A2(new_n310), .B(new_n144), .Y(new_n338));
  AND2x2_ASAP7_75t_R   g265(.A(new_n190), .B(new_n169), .Y(new_n339));
  INVx1_ASAP7_75t_R    g266(.A(new_n339), .Y(new_n340));
  OA211x2_ASAP7_75t_R  g267(.A1(new_n304), .A2(new_n310), .B(new_n339), .C(new_n144), .Y(new_n341));
  AO21x1_ASAP7_75t_R   g268(.A1(new_n341), .A2(new_n234), .B(new_n77), .Y(new_n342));
  OR4x2_ASAP7_75t_R    g269(.A(new_n338), .B(new_n340), .C(pi09), .D(new_n233), .Y(new_n343));
  AND2x2_ASAP7_75t_R   g270(.A(new_n342), .B(new_n343), .Y(po08));
  AO31x2_ASAP7_75t_R   g271(.A1(new_n145), .A2(new_n328), .A3(new_n329), .B(new_n83), .Y(new_n345));
  OR5x1_ASAP7_75t_R    g272(.A(new_n144), .B(new_n200), .C(new_n330), .D(new_n233), .E(pi15), .Y(new_n346));
  AND2x2_ASAP7_75t_R   g273(.A(new_n345), .B(new_n346), .Y(po09));
  AND3x1_ASAP7_75t_R   g274(.A(new_n261), .B(new_n294), .C(new_n275), .Y(new_n348));
  OR3x1_ASAP7_75t_R    g275(.A(new_n303), .B(new_n259), .C(new_n257), .Y(new_n349));
  AO31x2_ASAP7_75t_R   g276(.A1(new_n121), .A2(new_n235), .A3(new_n348), .B(new_n75), .Y(new_n350));
  OR5x1_ASAP7_75t_R    g277(.A(pi02), .B(new_n200), .C(new_n234), .D(new_n349), .E(new_n122), .Y(new_n351));
  AND2x2_ASAP7_75t_R   g278(.A(new_n350), .B(new_n351), .Y(po10));
  AO31x2_ASAP7_75t_R   g279(.A1(new_n188), .A2(new_n235), .A3(new_n348), .B(new_n97), .Y(new_n353));
  OR5x1_ASAP7_75t_R    g280(.A(pi34), .B(new_n200), .C(new_n234), .D(new_n349), .E(new_n189), .Y(new_n354));
  AND2x2_ASAP7_75t_R   g281(.A(new_n353), .B(new_n354), .Y(po11));
  AO31x2_ASAP7_75t_R   g282(.A1(new_n169), .A2(new_n235), .A3(new_n348), .B(new_n92), .Y(new_n356));
  OR5x1_ASAP7_75t_R    g283(.A(new_n234), .B(new_n200), .C(new_n168), .D(pi25), .E(new_n349), .Y(new_n357));
  AND2x2_ASAP7_75t_R   g284(.A(new_n356), .B(new_n357), .Y(po12));
  AO31x2_ASAP7_75t_R   g285(.A1(new_n145), .A2(new_n235), .A3(new_n348), .B(new_n84), .Y(new_n359));
  OR5x1_ASAP7_75t_R    g286(.A(new_n234), .B(new_n200), .C(new_n144), .D(pi16), .E(new_n349), .Y(new_n360));
  AND2x2_ASAP7_75t_R   g287(.A(new_n359), .B(new_n360), .Y(po13));
  AND3x1_ASAP7_75t_R   g288(.A(new_n262), .B(new_n294), .C(new_n275), .Y(new_n362));
  INVx1_ASAP7_75t_R    g289(.A(new_n362), .Y(new_n363));
  AND5x1_ASAP7_75t_R   g290(.A(new_n189), .B(new_n362), .C(new_n234), .D(new_n121), .E(new_n170), .Y(new_n364));
  XNOR2x2_ASAP7_75t_R  g291(.A(pi03), .B(new_n364), .Y(po14));
  AND5x1_ASAP7_75t_R   g292(.A(new_n170), .B(new_n188), .C(new_n362), .D(new_n234), .E(new_n122), .Y(new_n366));
  XNOR2x2_ASAP7_75t_R  g293(.A(pi35), .B(new_n366), .Y(po15));
  AO31x2_ASAP7_75t_R   g294(.A1(new_n169), .A2(new_n328), .A3(new_n362), .B(new_n93), .Y(new_n368));
  OR5x1_ASAP7_75t_R    g295(.A(new_n168), .B(new_n200), .C(new_n363), .D(new_n233), .E(pi26), .Y(new_n369));
  AND2x2_ASAP7_75t_R   g296(.A(new_n368), .B(new_n369), .Y(po16));
  AO31x2_ASAP7_75t_R   g297(.A1(new_n145), .A2(new_n328), .A3(new_n362), .B(new_n85), .Y(new_n371));
  OR5x1_ASAP7_75t_R    g298(.A(new_n144), .B(new_n200), .C(new_n363), .D(new_n233), .E(pi17), .Y(new_n372));
  AND2x2_ASAP7_75t_R   g299(.A(new_n371), .B(new_n372), .Y(po17));
  AND5x1_ASAP7_75t_R   g300(.A(new_n144), .B(new_n293), .C(new_n301), .D(new_n339), .E(new_n276), .Y(new_n374));
  XNOR2x2_ASAP7_75t_R  g301(.A(pi06), .B(new_n374), .Y(po18));
  AND5x1_ASAP7_75t_R   g302(.A(new_n144), .B(new_n275), .C(new_n339), .D(new_n294), .E(new_n301), .Y(new_n376));
  XNOR2x2_ASAP7_75t_R  g303(.A(pi07), .B(new_n376), .Y(po19));
  AOI21x1_ASAP7_75t_R  g304(.A1(new_n261), .A2(new_n341), .B(new_n76), .Y(new_n378));
  AND5x1_ASAP7_75t_R   g305(.A(new_n76), .B(new_n311), .C(new_n339), .D(new_n144), .E(new_n261), .Y(new_n379));
  NOR2x1_ASAP7_75t_R   g306(.A(new_n378), .B(new_n379), .Y(po20));
  AOI21x1_ASAP7_75t_R  g307(.A1(new_n275), .A2(new_n315), .B(new_n79), .Y(new_n381));
  AND5x1_ASAP7_75t_R   g308(.A(new_n275), .B(new_n311), .C(new_n313), .D(new_n145), .E(new_n79), .Y(new_n382));
  NOR2x1_ASAP7_75t_R   g309(.A(new_n381), .B(new_n382), .Y(po21));
  AOI21x1_ASAP7_75t_R  g310(.A1(new_n261), .A2(new_n315), .B(new_n80), .Y(new_n384));
  AND5x1_ASAP7_75t_R   g311(.A(new_n261), .B(new_n311), .C(new_n313), .D(new_n145), .E(new_n80), .Y(new_n385));
  NOR2x1_ASAP7_75t_R   g312(.A(new_n384), .B(new_n385), .Y(po22));
  AO21x1_ASAP7_75t_R   g313(.A1(new_n315), .A2(new_n234), .B(new_n81), .Y(new_n387));
  OR4x2_ASAP7_75t_R    g314(.A(new_n312), .B(new_n314), .C(pi13), .D(new_n233), .Y(new_n388));
  AND2x2_ASAP7_75t_R   g315(.A(new_n387), .B(new_n388), .Y(po23));
  AND2x2_ASAP7_75t_R   g316(.A(new_n191), .B(new_n169), .Y(new_n390));
  INVx1_ASAP7_75t_R    g317(.A(new_n390), .Y(new_n391));
  OA211x2_ASAP7_75t_R  g318(.A1(new_n304), .A2(new_n310), .B(new_n390), .C(new_n144), .Y(new_n392));
  AND5x1_ASAP7_75t_R   g319(.A(new_n144), .B(new_n293), .C(new_n301), .D(new_n390), .E(new_n276), .Y(new_n393));
  XNOR2x2_ASAP7_75t_R  g320(.A(pi28), .B(new_n393), .Y(po24));
  AND5x1_ASAP7_75t_R   g321(.A(new_n144), .B(new_n275), .C(new_n390), .D(new_n294), .E(new_n301), .Y(new_n395));
  XNOR2x2_ASAP7_75t_R  g322(.A(pi29), .B(new_n395), .Y(po25));
  AOI21x1_ASAP7_75t_R  g323(.A1(new_n261), .A2(new_n392), .B(new_n94), .Y(new_n397));
  AND5x1_ASAP7_75t_R   g324(.A(new_n94), .B(new_n311), .C(new_n390), .D(new_n144), .E(new_n261), .Y(new_n398));
  NOR2x1_ASAP7_75t_R   g325(.A(new_n397), .B(new_n398), .Y(po26));
  AO21x1_ASAP7_75t_R   g326(.A1(new_n392), .A2(new_n234), .B(new_n95), .Y(new_n400));
  OR4x2_ASAP7_75t_R    g327(.A(new_n338), .B(new_n391), .C(pi31), .D(new_n233), .Y(new_n401));
  AND2x2_ASAP7_75t_R   g328(.A(new_n400), .B(new_n401), .Y(po27));
  AND2x2_ASAP7_75t_R   g329(.A(new_n168), .B(new_n191), .Y(new_n403));
  NAND2x1_ASAP7_75t_R  g330(.A(new_n168), .B(new_n191), .Y(new_n404));
  OA211x2_ASAP7_75t_R  g331(.A1(new_n304), .A2(new_n310), .B(new_n403), .C(new_n145), .Y(new_n405));
  AOI21x1_ASAP7_75t_R  g332(.A1(new_n293), .A2(new_n405), .B(new_n86), .Y(new_n406));
  AND5x1_ASAP7_75t_R   g333(.A(new_n293), .B(new_n311), .C(new_n403), .D(new_n145), .E(new_n86), .Y(new_n407));
  NOR2x1_ASAP7_75t_R   g334(.A(new_n406), .B(new_n407), .Y(po28));
  AOI21x1_ASAP7_75t_R  g335(.A1(new_n275), .A2(new_n405), .B(new_n87), .Y(new_n409));
  AND5x1_ASAP7_75t_R   g336(.A(new_n275), .B(new_n311), .C(new_n403), .D(new_n145), .E(new_n87), .Y(new_n410));
  NOR2x1_ASAP7_75t_R   g337(.A(new_n409), .B(new_n410), .Y(po29));
  AOI21x1_ASAP7_75t_R  g338(.A1(new_n261), .A2(new_n405), .B(new_n88), .Y(new_n412));
  AND5x1_ASAP7_75t_R   g339(.A(new_n261), .B(new_n311), .C(new_n403), .D(new_n145), .E(new_n88), .Y(new_n413));
  NOR2x1_ASAP7_75t_R   g340(.A(new_n412), .B(new_n413), .Y(po30));
  AO21x1_ASAP7_75t_R   g341(.A1(new_n405), .A2(new_n234), .B(new_n89), .Y(new_n415));
  OR4x2_ASAP7_75t_R    g342(.A(new_n312), .B(new_n404), .C(pi22), .D(new_n233), .Y(new_n416));
  AND2x2_ASAP7_75t_R   g343(.A(new_n415), .B(new_n416), .Y(po31));
endmodule


