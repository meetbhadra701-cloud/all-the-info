// Benchmark "/w/experiments/inputs/c1/c2/c1908" written by ABC on Fri Sep 25 10:27:00 2026

module \/w/experiments/inputs/c1/c2/c1908  ( 
    pi00, pi01, pi02, pi03, pi04, pi05, pi06, pi07, pi08, pi09, pi10, pi11,
    pi12, pi13, pi14, pi15, pi16, pi17, pi18, pi19, pi20, pi21, pi22, pi23,
    pi24, pi25, pi26, pi27, pi28, pi29, pi30, pi31, pi32,
    po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10, po11,
    po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22, po23,
    po24  );
  input  pi00, pi01, pi02, pi03, pi04, pi05, pi06, pi07, pi08, pi09,
    pi10, pi11, pi12, pi13, pi14, pi15, pi16, pi17, pi18, pi19, pi20, pi21,
    pi22, pi23, pi24, pi25, pi26, pi27, pi28, pi29, pi30, pi31, pi32;
  output po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10,
    po11, po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22,
    po23, po24;
  wire new_n59, new_n60, new_n61, new_n62, new_n63, new_n64, new_n65,
    new_n66, new_n67, new_n68, new_n69, new_n70, new_n71, new_n72, new_n73,
    new_n74, new_n75, new_n76, new_n77, new_n78, new_n79, new_n80, new_n81,
    new_n82, new_n83, new_n84, new_n85, new_n86, new_n87, new_n88, new_n89,
    new_n90, new_n91, new_n92, new_n93, new_n94, new_n95, new_n96, new_n97,
    new_n98, new_n99, new_n100, new_n101, new_n102, new_n103, new_n104,
    new_n105, new_n106, new_n107, new_n108, new_n109, new_n110, new_n111,
    new_n112, new_n113, new_n114, new_n115, new_n116, new_n117, new_n118,
    new_n119, new_n120, new_n121, new_n122, new_n123, new_n124, new_n125,
    new_n126, new_n127, new_n128, new_n129, new_n130, new_n131, new_n132,
    new_n133, new_n134, new_n135, new_n136, new_n137, new_n138, new_n139,
    new_n140, new_n141, new_n142, new_n143, new_n144, new_n145, new_n146,
    new_n147, new_n148, new_n149, new_n150, new_n151, new_n152, new_n153,
    new_n154, new_n155, new_n156, new_n157, new_n158, new_n159, new_n160,
    new_n161, new_n162, new_n163, new_n164, new_n165, new_n166, new_n167,
    new_n168, new_n169, new_n170, new_n171, new_n172, new_n173, new_n174,
    new_n175, new_n176, new_n177, new_n178, new_n180, new_n181, new_n182,
    new_n183, new_n189, new_n193, new_n194, new_n195, new_n200, new_n204,
    new_n205, new_n206, new_n207, new_n208, new_n209, new_n211, new_n212,
    new_n213, new_n215, new_n216, new_n218, new_n219, new_n221, new_n222,
    new_n224, new_n225, new_n227, new_n228, new_n229, new_n230, new_n232,
    new_n233, new_n234, new_n235, new_n236, new_n238, new_n239;
  INVx1_ASAP7_75t_R    g000(.A(pi00), .Y(new_n59));
  INVx1_ASAP7_75t_R    g001(.A(pi01), .Y(new_n60));
  INVx1_ASAP7_75t_R    g002(.A(pi02), .Y(new_n61));
  INVx1_ASAP7_75t_R    g003(.A(pi03), .Y(new_n62));
  INVx1_ASAP7_75t_R    g004(.A(pi05), .Y(new_n63));
  INVx1_ASAP7_75t_R    g005(.A(pi23), .Y(new_n64));
  INVx1_ASAP7_75t_R    g006(.A(pi24), .Y(new_n65));
  INVx1_ASAP7_75t_R    g007(.A(pi25), .Y(new_n66));
  INVx1_ASAP7_75t_R    g008(.A(pi26), .Y(new_n67));
  INVx1_ASAP7_75t_R    g009(.A(pi32), .Y(new_n68));
  OA211x2_ASAP7_75t_R  g010(.A1(pi00), .A2(new_n60), .B(new_n61), .C(new_n63), .Y(new_n69));
  NOR2x1_ASAP7_75t_R   g011(.A(pi02), .B(pi04), .Y(new_n70));
  OA21x2_ASAP7_75t_R   g012(.A1(new_n60), .A2(pi00), .B(new_n62), .Y(new_n71));
  AO21x1_ASAP7_75t_R   g013(.A1(new_n70), .A2(new_n71), .B(new_n69), .Y(new_n72));
  XOR2x2_ASAP7_75t_R   g014(.A(pi09), .B(pi18), .Y(new_n73));
  XNOR2x2_ASAP7_75t_R  g015(.A(pi06), .B(pi19), .Y(new_n74));
  XOR2x2_ASAP7_75t_R   g016(.A(new_n74), .B(pi20), .Y(new_n75));
  NOR2x1_ASAP7_75t_R   g017(.A(pi01), .B(pi02), .Y(new_n76));
  OR2x4_ASAP7_75t_R    g018(.A(pi14), .B(pi15), .Y(new_n77));
  NAND2x1_ASAP7_75t_R  g019(.A(pi14), .B(pi15), .Y(new_n78));
  AND2x2_ASAP7_75t_R   g020(.A(new_n77), .B(new_n78), .Y(new_n79));
  AOI21x1_ASAP7_75t_R  g021(.A1(new_n78), .A2(new_n77), .B(pi16), .Y(new_n80));
  AO21x1_ASAP7_75t_R   g022(.A1(new_n77), .A2(new_n78), .B(pi16), .Y(new_n81));
  AND3x1_ASAP7_75t_R   g023(.A(new_n77), .B(new_n78), .C(pi16), .Y(new_n82));
  NAND3x1_ASAP7_75t_R  g024(.A(new_n77), .B(new_n78), .C(pi16), .Y(new_n83));
  OA211x2_ASAP7_75t_R  g025(.A1(new_n82), .A2(new_n80), .B(new_n76), .C(pi17), .Y(new_n84));
  AOI211x1_ASAP7_75t_R g026(.A1(pi17), .A2(new_n76), .B(new_n82), .C(new_n80), .Y(new_n85));
  OAI21x1_ASAP7_75t_R  g027(.A1(new_n85), .A2(new_n84), .B(new_n75), .Y(new_n86));
  OR3x1_ASAP7_75t_R    g028(.A(new_n84), .B(new_n85), .C(new_n75), .Y(new_n87));
  AND2x2_ASAP7_75t_R   g029(.A(new_n87), .B(new_n86), .Y(new_n88));
  XOR2x2_ASAP7_75t_R   g030(.A(new_n88), .B(new_n73), .Y(new_n89));
  OR3x1_ASAP7_75t_R    g031(.A(new_n89), .B(pi21), .C(pi03), .Y(new_n90));
  OAI21x1_ASAP7_75t_R  g032(.A1(pi03), .A2(new_n89), .B(pi21), .Y(new_n91));
  XOR2x2_ASAP7_75t_R   g033(.A(pi09), .B(pi10), .Y(new_n92));
  NOR2x1_ASAP7_75t_R   g034(.A(pi00), .B(pi02), .Y(new_n93));
  AND3x1_ASAP7_75t_R   g035(.A(new_n59), .B(new_n61), .C(pi12), .Y(new_n94));
  XNOR2x2_ASAP7_75t_R  g036(.A(pi06), .B(pi07), .Y(new_n95));
  XOR2x2_ASAP7_75t_R   g037(.A(pi08), .B(pi11), .Y(new_n96));
  XOR2x2_ASAP7_75t_R   g038(.A(new_n95), .B(new_n96), .Y(new_n97));
  XOR2x2_ASAP7_75t_R   g039(.A(new_n97), .B(new_n94), .Y(new_n98));
  XOR2x2_ASAP7_75t_R   g040(.A(new_n98), .B(new_n92), .Y(new_n99));
  OR3x1_ASAP7_75t_R    g041(.A(new_n99), .B(pi13), .C(pi03), .Y(new_n100));
  OAI21x1_ASAP7_75t_R  g042(.A1(pi03), .A2(new_n99), .B(pi13), .Y(new_n101));
  AND4x2_ASAP7_75t_R   g043(.A(new_n90), .B(new_n91), .C(new_n100), .D(new_n101), .Y(new_n102));
  AND2x2_ASAP7_75t_R   g044(.A(new_n102), .B(new_n72), .Y(new_n103));
  NAND2x1_ASAP7_75t_R  g045(.A(new_n72), .B(new_n102), .Y(new_n104));
  OA21x2_ASAP7_75t_R   g046(.A1(pi01), .A2(pi03), .B(pi27), .Y(new_n105));
  INVx1_ASAP7_75t_R    g047(.A(new_n105), .Y(new_n106));
  AND2x2_ASAP7_75t_R   g048(.A(new_n61), .B(pi31), .Y(new_n107));
  XOR2x2_ASAP7_75t_R   g049(.A(new_n107), .B(pi14), .Y(new_n108));
  XNOR2x2_ASAP7_75t_R  g050(.A(pi09), .B(pi16), .Y(new_n109));
  XOR2x2_ASAP7_75t_R   g051(.A(new_n109), .B(pi10), .Y(new_n110));
  XNOR2x2_ASAP7_75t_R  g052(.A(pi06), .B(pi23), .Y(new_n111));
  XNOR2x2_ASAP7_75t_R  g053(.A(pi07), .B(pi22), .Y(new_n112));
  AND2x2_ASAP7_75t_R   g054(.A(new_n112), .B(pi19), .Y(new_n113));
  NAND2x1_ASAP7_75t_R  g055(.A(pi19), .B(new_n112), .Y(new_n114));
  NOR2x1_ASAP7_75t_R   g056(.A(pi19), .B(new_n112), .Y(new_n115));
  OR2x4_ASAP7_75t_R    g057(.A(pi19), .B(new_n112), .Y(new_n116));
  XNOR2x2_ASAP7_75t_R  g058(.A(pi08), .B(pi20), .Y(new_n117));
  AND2x2_ASAP7_75t_R   g059(.A(new_n117), .B(pi26), .Y(new_n118));
  NAND2x1_ASAP7_75t_R  g060(.A(pi26), .B(new_n117), .Y(new_n119));
  NOR2x1_ASAP7_75t_R   g061(.A(pi26), .B(new_n117), .Y(new_n120));
  OR2x4_ASAP7_75t_R    g062(.A(pi26), .B(new_n117), .Y(new_n121));
  NAND2x1_ASAP7_75t_R  g063(.A(new_n119), .B(new_n121), .Y(new_n122));
  AO211x2_ASAP7_75t_R  g064(.A1(new_n119), .A2(new_n121), .B(new_n113), .C(new_n115), .Y(new_n123));
  AO211x2_ASAP7_75t_R  g065(.A1(new_n114), .A2(new_n116), .B(new_n118), .C(new_n120), .Y(new_n124));
  AND3x1_ASAP7_75t_R   g066(.A(new_n123), .B(new_n124), .C(new_n111), .Y(new_n125));
  AOI21x1_ASAP7_75t_R  g067(.A1(new_n123), .A2(new_n124), .B(new_n111), .Y(new_n126));
  OA21x2_ASAP7_75t_R   g068(.A1(new_n125), .A2(new_n126), .B(new_n110), .Y(new_n127));
  NOR3x1_ASAP7_75t_R   g069(.A(new_n125), .B(new_n126), .C(new_n110), .Y(new_n128));
  NOR3x1_ASAP7_75t_R   g070(.A(new_n128), .B(new_n127), .C(new_n108), .Y(new_n129));
  OR3x1_ASAP7_75t_R    g071(.A(new_n128), .B(new_n127), .C(new_n108), .Y(new_n130));
  OA21x2_ASAP7_75t_R   g072(.A1(new_n128), .A2(new_n127), .B(new_n108), .Y(new_n131));
  OAI21x1_ASAP7_75t_R  g073(.A1(new_n127), .A2(new_n128), .B(new_n108), .Y(new_n132));
  NAND2x1_ASAP7_75t_R  g074(.A(new_n132), .B(new_n130), .Y(new_n133));
  AND4x2_ASAP7_75t_R   g075(.A(new_n130), .B(new_n132), .C(new_n62), .D(new_n106), .Y(new_n134));
  OA31x2_ASAP7_75t_R   g076(.A1(pi03), .A2(new_n129), .A3(new_n131), .B1(new_n105), .Y(new_n135));
  NOR2x1_ASAP7_75t_R   g077(.A(new_n135), .B(new_n134), .Y(new_n136));
  XOR2x2_ASAP7_75t_R   g078(.A(pi10), .B(pi22), .Y(new_n137));
  OR4x2_ASAP7_75t_R    g079(.A(new_n65), .B(pi25), .C(pi00), .D(pi02), .Y(new_n138));
  AO21x1_ASAP7_75t_R   g080(.A1(new_n93), .A2(pi24), .B(new_n66), .Y(new_n139));
  OA21x2_ASAP7_75t_R   g081(.A1(new_n82), .A2(new_n80), .B(pi23), .Y(new_n140));
  AND3x1_ASAP7_75t_R   g082(.A(new_n83), .B(new_n81), .C(new_n64), .Y(new_n141));
  OA211x2_ASAP7_75t_R  g083(.A1(new_n141), .A2(new_n140), .B(new_n139), .C(new_n138), .Y(new_n142));
  AOI211x1_ASAP7_75t_R g084(.A1(new_n138), .A2(new_n139), .B(new_n141), .C(new_n140), .Y(new_n143));
  OR3x1_ASAP7_75t_R    g085(.A(new_n142), .B(new_n143), .C(new_n137), .Y(new_n144));
  OAI21x1_ASAP7_75t_R  g086(.A1(new_n143), .A2(new_n142), .B(new_n137), .Y(new_n145));
  AND2x2_ASAP7_75t_R   g087(.A(new_n144), .B(new_n145), .Y(new_n146));
  OA21x2_ASAP7_75t_R   g088(.A1(pi00), .A2(pi03), .B(pi12), .Y(new_n147));
  OR3x1_ASAP7_75t_R    g089(.A(new_n146), .B(new_n147), .C(pi03), .Y(new_n148));
  AO21x1_ASAP7_75t_R   g090(.A1(new_n116), .A2(new_n114), .B(new_n67), .Y(new_n149));
  OR3x1_ASAP7_75t_R    g091(.A(new_n115), .B(new_n113), .C(pi26), .Y(new_n150));
  NAND2x1_ASAP7_75t_R  g092(.A(new_n149), .B(new_n150), .Y(new_n151));
  INVx1_ASAP7_75t_R    g093(.A(new_n151), .Y(new_n152));
  XOR2x2_ASAP7_75t_R   g094(.A(pi11), .B(pi25), .Y(new_n153));
  XOR2x2_ASAP7_75t_R   g095(.A(new_n153), .B(pi18), .Y(new_n154));
  XNOR2x2_ASAP7_75t_R  g096(.A(new_n154), .B(new_n110), .Y(new_n155));
  AND3x1_ASAP7_75t_R   g097(.A(new_n60), .B(new_n61), .C(pi27), .Y(new_n156));
  NAND2x1_ASAP7_75t_R  g098(.A(new_n156), .B(new_n155), .Y(new_n157));
  AO21x1_ASAP7_75t_R   g099(.A1(pi27), .A2(new_n76), .B(new_n155), .Y(new_n158));
  AND3x1_ASAP7_75t_R   g100(.A(new_n157), .B(new_n158), .C(new_n152), .Y(new_n159));
  AOI21x1_ASAP7_75t_R  g101(.A1(new_n158), .A2(new_n157), .B(new_n152), .Y(new_n160));
  OR2x4_ASAP7_75t_R    g102(.A(new_n160), .B(new_n159), .Y(new_n161));
  OAI21x1_ASAP7_75t_R  g103(.A1(new_n160), .A2(new_n159), .B(new_n62), .Y(new_n162));
  OA21x2_ASAP7_75t_R   g104(.A1(new_n146), .A2(pi03), .B(new_n147), .Y(new_n163));
  AOI21x1_ASAP7_75t_R  g105(.A1(pi28), .A2(new_n162), .B(new_n163), .Y(new_n164));
  OA211x2_ASAP7_75t_R  g106(.A1(pi28), .A2(new_n162), .B(new_n164), .C(new_n148), .Y(new_n165));
  INVx1_ASAP7_75t_R    g107(.A(new_n165), .Y(new_n166));
  AO21x1_ASAP7_75t_R   g108(.A1(new_n59), .A2(new_n62), .B(new_n65), .Y(new_n167));
  NAND2x1_ASAP7_75t_R  g109(.A(pi29), .B(new_n61), .Y(new_n168));
  XOR2x2_ASAP7_75t_R   g110(.A(new_n122), .B(new_n168), .Y(new_n169));
  XNOR2x2_ASAP7_75t_R  g111(.A(pi15), .B(pi23), .Y(new_n170));
  XOR2x2_ASAP7_75t_R   g112(.A(new_n155), .B(new_n170), .Y(new_n171));
  XOR2x2_ASAP7_75t_R   g113(.A(new_n171), .B(new_n169), .Y(new_n172));
  NAND2x1_ASAP7_75t_R  g114(.A(new_n62), .B(new_n172), .Y(new_n173));
  XOR2x2_ASAP7_75t_R   g115(.A(new_n173), .B(pi30), .Y(new_n174));
  NOR2x1_ASAP7_75t_R   g116(.A(new_n167), .B(new_n174), .Y(new_n175));
  OAI21x1_ASAP7_75t_R  g117(.A1(pi01), .A2(pi03), .B(pi17), .Y(new_n176));
  OR5x1_ASAP7_75t_R    g118(.A(new_n175), .B(new_n176), .C(new_n134), .D(new_n135), .E(new_n166), .Y(new_n177));
  OR2x4_ASAP7_75t_R    g119(.A(new_n104), .B(new_n177), .Y(new_n178));
  XOR2x2_ASAP7_75t_R   g120(.A(new_n178), .B(pi15), .Y(po00));
  AND3x1_ASAP7_75t_R   g121(.A(new_n71), .B(new_n68), .C(new_n61), .Y(new_n180));
  OA21x2_ASAP7_75t_R   g122(.A1(new_n69), .A2(new_n180), .B(new_n102), .Y(new_n181));
  OA21x2_ASAP7_75t_R   g123(.A1(new_n136), .A2(new_n176), .B(new_n165), .Y(new_n182));
  OA211x2_ASAP7_75t_R  g124(.A1(new_n167), .A2(new_n174), .B(new_n182), .C(new_n181), .Y(new_n183));
  XOR2x2_ASAP7_75t_R   g125(.A(new_n183), .B(new_n67), .Y(po01));
  XNOR2x2_ASAP7_75t_R  g126(.A(pi20), .B(new_n183), .Y(po02));
  XOR2x2_ASAP7_75t_R   g127(.A(new_n178), .B(pi25), .Y(po03));
  XNOR2x2_ASAP7_75t_R  g128(.A(pi08), .B(new_n183), .Y(po04));
  XOR2x2_ASAP7_75t_R   g129(.A(new_n183), .B(new_n64), .Y(po05));
  OA211x2_ASAP7_75t_R  g130(.A1(new_n167), .A2(new_n174), .B(new_n182), .C(new_n103), .Y(new_n189));
  XNOR2x2_ASAP7_75t_R  g131(.A(pi10), .B(new_n189), .Y(po06));
  XNOR2x2_ASAP7_75t_R  g132(.A(pi09), .B(new_n189), .Y(po07));
  XNOR2x2_ASAP7_75t_R  g133(.A(pi16), .B(new_n189), .Y(po08));
  OA211x2_ASAP7_75t_R  g134(.A1(pi00), .A2(pi03), .B(new_n174), .C(pi24), .Y(new_n193));
  NAND2x1_ASAP7_75t_R  g135(.A(new_n182), .B(new_n193), .Y(new_n194));
  AND3x1_ASAP7_75t_R   g136(.A(new_n193), .B(new_n182), .C(new_n181), .Y(new_n195));
  XNOR2x2_ASAP7_75t_R  g137(.A(pi19), .B(new_n195), .Y(po09));
  XNOR2x2_ASAP7_75t_R  g138(.A(pi07), .B(new_n195), .Y(po10));
  XNOR2x2_ASAP7_75t_R  g139(.A(pi22), .B(new_n195), .Y(po11));
  XNOR2x2_ASAP7_75t_R  g140(.A(pi06), .B(new_n195), .Y(po12));
  AND3x1_ASAP7_75t_R   g141(.A(new_n193), .B(new_n182), .C(new_n103), .Y(new_n200));
  XNOR2x2_ASAP7_75t_R  g142(.A(pi14), .B(new_n200), .Y(po13));
  XOR2x2_ASAP7_75t_R   g143(.A(new_n178), .B(pi18), .Y(po14));
  XOR2x2_ASAP7_75t_R   g144(.A(new_n178), .B(pi11), .Y(po15));
  NOR2x1_ASAP7_75t_R   g145(.A(new_n183), .B(new_n189), .Y(new_n204));
  NAND2x1_ASAP7_75t_R  g146(.A(new_n69), .B(new_n102), .Y(new_n205));
  AO21x1_ASAP7_75t_R   g147(.A1(new_n177), .A2(new_n194), .B(new_n205), .Y(new_n206));
  AO21x1_ASAP7_75t_R   g148(.A1(new_n206), .A2(new_n204), .B(new_n63), .Y(new_n207));
  AND5x1_ASAP7_75t_R   g149(.A(new_n174), .B(new_n176), .C(new_n102), .D(new_n165), .E(new_n167), .Y(new_n208));
  AOI21x1_ASAP7_75t_R  g150(.A1(new_n136), .A2(new_n208), .B(pi02), .Y(new_n209));
  NAND2x1_ASAP7_75t_R  g151(.A(new_n209), .B(new_n207), .Y(po16));
  OA21x2_ASAP7_75t_R   g152(.A1(new_n183), .A2(new_n189), .B(new_n62), .Y(new_n211));
  NAND2x1_ASAP7_75t_R  g153(.A(new_n105), .B(new_n211), .Y(new_n212));
  OAI22x1_ASAP7_75t_R  g154(.A1(pi02), .A2(pi05), .B1(new_n212), .B2(new_n133), .Y(new_n213));
  AOI21x1_ASAP7_75t_R  g155(.A1(new_n133), .A2(new_n212), .B(new_n213), .Y(po17));
  AOI21x1_ASAP7_75t_R  g156(.A1(pi30), .A2(new_n211), .B(new_n172), .Y(new_n215));
  AO32x1_ASAP7_75t_R   g157(.A1(pi30), .A2(new_n211), .A3(new_n172), .B1(new_n61), .B2(new_n63), .Y(new_n216));
  NOR2x1_ASAP7_75t_R   g158(.A(new_n215), .B(new_n216), .Y(po18));
  AOI21x1_ASAP7_75t_R  g159(.A1(pi21), .A2(new_n211), .B(new_n89), .Y(new_n218));
  AO32x1_ASAP7_75t_R   g160(.A1(pi21), .A2(new_n211), .A3(new_n89), .B1(new_n61), .B2(new_n63), .Y(new_n219));
  NOR2x1_ASAP7_75t_R   g161(.A(new_n218), .B(new_n219), .Y(po19));
  AOI21x1_ASAP7_75t_R  g162(.A1(pi13), .A2(new_n211), .B(new_n99), .Y(new_n221));
  AO32x1_ASAP7_75t_R   g163(.A1(pi13), .A2(new_n211), .A3(new_n99), .B1(new_n61), .B2(new_n63), .Y(new_n222));
  NOR2x1_ASAP7_75t_R   g164(.A(new_n221), .B(new_n222), .Y(po20));
  AOI21x1_ASAP7_75t_R  g165(.A1(new_n147), .A2(new_n211), .B(new_n146), .Y(new_n224));
  AO32x1_ASAP7_75t_R   g166(.A1(new_n146), .A2(new_n211), .A3(new_n147), .B1(new_n61), .B2(new_n63), .Y(new_n225));
  NOR2x1_ASAP7_75t_R   g167(.A(new_n224), .B(new_n225), .Y(po21));
  AND2x2_ASAP7_75t_R   g168(.A(new_n183), .B(new_n61), .Y(new_n227));
  AOI211x1_ASAP7_75t_R g169(.A1(new_n61), .A2(new_n68), .B(new_n125), .C(new_n126), .Y(new_n228));
  XOR2x2_ASAP7_75t_R   g170(.A(new_n227), .B(new_n228), .Y(new_n229));
  AO21x1_ASAP7_75t_R   g171(.A1(pi31), .A2(pi32), .B(pi02), .Y(new_n230));
  XNOR2x2_ASAP7_75t_R  g172(.A(new_n230), .B(new_n229), .Y(po22));
  AND2x2_ASAP7_75t_R   g173(.A(new_n189), .B(new_n61), .Y(new_n232));
  AOI21x1_ASAP7_75t_R  g174(.A1(new_n79), .A2(new_n155), .B(new_n70), .Y(new_n233));
  OA21x2_ASAP7_75t_R   g175(.A1(new_n79), .A2(new_n155), .B(new_n233), .Y(new_n234));
  XOR2x2_ASAP7_75t_R   g176(.A(new_n232), .B(new_n234), .Y(new_n235));
  AO21x1_ASAP7_75t_R   g177(.A1(pi04), .A2(pi29), .B(pi02), .Y(new_n236));
  XNOR2x2_ASAP7_75t_R  g178(.A(new_n236), .B(new_n235), .Y(po23));
  AOI21x1_ASAP7_75t_R  g179(.A1(pi28), .A2(new_n211), .B(new_n161), .Y(new_n238));
  AO32x1_ASAP7_75t_R   g180(.A1(pi28), .A2(new_n211), .A3(new_n161), .B1(new_n61), .B2(new_n63), .Y(new_n239));
  NOR2x1_ASAP7_75t_R   g181(.A(new_n238), .B(new_n239), .Y(po24));
endmodule


