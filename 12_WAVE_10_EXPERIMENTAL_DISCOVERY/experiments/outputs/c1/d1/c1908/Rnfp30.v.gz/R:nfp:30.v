// Benchmark "/w/experiments/inputs/c1/c2/c1908" written by ABC on Fri Sep 25 10:27:00 2026

module \/w/experiments/inputs/c1/c2/c1908  ( 
    pi00, pi01, pi02, pi03, pi04, pi05, pi06, pi07, pi08, pi09, pi10, pi11,
    pi12, pi13, pi14, pi15, pi16, pi17, pi18, pi19, pi20, pi21, pi22, pi23,
    pi24, pi25, pi26, pi27, pi28, pi29, pi30, pi31, pi32,
    po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10, po11,
    po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22, po23,
    po24  );
  input  pi00, pi01, pi02, pi03, pi04, pi05, pi06, pi07, pi08, pi09,
    pi10, pi11, pi12, pi13, pi14, pi15, pi16, pi17, pi18, pi19, pi20, pi21,
    pi22, pi23, pi24, pi25, pi26, pi27, pi28, pi29, pi30, pi31, pi32;
  output po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10,
    po11, po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22,
    po23, po24;
  wire new_n59, new_n60, new_n61, new_n62, new_n63, new_n64, new_n65,
    new_n66, new_n67, new_n68, new_n69, new_n70, new_n71, new_n72, new_n73,
    new_n74, new_n75, new_n76, new_n77, new_n78, new_n79, new_n80, new_n81,
    new_n82, new_n83, new_n84, new_n85, new_n86, new_n87, new_n88, new_n89,
    new_n90, new_n91, new_n92, new_n93, new_n94, new_n95, new_n96, new_n97,
    new_n98, new_n99, new_n100, new_n101, new_n102, new_n103, new_n104,
    new_n105, new_n106, new_n107, new_n108, new_n109, new_n110, new_n111,
    new_n112, new_n113, new_n114, new_n115, new_n116, new_n117, new_n118,
    new_n119, new_n120, new_n121, new_n122, new_n123, new_n124, new_n125,
    new_n126, new_n127, new_n128, new_n129, new_n130, new_n131, new_n132,
    new_n133, new_n134, new_n135, new_n136, new_n137, new_n138, new_n139,
    new_n140, new_n141, new_n142, new_n143, new_n144, new_n145, new_n146,
    new_n147, new_n148, new_n149, new_n150, new_n151, new_n152, new_n153,
    new_n154, new_n155, new_n156, new_n157, new_n158, new_n159, new_n160,
    new_n161, new_n162, new_n163, new_n164, new_n165, new_n166, new_n167,
    new_n168, new_n170, new_n171, new_n172, new_n173, new_n174, new_n180,
    new_n184, new_n185, new_n186, new_n191, new_n195, new_n196, new_n197,
    new_n198, new_n199, new_n200, new_n201, new_n203, new_n204, new_n205,
    new_n206, new_n208, new_n209, new_n211, new_n212, new_n214, new_n215,
    new_n217, new_n218, new_n220, new_n221, new_n222, new_n223, new_n225,
    new_n226, new_n227, new_n228, new_n229, new_n231, new_n232;
  INVx1_ASAP7_75t_R    g000(.A(pi00), .Y(new_n59));
  INVx1_ASAP7_75t_R    g001(.A(pi01), .Y(new_n60));
  INVx1_ASAP7_75t_R    g002(.A(pi02), .Y(new_n61));
  INVx1_ASAP7_75t_R    g003(.A(pi03), .Y(new_n62));
  INVx1_ASAP7_75t_R    g004(.A(pi05), .Y(new_n63));
  INVx1_ASAP7_75t_R    g005(.A(pi19), .Y(new_n64));
  INVx1_ASAP7_75t_R    g006(.A(pi23), .Y(new_n65));
  INVx1_ASAP7_75t_R    g007(.A(pi24), .Y(new_n66));
  INVx1_ASAP7_75t_R    g008(.A(pi25), .Y(new_n67));
  INVx1_ASAP7_75t_R    g009(.A(pi26), .Y(new_n68));
  INVx1_ASAP7_75t_R    g010(.A(pi32), .Y(new_n69));
  OA211x2_ASAP7_75t_R  g011(.A1(pi00), .A2(new_n60), .B(new_n61), .C(new_n63), .Y(new_n70));
  NOR2x1_ASAP7_75t_R   g012(.A(pi02), .B(pi04), .Y(new_n71));
  OA21x2_ASAP7_75t_R   g013(.A1(new_n60), .A2(pi00), .B(new_n62), .Y(new_n72));
  AO21x1_ASAP7_75t_R   g014(.A1(new_n71), .A2(new_n72), .B(new_n70), .Y(new_n73));
  XOR2x2_ASAP7_75t_R   g015(.A(pi09), .B(pi18), .Y(new_n74));
  XOR2x2_ASAP7_75t_R   g016(.A(pi06), .B(pi19), .Y(new_n75));
  XOR2x2_ASAP7_75t_R   g017(.A(new_n75), .B(pi20), .Y(new_n76));
  AND3x1_ASAP7_75t_R   g018(.A(new_n60), .B(new_n61), .C(pi17), .Y(new_n77));
  OR2x4_ASAP7_75t_R    g019(.A(pi14), .B(pi15), .Y(new_n78));
  NAND2x1_ASAP7_75t_R  g020(.A(pi14), .B(pi15), .Y(new_n79));
  AND2x2_ASAP7_75t_R   g021(.A(new_n78), .B(new_n79), .Y(new_n80));
  AO21x1_ASAP7_75t_R   g022(.A1(new_n78), .A2(new_n79), .B(pi16), .Y(new_n81));
  NAND3x1_ASAP7_75t_R  g023(.A(new_n78), .B(new_n79), .C(pi16), .Y(new_n82));
  NAND2x1_ASAP7_75t_R  g024(.A(new_n81), .B(new_n82), .Y(new_n83));
  XOR2x2_ASAP7_75t_R   g025(.A(new_n83), .B(new_n77), .Y(new_n84));
  XOR2x2_ASAP7_75t_R   g026(.A(new_n84), .B(new_n76), .Y(new_n85));
  XOR2x2_ASAP7_75t_R   g027(.A(new_n85), .B(new_n74), .Y(new_n86));
  OR3x1_ASAP7_75t_R    g028(.A(new_n86), .B(pi21), .C(pi03), .Y(new_n87));
  OAI21x1_ASAP7_75t_R  g029(.A1(pi03), .A2(new_n86), .B(pi21), .Y(new_n88));
  XNOR2x2_ASAP7_75t_R  g030(.A(pi09), .B(pi10), .Y(new_n89));
  NOR2x1_ASAP7_75t_R   g031(.A(pi00), .B(pi02), .Y(new_n90));
  AND3x1_ASAP7_75t_R   g032(.A(new_n59), .B(new_n61), .C(pi12), .Y(new_n91));
  XOR2x2_ASAP7_75t_R   g033(.A(pi06), .B(pi07), .Y(new_n92));
  XOR2x2_ASAP7_75t_R   g034(.A(pi08), .B(pi11), .Y(new_n93));
  XOR2x2_ASAP7_75t_R   g035(.A(new_n92), .B(new_n93), .Y(new_n94));
  XOR2x2_ASAP7_75t_R   g036(.A(new_n94), .B(new_n91), .Y(new_n95));
  XOR2x2_ASAP7_75t_R   g037(.A(new_n95), .B(new_n89), .Y(new_n96));
  OR3x1_ASAP7_75t_R    g038(.A(new_n96), .B(pi13), .C(pi03), .Y(new_n97));
  OAI21x1_ASAP7_75t_R  g039(.A1(pi03), .A2(new_n96), .B(pi13), .Y(new_n98));
  AND3x1_ASAP7_75t_R   g040(.A(new_n88), .B(new_n97), .C(new_n98), .Y(new_n99));
  NAND2x1_ASAP7_75t_R  g041(.A(new_n87), .B(new_n99), .Y(new_n100));
  INVx1_ASAP7_75t_R    g042(.A(new_n100), .Y(new_n101));
  AND3x1_ASAP7_75t_R   g043(.A(new_n99), .B(new_n87), .C(new_n73), .Y(new_n102));
  OA21x2_ASAP7_75t_R   g044(.A1(pi01), .A2(pi03), .B(pi27), .Y(new_n103));
  INVx1_ASAP7_75t_R    g045(.A(new_n103), .Y(new_n104));
  AND2x2_ASAP7_75t_R   g046(.A(new_n61), .B(pi31), .Y(new_n105));
  XOR2x2_ASAP7_75t_R   g047(.A(new_n105), .B(pi14), .Y(new_n106));
  XOR2x2_ASAP7_75t_R   g048(.A(pi09), .B(pi16), .Y(new_n107));
  XOR2x2_ASAP7_75t_R   g049(.A(new_n107), .B(pi10), .Y(new_n108));
  INVx1_ASAP7_75t_R    g050(.A(new_n108), .Y(new_n109));
  XOR2x2_ASAP7_75t_R   g051(.A(pi06), .B(pi23), .Y(new_n110));
  INVx1_ASAP7_75t_R    g052(.A(new_n110), .Y(new_n111));
  XOR2x2_ASAP7_75t_R   g053(.A(pi07), .B(pi22), .Y(new_n112));
  XOR2x2_ASAP7_75t_R   g054(.A(new_n112), .B(pi19), .Y(new_n113));
  XOR2x2_ASAP7_75t_R   g055(.A(pi08), .B(pi20), .Y(new_n114));
  OR2x4_ASAP7_75t_R    g056(.A(new_n68), .B(new_n114), .Y(new_n115));
  NAND2x1_ASAP7_75t_R  g057(.A(new_n68), .B(new_n114), .Y(new_n116));
  XOR2x2_ASAP7_75t_R   g058(.A(new_n114), .B(new_n68), .Y(new_n117));
  AO21x1_ASAP7_75t_R   g059(.A1(new_n115), .A2(new_n116), .B(new_n113), .Y(new_n118));
  NAND2x1_ASAP7_75t_R  g060(.A(new_n117), .B(new_n113), .Y(new_n119));
  AND3x1_ASAP7_75t_R   g061(.A(new_n118), .B(new_n119), .C(new_n111), .Y(new_n120));
  AOI21x1_ASAP7_75t_R  g062(.A1(new_n119), .A2(new_n118), .B(new_n111), .Y(new_n121));
  NOR2x1_ASAP7_75t_R   g063(.A(new_n121), .B(new_n120), .Y(new_n122));
  OA21x2_ASAP7_75t_R   g064(.A1(new_n120), .A2(new_n121), .B(new_n109), .Y(new_n123));
  NOR3x1_ASAP7_75t_R   g065(.A(new_n120), .B(new_n121), .C(new_n109), .Y(new_n124));
  OR3x1_ASAP7_75t_R    g066(.A(new_n124), .B(new_n123), .C(new_n106), .Y(new_n125));
  OAI21x1_ASAP7_75t_R  g067(.A1(new_n123), .A2(new_n124), .B(new_n106), .Y(new_n126));
  NAND2x1_ASAP7_75t_R  g068(.A(new_n126), .B(new_n125), .Y(new_n127));
  AND3x1_ASAP7_75t_R   g069(.A(new_n125), .B(new_n126), .C(new_n62), .Y(new_n128));
  XOR2x2_ASAP7_75t_R   g070(.A(new_n128), .B(new_n103), .Y(new_n129));
  XNOR2x2_ASAP7_75t_R  g071(.A(pi10), .B(pi22), .Y(new_n130));
  OR4x2_ASAP7_75t_R    g072(.A(new_n66), .B(pi25), .C(pi00), .D(pi02), .Y(new_n131));
  AO21x1_ASAP7_75t_R   g073(.A1(new_n90), .A2(pi24), .B(new_n67), .Y(new_n132));
  AOI21x1_ASAP7_75t_R  g074(.A1(new_n81), .A2(new_n82), .B(new_n65), .Y(new_n133));
  AND3x1_ASAP7_75t_R   g075(.A(new_n82), .B(new_n81), .C(new_n65), .Y(new_n134));
  OA211x2_ASAP7_75t_R  g076(.A1(new_n134), .A2(new_n133), .B(new_n132), .C(new_n131), .Y(new_n135));
  AOI211x1_ASAP7_75t_R g077(.A1(new_n131), .A2(new_n132), .B(new_n134), .C(new_n133), .Y(new_n136));
  NOR2x1_ASAP7_75t_R   g078(.A(new_n136), .B(new_n135), .Y(new_n137));
  XOR2x2_ASAP7_75t_R   g079(.A(new_n137), .B(new_n130), .Y(new_n138));
  OR2x4_ASAP7_75t_R    g080(.A(pi03), .B(new_n138), .Y(new_n139));
  OA21x2_ASAP7_75t_R   g081(.A1(pi00), .A2(pi03), .B(pi12), .Y(new_n140));
  XOR2x2_ASAP7_75t_R   g082(.A(new_n113), .B(new_n68), .Y(new_n141));
  XOR2x2_ASAP7_75t_R   g083(.A(pi11), .B(pi25), .Y(new_n142));
  XOR2x2_ASAP7_75t_R   g084(.A(new_n142), .B(pi18), .Y(new_n143));
  XOR2x2_ASAP7_75t_R   g085(.A(new_n108), .B(new_n143), .Y(new_n144));
  AND3x1_ASAP7_75t_R   g086(.A(new_n60), .B(new_n61), .C(pi27), .Y(new_n145));
  AND2x2_ASAP7_75t_R   g087(.A(new_n144), .B(new_n145), .Y(new_n146));
  NOR2x1_ASAP7_75t_R   g088(.A(new_n145), .B(new_n144), .Y(new_n147));
  OR3x1_ASAP7_75t_R    g089(.A(new_n147), .B(new_n146), .C(new_n141), .Y(new_n148));
  OAI21x1_ASAP7_75t_R  g090(.A1(new_n146), .A2(new_n147), .B(new_n141), .Y(new_n149));
  NAND2x1_ASAP7_75t_R  g091(.A(new_n149), .B(new_n148), .Y(new_n150));
  AO21x1_ASAP7_75t_R   g092(.A1(new_n148), .A2(new_n149), .B(pi03), .Y(new_n151));
  OAI22x1_ASAP7_75t_R  g093(.A1(pi28), .A2(new_n151), .B1(new_n139), .B2(new_n140), .Y(new_n152));
  AO22x1_ASAP7_75t_R   g094(.A1(new_n139), .A2(new_n140), .B1(new_n151), .B2(pi28), .Y(new_n153));
  OR2x4_ASAP7_75t_R    g095(.A(new_n152), .B(new_n153), .Y(new_n154));
  AO21x1_ASAP7_75t_R   g096(.A1(new_n59), .A2(new_n62), .B(new_n66), .Y(new_n155));
  AND2x2_ASAP7_75t_R   g097(.A(new_n61), .B(pi29), .Y(new_n156));
  XOR2x2_ASAP7_75t_R   g098(.A(new_n117), .B(new_n156), .Y(new_n157));
  XNOR2x2_ASAP7_75t_R  g099(.A(pi15), .B(pi23), .Y(new_n158));
  XOR2x2_ASAP7_75t_R   g100(.A(new_n144), .B(new_n158), .Y(new_n159));
  XOR2x2_ASAP7_75t_R   g101(.A(new_n159), .B(new_n157), .Y(new_n160));
  NAND2x1_ASAP7_75t_R  g102(.A(new_n62), .B(new_n160), .Y(new_n161));
  XOR2x2_ASAP7_75t_R   g103(.A(new_n161), .B(pi30), .Y(new_n162));
  NOR2x1_ASAP7_75t_R   g104(.A(new_n155), .B(new_n162), .Y(new_n163));
  OAI21x1_ASAP7_75t_R  g105(.A1(pi01), .A2(pi03), .B(pi17), .Y(new_n164));
  INVx1_ASAP7_75t_R    g106(.A(new_n164), .Y(new_n165));
  OR3x1_ASAP7_75t_R    g107(.A(new_n163), .B(new_n164), .C(new_n154), .Y(new_n166));
  NOR2x1_ASAP7_75t_R   g108(.A(new_n129), .B(new_n166), .Y(new_n167));
  NAND2x1_ASAP7_75t_R  g109(.A(new_n102), .B(new_n167), .Y(new_n168));
  XOR2x2_ASAP7_75t_R   g110(.A(new_n168), .B(pi15), .Y(po00));
  AND3x1_ASAP7_75t_R   g111(.A(new_n72), .B(new_n69), .C(new_n61), .Y(new_n170));
  OA211x2_ASAP7_75t_R  g112(.A1(new_n70), .A2(new_n170), .B(new_n99), .C(new_n87), .Y(new_n171));
  AOI21x1_ASAP7_75t_R  g113(.A1(new_n165), .A2(new_n129), .B(new_n154), .Y(new_n172));
  OA21x2_ASAP7_75t_R   g114(.A1(new_n155), .A2(new_n162), .B(new_n172), .Y(new_n173));
  AND2x2_ASAP7_75t_R   g115(.A(new_n173), .B(new_n171), .Y(new_n174));
  XOR2x2_ASAP7_75t_R   g116(.A(new_n174), .B(new_n68), .Y(po01));
  XNOR2x2_ASAP7_75t_R  g117(.A(pi20), .B(new_n174), .Y(po02));
  XOR2x2_ASAP7_75t_R   g118(.A(new_n168), .B(pi25), .Y(po03));
  XNOR2x2_ASAP7_75t_R  g119(.A(pi08), .B(new_n174), .Y(po04));
  XOR2x2_ASAP7_75t_R   g120(.A(new_n174), .B(new_n65), .Y(po05));
  AND2x2_ASAP7_75t_R   g121(.A(new_n173), .B(new_n102), .Y(new_n180));
  XNOR2x2_ASAP7_75t_R  g122(.A(pi10), .B(new_n180), .Y(po06));
  XNOR2x2_ASAP7_75t_R  g123(.A(pi09), .B(new_n180), .Y(po07));
  XNOR2x2_ASAP7_75t_R  g124(.A(pi16), .B(new_n180), .Y(po08));
  OA211x2_ASAP7_75t_R  g125(.A1(pi00), .A2(pi03), .B(new_n162), .C(pi24), .Y(new_n184));
  AND2x2_ASAP7_75t_R   g126(.A(new_n184), .B(new_n172), .Y(new_n185));
  AND3x1_ASAP7_75t_R   g127(.A(new_n171), .B(new_n172), .C(new_n184), .Y(new_n186));
  XOR2x2_ASAP7_75t_R   g128(.A(new_n186), .B(new_n64), .Y(po09));
  XNOR2x2_ASAP7_75t_R  g129(.A(pi07), .B(new_n186), .Y(po10));
  XNOR2x2_ASAP7_75t_R  g130(.A(pi22), .B(new_n186), .Y(po11));
  XNOR2x2_ASAP7_75t_R  g131(.A(pi06), .B(new_n186), .Y(po12));
  AND3x1_ASAP7_75t_R   g132(.A(new_n102), .B(new_n172), .C(new_n184), .Y(new_n191));
  XNOR2x2_ASAP7_75t_R  g133(.A(pi14), .B(new_n191), .Y(po13));
  XOR2x2_ASAP7_75t_R   g134(.A(new_n168), .B(pi18), .Y(po14));
  XOR2x2_ASAP7_75t_R   g135(.A(new_n168), .B(pi11), .Y(po15));
  AO21x1_ASAP7_75t_R   g136(.A1(new_n102), .A2(new_n173), .B(new_n174), .Y(new_n195));
  OA211x2_ASAP7_75t_R  g137(.A1(new_n167), .A2(new_n185), .B(new_n70), .C(new_n101), .Y(new_n196));
  OA21x2_ASAP7_75t_R   g138(.A1(new_n196), .A2(new_n195), .B(pi05), .Y(new_n197));
  AND3x1_ASAP7_75t_R   g139(.A(new_n162), .B(new_n164), .C(new_n155), .Y(new_n198));
  INVx1_ASAP7_75t_R    g140(.A(new_n198), .Y(new_n199));
  OR4x2_ASAP7_75t_R    g141(.A(new_n199), .B(new_n154), .C(new_n129), .D(new_n100), .Y(new_n200));
  INVx1_ASAP7_75t_R    g142(.A(new_n200), .Y(new_n201));
  OR3x1_ASAP7_75t_R    g143(.A(new_n197), .B(new_n201), .C(pi02), .Y(po16));
  AND2x2_ASAP7_75t_R   g144(.A(new_n195), .B(new_n62), .Y(new_n203));
  OAI21x1_ASAP7_75t_R  g145(.A1(new_n174), .A2(new_n180), .B(new_n62), .Y(new_n204));
  OAI21x1_ASAP7_75t_R  g146(.A1(new_n104), .A2(new_n204), .B(new_n127), .Y(new_n205));
  OR3x1_ASAP7_75t_R    g147(.A(new_n204), .B(new_n127), .C(new_n104), .Y(new_n206));
  OA211x2_ASAP7_75t_R  g148(.A1(pi02), .A2(pi05), .B(new_n206), .C(new_n205), .Y(po17));
  AOI21x1_ASAP7_75t_R  g149(.A1(pi30), .A2(new_n203), .B(new_n160), .Y(new_n208));
  AO32x1_ASAP7_75t_R   g150(.A1(pi30), .A2(new_n203), .A3(new_n160), .B1(new_n61), .B2(new_n63), .Y(new_n209));
  NOR2x1_ASAP7_75t_R   g151(.A(new_n208), .B(new_n209), .Y(po18));
  AOI21x1_ASAP7_75t_R  g152(.A1(pi21), .A2(new_n203), .B(new_n86), .Y(new_n211));
  AO32x1_ASAP7_75t_R   g153(.A1(pi21), .A2(new_n203), .A3(new_n86), .B1(new_n61), .B2(new_n63), .Y(new_n212));
  NOR2x1_ASAP7_75t_R   g154(.A(new_n211), .B(new_n212), .Y(po19));
  AOI21x1_ASAP7_75t_R  g155(.A1(pi13), .A2(new_n203), .B(new_n96), .Y(new_n214));
  AO32x1_ASAP7_75t_R   g156(.A1(pi13), .A2(new_n203), .A3(new_n96), .B1(new_n61), .B2(new_n63), .Y(new_n215));
  NOR2x1_ASAP7_75t_R   g157(.A(new_n214), .B(new_n215), .Y(po20));
  AOI21x1_ASAP7_75t_R  g158(.A1(new_n140), .A2(new_n203), .B(new_n138), .Y(new_n217));
  AO32x1_ASAP7_75t_R   g159(.A1(new_n138), .A2(new_n203), .A3(new_n140), .B1(new_n61), .B2(new_n63), .Y(new_n218));
  NOR2x1_ASAP7_75t_R   g160(.A(new_n217), .B(new_n218), .Y(po21));
  AND3x1_ASAP7_75t_R   g161(.A(new_n173), .B(new_n171), .C(new_n61), .Y(new_n220));
  OA21x2_ASAP7_75t_R   g162(.A1(pi02), .A2(pi32), .B(new_n122), .Y(new_n221));
  XNOR2x2_ASAP7_75t_R  g163(.A(new_n221), .B(new_n220), .Y(new_n222));
  AO21x1_ASAP7_75t_R   g164(.A1(pi31), .A2(pi32), .B(pi02), .Y(new_n223));
  XOR2x2_ASAP7_75t_R   g165(.A(new_n222), .B(new_n223), .Y(po22));
  AND3x1_ASAP7_75t_R   g166(.A(new_n173), .B(new_n102), .C(new_n61), .Y(new_n225));
  AOI21x1_ASAP7_75t_R  g167(.A1(new_n80), .A2(new_n144), .B(new_n71), .Y(new_n226));
  OA21x2_ASAP7_75t_R   g168(.A1(new_n80), .A2(new_n144), .B(new_n226), .Y(new_n227));
  XNOR2x2_ASAP7_75t_R  g169(.A(new_n227), .B(new_n225), .Y(new_n228));
  AO21x1_ASAP7_75t_R   g170(.A1(pi04), .A2(pi29), .B(pi02), .Y(new_n229));
  XOR2x2_ASAP7_75t_R   g171(.A(new_n228), .B(new_n229), .Y(po23));
  AOI21x1_ASAP7_75t_R  g172(.A1(pi28), .A2(new_n203), .B(new_n150), .Y(new_n231));
  AO32x1_ASAP7_75t_R   g173(.A1(pi28), .A2(new_n203), .A3(new_n150), .B1(new_n61), .B2(new_n63), .Y(new_n232));
  NOR2x1_ASAP7_75t_R   g174(.A(new_n231), .B(new_n232), .Y(po24));
endmodule


