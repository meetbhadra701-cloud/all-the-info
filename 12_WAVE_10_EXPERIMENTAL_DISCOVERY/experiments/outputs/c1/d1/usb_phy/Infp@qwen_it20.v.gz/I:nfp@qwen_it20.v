// Benchmark "/w/experiments/inputs/c1/c2/usb_phy" written by ABC on Fri Sep 25 09:43:46 2026

module \/w/experiments/inputs/c1/c2/usb_phy  ( 
    pi000, pi001, pi002, pi003, pi004, pi005, pi006, pi007, pi008, pi009,
    pi010, pi011, pi012, pi013, pi014, pi015, pi016, pi017, pi018, pi019,
    pi020, pi021, pi022, pi023, pi024, pi025, pi026, pi027, pi028, pi029,
    pi030, pi031, pi032, pi033, pi034, pi035, pi036, pi037, pi038, pi039,
    pi040, pi041, pi042, pi043, pi044, pi045, pi046, pi047, pi048, pi049,
    pi050, pi051, pi052, pi053, pi054, pi055, pi056, pi057, pi058, pi059,
    pi060, pi061, pi062, pi063, pi064, pi065, pi066, pi067, pi068, pi069,
    pi070, pi071, pi072, pi073, pi074, pi075, pi076, pi077, pi078, pi079,
    pi080, pi081, pi082, pi083, pi084, pi085, pi086, pi087, pi088, pi089,
    pi090, pi091, pi092, pi093, pi094, pi095, pi096, pi097, pi098, pi099,
    pi100, pi101, pi102, pi103, pi104, pi105, pi106, pi107, pi108, pi109,
    pi110, pi111, pi112, pi113, pi114, pi115, pi116, pi117, pi118, pi119,
    pi120, pi121, pi122, pi123, pi124, pi125, pi126, pi127, pi128, pi129,
    pi130, pi131, pi132, pi133, pi134, pi135, pi136, pi137, pi138, pi139,
    pi140, pi141, pi142, pi143, pi144, pi145, pi146, pi147, pi148, pi149,
    pi150, pi151, pi152, pi153, pi154, pi155, pi156, pi157, pi158, pi159,
    pi160, pi161, pi162, pi163, pi164, pi165, pi166, pi167, pi168, pi169,
    pi170, pi171, pi172, pi173, pi174, pi175, pi176, pi177, pi178, pi179,
    pi180, pi181, pi182, pi183, pi184, pi185, pi186, pi187, pi188, pi189,
    pi190, pi191, pi192, pi193, pi194, pi195, pi196, pi197, pi198, pi199,
    pi200, pi201, pi202, pi203, pi204, pi205, pi206, pi207, pi208, pi209,
    pi210,
    po000, po001, po002, po003, po004, po005, po006, po007, po008, po009,
    po010, po011, po012, po013, po014, po015, po016, po017, po018, po019,
    po020, po021, po022, po023, po024, po025, po026, po027, po028, po029,
    po030, po031, po032, po033, po034, po035, po036, po037, po038, po039,
    po040, po041, po042, po043, po044, po045, po046, po047, po048, po049,
    po050, po051, po052, po053, po054, po055, po056, po057, po058, po059,
    po060, po061, po062, po063, po064, po065, po066, po067, po068, po069,
    po070, po071, po072, po073, po074, po075, po076, po077, po078, po079,
    po080, po081, po082, po083, po084, po085, po086, po087, po088, po089,
    po090, po091, po092, po093, po094, po095, po096, po097, po098, po099,
    po100, po101, po102, po103, po104, po105, po106, po107, po108, po109,
    po110  );
  input  pi000, pi001, pi002, pi003, pi004, pi005, pi006, pi007, pi008,
    pi009, pi010, pi011, pi012, pi013, pi014, pi015, pi016, pi017, pi018,
    pi019, pi020, pi021, pi022, pi023, pi024, pi025, pi026, pi027, pi028,
    pi029, pi030, pi031, pi032, pi033, pi034, pi035, pi036, pi037, pi038,
    pi039, pi040, pi041, pi042, pi043, pi044, pi045, pi046, pi047, pi048,
    pi049, pi050, pi051, pi052, pi053, pi054, pi055, pi056, pi057, pi058,
    pi059, pi060, pi061, pi062, pi063, pi064, pi065, pi066, pi067, pi068,
    pi069, pi070, pi071, pi072, pi073, pi074, pi075, pi076, pi077, pi078,
    pi079, pi080, pi081, pi082, pi083, pi084, pi085, pi086, pi087, pi088,
    pi089, pi090, pi091, pi092, pi093, pi094, pi095, pi096, pi097, pi098,
    pi099, pi100, pi101, pi102, pi103, pi104, pi105, pi106, pi107, pi108,
    pi109, pi110, pi111, pi112, pi113, pi114, pi115, pi116, pi117, pi118,
    pi119, pi120, pi121, pi122, pi123, pi124, pi125, pi126, pi127, pi128,
    pi129, pi130, pi131, pi132, pi133, pi134, pi135, pi136, pi137, pi138,
    pi139, pi140, pi141, pi142, pi143, pi144, pi145, pi146, pi147, pi148,
    pi149, pi150, pi151, pi152, pi153, pi154, pi155, pi156, pi157, pi158,
    pi159, pi160, pi161, pi162, pi163, pi164, pi165, pi166, pi167, pi168,
    pi169, pi170, pi171, pi172, pi173, pi174, pi175, pi176, pi177, pi178,
    pi179, pi180, pi181, pi182, pi183, pi184, pi185, pi186, pi187, pi188,
    pi189, pi190, pi191, pi192, pi193, pi194, pi195, pi196, pi197, pi198,
    pi199, pi200, pi201, pi202, pi203, pi204, pi205, pi206, pi207, pi208,
    pi209, pi210;
  output po000, po001, po002, po003, po004, po005, po006, po007, po008, po009,
    po010, po011, po012, po013, po014, po015, po016, po017, po018, po019,
    po020, po021, po022, po023, po024, po025, po026, po027, po028, po029,
    po030, po031, po032, po033, po034, po035, po036, po037, po038, po039,
    po040, po041, po042, po043, po044, po045, po046, po047, po048, po049,
    po050, po051, po052, po053, po054, po055, po056, po057, po058, po059,
    po060, po061, po062, po063, po064, po065, po066, po067, po068, po069,
    po070, po071, po072, po073, po074, po075, po076, po077, po078, po079,
    po080, po081, po082, po083, po084, po085, po086, po087, po088, po089,
    po090, po091, po092, po093, po094, po095, po096, po097, po098, po099,
    po100, po101, po102, po103, po104, po105, po106, po107, po108, po109,
    po110;
  wire new_n324, new_n325, new_n326, new_n327, new_n328, new_n329, new_n330,
    new_n331, new_n332, new_n333, new_n334, new_n335, new_n336, new_n337,
    new_n338, new_n339, new_n340, new_n341, new_n342, new_n343, new_n344,
    new_n345, new_n346, new_n347, new_n348, new_n349, new_n350, new_n351,
    new_n352, new_n353, new_n354, new_n355, new_n356, new_n357, new_n358,
    new_n359, new_n360, new_n361, new_n362, new_n363, new_n364, new_n365,
    new_n366, new_n367, new_n369, new_n371, new_n372, new_n373, new_n374,
    new_n375, new_n376, new_n377, new_n378, new_n380, new_n381, new_n382,
    new_n384, new_n385, new_n387, new_n388, new_n389, new_n390, new_n391,
    new_n393, new_n394, new_n395, new_n397, new_n398, new_n399, new_n401,
    new_n403, new_n404, new_n405, new_n406, new_n408, new_n410, new_n412,
    new_n414, new_n416, new_n418, new_n420, new_n422, new_n425, new_n426,
    new_n427, new_n428, new_n429, new_n430, new_n431, new_n432, new_n434,
    new_n435, new_n437, new_n439, new_n440, new_n442, new_n443, new_n444,
    new_n445, new_n446, new_n448, new_n451, new_n452, new_n453, new_n454,
    new_n455, new_n456, new_n457, new_n460, new_n462, new_n464, new_n465,
    new_n467, new_n468, new_n469, new_n470, new_n471, new_n472, new_n474,
    new_n475, new_n477, new_n478, new_n479, new_n480, new_n481, new_n482,
    new_n483, new_n484, new_n485, new_n486, new_n487, new_n488, new_n489,
    new_n491, new_n493, new_n494, new_n495, new_n496, new_n498, new_n499,
    new_n500, new_n502, new_n504, new_n506, new_n508, new_n510, new_n512,
    new_n513, new_n514, new_n515, new_n517, new_n518, new_n520, new_n521,
    new_n523, new_n524, new_n526, new_n528, new_n532, new_n534, new_n536,
    new_n537, new_n538, new_n540, new_n541, new_n542, new_n544, new_n546,
    new_n548, new_n549, new_n550, new_n552, new_n553, new_n555, new_n556,
    new_n562, new_n564, new_n566, new_n568, new_n570, new_n572, new_n573,
    new_n574, new_n576, new_n579;
  INVx1_ASAP7_75t_R    g000(.A(pi009), .Y(new_n324));
  INVx1_ASAP7_75t_R    g001(.A(pi011), .Y(new_n325));
  INVx1_ASAP7_75t_R    g002(.A(pi019), .Y(new_n326));
  INVx1_ASAP7_75t_R    g003(.A(pi021), .Y(new_n327));
  INVx1_ASAP7_75t_R    g004(.A(pi023), .Y(new_n328));
  INVx1_ASAP7_75t_R    g005(.A(pi025), .Y(new_n329));
  INVx1_ASAP7_75t_R    g006(.A(pi027), .Y(new_n330));
  INVx1_ASAP7_75t_R    g007(.A(pi029), .Y(new_n331));
  INVx1_ASAP7_75t_R    g008(.A(pi031), .Y(new_n332));
  INVx1_ASAP7_75t_R    g009(.A(pi033), .Y(new_n333));
  INVx1_ASAP7_75t_R    g010(.A(pi035), .Y(new_n334));
  INVx1_ASAP7_75t_R    g011(.A(pi039), .Y(new_n335));
  INVx1_ASAP7_75t_R    g012(.A(pi043), .Y(new_n336));
  INVx1_ASAP7_75t_R    g013(.A(pi055), .Y(new_n337));
  INVx1_ASAP7_75t_R    g014(.A(pi057), .Y(new_n338));
  INVx1_ASAP7_75t_R    g015(.A(pi059), .Y(new_n339));
  INVx1_ASAP7_75t_R    g016(.A(pi065), .Y(new_n340));
  INVx1_ASAP7_75t_R    g017(.A(pi069), .Y(new_n341));
  INVx1_ASAP7_75t_R    g018(.A(pi079), .Y(new_n342));
  INVx1_ASAP7_75t_R    g019(.A(pi083), .Y(new_n343));
  INVx1_ASAP7_75t_R    g020(.A(pi085), .Y(new_n344));
  INVx1_ASAP7_75t_R    g021(.A(pi087), .Y(new_n345));
  INVx1_ASAP7_75t_R    g022(.A(pi107), .Y(new_n346));
  INVx1_ASAP7_75t_R    g023(.A(pi111), .Y(new_n347));
  INVx1_ASAP7_75t_R    g024(.A(pi121), .Y(new_n348));
  INVx1_ASAP7_75t_R    g025(.A(pi123), .Y(new_n349));
  INVx1_ASAP7_75t_R    g026(.A(pi125), .Y(new_n350));
  INVx1_ASAP7_75t_R    g027(.A(pi129), .Y(new_n351));
  INVx1_ASAP7_75t_R    g028(.A(pi137), .Y(new_n352));
  INVx1_ASAP7_75t_R    g029(.A(pi141), .Y(new_n353));
  INVx1_ASAP7_75t_R    g030(.A(pi147), .Y(new_n354));
  INVx1_ASAP7_75t_R    g031(.A(pi155), .Y(new_n355));
  INVx1_ASAP7_75t_R    g032(.A(pi156), .Y(new_n356));
  INVx1_ASAP7_75t_R    g033(.A(pi158), .Y(new_n357));
  INVx1_ASAP7_75t_R    g034(.A(pi166), .Y(new_n358));
  INVx1_ASAP7_75t_R    g035(.A(pi176), .Y(new_n359));
  INVx1_ASAP7_75t_R    g036(.A(pi183), .Y(new_n360));
  INVx1_ASAP7_75t_R    g037(.A(pi185), .Y(new_n361));
  INVx1_ASAP7_75t_R    g038(.A(pi191), .Y(new_n362));
  INVx1_ASAP7_75t_R    g039(.A(pi197), .Y(new_n363));
  INVx1_ASAP7_75t_R    g040(.A(pi198), .Y(new_n364));
  INVx1_ASAP7_75t_R    g041(.A(pi202), .Y(new_n365));
  INVx1_ASAP7_75t_R    g042(.A(pi210), .Y(new_n366));
  AND3x1_ASAP7_75t_R   g043(.A(pi006), .B(pi012), .C(pi016), .Y(new_n367));
  INVx1_ASAP7_75t_R    g044(.A(new_n367), .Y(po007));
  AND2x2_ASAP7_75t_R   g045(.A(pi003), .B(pi011), .Y(new_n369));
  NOR2x1_ASAP7_75t_R   g046(.A(pi125), .B(pi127), .Y(po043));
  INVx1_ASAP7_75t_R    g047(.A(po043), .Y(new_n371));
  OA21x2_ASAP7_75t_R   g048(.A1(pi125), .A2(pi127), .B(pi147), .Y(new_n372));
  NOR2x1_ASAP7_75t_R   g049(.A(pi005), .B(pi033), .Y(new_n373));
  AND2x2_ASAP7_75t_R   g050(.A(new_n373), .B(new_n372), .Y(new_n374));
  AND3x1_ASAP7_75t_R   g051(.A(new_n373), .B(new_n372), .C(new_n369), .Y(new_n375));
  OR3x1_ASAP7_75t_R    g052(.A(new_n350), .B(new_n354), .C(pi127), .Y(new_n376));
  AOI21x1_ASAP7_75t_R  g053(.A1(new_n324), .A2(new_n362), .B(new_n376), .Y(new_n377));
  AND2x2_ASAP7_75t_R   g054(.A(pi005), .B(pi147), .Y(new_n378));
  AO221x2_ASAP7_75t_R  g055(.A1(pi001), .A2(new_n354), .B1(new_n375), .B2(new_n377), .C(new_n378), .Y(po020));
  OR3x1_ASAP7_75t_R    g056(.A(new_n350), .B(new_n362), .C(pi127), .Y(new_n380));
  INVx1_ASAP7_75t_R    g057(.A(new_n380), .Y(new_n381));
  OAI21x1_ASAP7_75t_R  g058(.A1(pi003), .A2(new_n380), .B(new_n374), .Y(new_n382));
  OA211x2_ASAP7_75t_R  g059(.A1(pi003), .A2(new_n374), .B(new_n382), .C(pi197), .Y(po021));
  NAND2x1_ASAP7_75t_R  g060(.A(pi045), .B(po043), .Y(new_n384));
  AO32x1_ASAP7_75t_R   g061(.A1(new_n369), .A2(new_n381), .A3(new_n374), .B1(pi005), .B2(new_n384), .Y(new_n385));
  AND2x2_ASAP7_75t_R   g062(.A(new_n385), .B(pi197), .Y(po022));
  AND3x1_ASAP7_75t_R   g063(.A(new_n350), .B(pi127), .C(pi191), .Y(new_n387));
  NAND2x1_ASAP7_75t_R  g064(.A(pi003), .B(new_n325), .Y(new_n388));
  NOR2x1_ASAP7_75t_R   g065(.A(new_n388), .B(new_n387), .Y(new_n389));
  OAI21x1_ASAP7_75t_R  g066(.A1(pi009), .A2(new_n387), .B(pi003), .Y(new_n390));
  OA211x2_ASAP7_75t_R  g067(.A1(pi009), .A2(pi011), .B(new_n390), .C(new_n380), .Y(new_n391));
  OA21x2_ASAP7_75t_R   g068(.A1(new_n391), .A2(new_n389), .B(new_n374), .Y(po023));
  AND2x2_ASAP7_75t_R   g069(.A(new_n382), .B(pi009), .Y(new_n393));
  AND5x1_ASAP7_75t_R   g070(.A(new_n373), .B(pi147), .C(pi127), .D(new_n350), .E(pi191), .Y(new_n394));
  AND3x1_ASAP7_75t_R   g071(.A(new_n394), .B(new_n324), .C(pi003), .Y(new_n395));
  OA21x2_ASAP7_75t_R   g072(.A1(new_n393), .A2(new_n395), .B(pi197), .Y(po024));
  AO21x1_ASAP7_75t_R   g073(.A1(new_n325), .A2(pi003), .B(new_n324), .Y(new_n397));
  OA21x2_ASAP7_75t_R   g074(.A1(pi009), .A2(new_n369), .B(new_n397), .Y(new_n398));
  AO22x1_ASAP7_75t_R   g075(.A1(new_n382), .A2(pi011), .B1(new_n398), .B2(new_n394), .Y(new_n399));
  AND2x2_ASAP7_75t_R   g076(.A(new_n399), .B(pi197), .Y(po025));
  AND3x1_ASAP7_75t_R   g077(.A(po043), .B(pi046), .C(pi005), .Y(new_n401));
  OA21x2_ASAP7_75t_R   g078(.A1(pi063), .A2(pi073), .B(new_n401), .Y(po026));
  NOR2x1_ASAP7_75t_R   g079(.A(pi035), .B(pi039), .Y(new_n403));
  OR4x2_ASAP7_75t_R    g080(.A(new_n365), .B(pi055), .C(pi039), .D(pi035), .Y(new_n404));
  NAND2x1_ASAP7_75t_R  g081(.A(pi015), .B(pi074), .Y(new_n405));
  OA211x2_ASAP7_75t_R  g082(.A1(pi074), .A2(new_n366), .B(new_n404), .C(new_n405), .Y(new_n406));
  INVx1_ASAP7_75t_R    g083(.A(new_n406), .Y(po027));
  AND3x1_ASAP7_75t_R   g084(.A(new_n341), .B(pi059), .C(pi057), .Y(new_n408));
  AND4x2_ASAP7_75t_R   g085(.A(new_n408), .B(new_n378), .C(new_n371), .D(pi113), .Y(po028));
  NAND2x1_ASAP7_75t_R  g086(.A(pi074), .B(new_n326), .Y(new_n410));
  OA211x2_ASAP7_75t_R  g087(.A1(pi074), .A2(pi203), .B(new_n404), .C(new_n410), .Y(po029));
  NAND2x1_ASAP7_75t_R  g088(.A(pi074), .B(new_n327), .Y(new_n412));
  OA211x2_ASAP7_75t_R  g089(.A1(pi074), .A2(pi204), .B(new_n404), .C(new_n412), .Y(po030));
  NAND2x1_ASAP7_75t_R  g090(.A(pi074), .B(new_n328), .Y(new_n414));
  OA211x2_ASAP7_75t_R  g091(.A1(pi074), .A2(pi205), .B(new_n404), .C(new_n414), .Y(po031));
  NAND2x1_ASAP7_75t_R  g092(.A(pi074), .B(new_n329), .Y(new_n416));
  OA211x2_ASAP7_75t_R  g093(.A1(pi074), .A2(pi206), .B(new_n404), .C(new_n416), .Y(po032));
  NAND2x1_ASAP7_75t_R  g094(.A(pi074), .B(new_n330), .Y(new_n418));
  OA211x2_ASAP7_75t_R  g095(.A1(pi074), .A2(pi207), .B(new_n404), .C(new_n418), .Y(po033));
  NAND2x1_ASAP7_75t_R  g096(.A(pi074), .B(new_n331), .Y(new_n420));
  OA211x2_ASAP7_75t_R  g097(.A1(pi074), .A2(pi208), .B(new_n404), .C(new_n420), .Y(po034));
  NAND2x1_ASAP7_75t_R  g098(.A(pi074), .B(new_n332), .Y(new_n422));
  OA211x2_ASAP7_75t_R  g099(.A1(pi074), .A2(pi209), .B(new_n404), .C(new_n422), .Y(po035));
  AOI21x1_ASAP7_75t_R  g100(.A1(new_n333), .A2(new_n354), .B(new_n372), .Y(po036));
  OR5x1_ASAP7_75t_R    g101(.A(new_n335), .B(new_n354), .C(pi055), .D(pi035), .E(pi121), .Y(new_n425));
  NAND2x1_ASAP7_75t_R  g102(.A(new_n404), .B(new_n425), .Y(new_n426));
  OR3x1_ASAP7_75t_R    g103(.A(new_n351), .B(pi183), .C(pi039), .Y(new_n427));
  OA211x2_ASAP7_75t_R  g104(.A1(new_n335), .A2(new_n354), .B(new_n337), .C(pi035), .Y(new_n428));
  AND3x1_ASAP7_75t_R   g105(.A(new_n334), .B(new_n335), .C(pi055), .Y(new_n429));
  AND5x1_ASAP7_75t_R   g106(.A(new_n403), .B(new_n355), .C(pi129), .D(pi055), .E(new_n360), .Y(new_n430));
  AND3x1_ASAP7_75t_R   g107(.A(new_n335), .B(pi055), .C(pi035), .Y(new_n431));
  AO221x2_ASAP7_75t_R  g108(.A1(new_n427), .A2(new_n428), .B1(new_n431), .B2(new_n348), .C(new_n430), .Y(new_n432));
  OA21x2_ASAP7_75t_R   g109(.A1(new_n432), .A2(new_n426), .B(pi197), .Y(po037));
  XOR2x2_ASAP7_75t_R   g110(.A(pi149), .B(pi163), .Y(new_n434));
  AOI21x1_ASAP7_75t_R  g111(.A1(pi191), .A2(new_n434), .B(pi037), .Y(new_n435));
  AND2x2_ASAP7_75t_R   g112(.A(new_n336), .B(pi037), .Y(po094));
  AND3x1_ASAP7_75t_R   g113(.A(po094), .B(new_n434), .C(pi191), .Y(new_n437));
  OR3x1_ASAP7_75t_R    g114(.A(new_n437), .B(new_n435), .C(new_n363), .Y(po038));
  NAND2x1_ASAP7_75t_R  g115(.A(pi035), .B(pi147), .Y(new_n439));
  AO32x1_ASAP7_75t_R   g116(.A1(pi039), .A2(new_n337), .A3(new_n439), .B1(pi121), .B2(new_n431), .Y(new_n440));
  AND2x2_ASAP7_75t_R   g117(.A(new_n440), .B(pi197), .Y(po039));
  OA31x2_ASAP7_75t_R   g118(.A1(new_n338), .A2(new_n339), .A3(pi069), .B1(pi147), .Y(new_n442));
  OA21x2_ASAP7_75t_R   g119(.A1(new_n408), .A2(new_n354), .B(pi041), .Y(new_n443));
  AND3x1_ASAP7_75t_R   g120(.A(new_n442), .B(pi073), .C(pi071), .Y(new_n444));
  INVx1_ASAP7_75t_R    g121(.A(new_n444), .Y(new_n445));
  AOI21x1_ASAP7_75t_R  g122(.A1(pi063), .A2(new_n444), .B(new_n443), .Y(new_n446));
  NOR2x1_ASAP7_75t_R   g123(.A(new_n363), .B(new_n446), .Y(po040));
  AO21x1_ASAP7_75t_R   g124(.A1(new_n435), .A2(pi043), .B(po094), .Y(new_n448));
  AND2x2_ASAP7_75t_R   g125(.A(new_n448), .B(pi197), .Y(po041));
  AO21x1_ASAP7_75t_R   g126(.A1(new_n354), .A2(pi045), .B(pi089), .Y(po042));
  AND2x2_ASAP7_75t_R   g127(.A(new_n353), .B(pi147), .Y(new_n451));
  AND3x1_ASAP7_75t_R   g128(.A(new_n353), .B(pi147), .C(pi117), .Y(new_n452));
  AND4x2_ASAP7_75t_R   g129(.A(new_n353), .B(pi147), .C(pi109), .D(pi117), .Y(new_n453));
  AND2x2_ASAP7_75t_R   g130(.A(new_n453), .B(pi053), .Y(new_n454));
  OR3x1_ASAP7_75t_R    g131(.A(new_n363), .B(pi169), .C(pi165), .Y(new_n455));
  AND3x1_ASAP7_75t_R   g132(.A(new_n453), .B(pi053), .C(pi049), .Y(new_n456));
  NOR2x1_ASAP7_75t_R   g133(.A(new_n455), .B(new_n456), .Y(new_n457));
  OA21x2_ASAP7_75t_R   g134(.A1(pi049), .A2(new_n454), .B(new_n457), .Y(po044));
  AND5x1_ASAP7_75t_R   g135(.A(pi049), .B(pi051), .C(pi053), .D(pi109), .E(pi117), .Y(po084));
  AOI21x1_ASAP7_75t_R  g136(.A1(new_n451), .A2(po084), .B(new_n455), .Y(new_n460));
  OA21x2_ASAP7_75t_R   g137(.A1(new_n456), .A2(pi051), .B(new_n460), .Y(po045));
  NOR2x1_ASAP7_75t_R   g138(.A(new_n455), .B(new_n454), .Y(new_n462));
  OA21x2_ASAP7_75t_R   g139(.A1(pi053), .A2(new_n453), .B(new_n462), .Y(po046));
  AND5x1_ASAP7_75t_R   g140(.A(new_n335), .B(new_n337), .C(new_n360), .D(pi129), .E(pi035), .Y(new_n464));
  AO21x1_ASAP7_75t_R   g141(.A1(new_n431), .A2(new_n348), .B(new_n429), .Y(new_n465));
  OA21x2_ASAP7_75t_R   g142(.A1(new_n465), .A2(new_n464), .B(pi197), .Y(po047));
  AND2x2_ASAP7_75t_R   g143(.A(pi001), .B(pi197), .Y(new_n467));
  NAND2x1_ASAP7_75t_R  g144(.A(pi001), .B(pi197), .Y(new_n468));
  NAND2x1_ASAP7_75t_R  g145(.A(pi059), .B(pi069), .Y(new_n469));
  AO31x2_ASAP7_75t_R   g146(.A1(pi113), .A2(new_n442), .A3(new_n469), .B(new_n354), .Y(new_n470));
  AND5x1_ASAP7_75t_R   g147(.A(new_n338), .B(pi059), .C(pi069), .D(pi113), .E(pi147), .Y(new_n471));
  AO21x1_ASAP7_75t_R   g148(.A1(new_n470), .A2(pi057), .B(new_n471), .Y(new_n472));
  AND2x2_ASAP7_75t_R   g149(.A(new_n472), .B(new_n467), .Y(po048));
  AND4x2_ASAP7_75t_R   g150(.A(new_n339), .B(pi069), .C(pi113), .D(pi147), .Y(new_n474));
  AO21x1_ASAP7_75t_R   g151(.A1(new_n470), .A2(pi059), .B(new_n474), .Y(new_n475));
  AND2x2_ASAP7_75t_R   g152(.A(new_n475), .B(new_n467), .Y(po049));
  AND2x2_ASAP7_75t_R   g153(.A(pi083), .B(pi085), .Y(new_n477));
  AOI21x1_ASAP7_75t_R  g154(.A1(new_n359), .A2(new_n477), .B(pi065), .Y(new_n478));
  OR3x1_ASAP7_75t_R    g155(.A(new_n343), .B(pi085), .C(pi170), .Y(new_n479));
  OR3x1_ASAP7_75t_R    g156(.A(new_n361), .B(pi085), .C(pi083), .Y(new_n480));
  OR3x1_ASAP7_75t_R    g157(.A(new_n344), .B(pi180), .C(pi083), .Y(new_n481));
  OR3x1_ASAP7_75t_R    g158(.A(new_n343), .B(pi085), .C(pi172), .Y(new_n482));
  AO33x2_ASAP7_75t_R   g159(.A1(new_n481), .A2(new_n482), .A3(pi065), .B1(new_n478), .B2(new_n479), .B3(new_n480), .Y(new_n483));
  INVx1_ASAP7_75t_R    g160(.A(new_n483), .Y(new_n484));
  AND3x1_ASAP7_75t_R   g161(.A(pi065), .B(pi083), .C(pi085), .Y(new_n485));
  AND2x2_ASAP7_75t_R   g162(.A(new_n485), .B(pi193), .Y(new_n486));
  AND4x2_ASAP7_75t_R   g163(.A(new_n343), .B(new_n344), .C(pi195), .D(pi065), .Y(new_n487));
  AND4x2_ASAP7_75t_R   g164(.A(new_n340), .B(new_n343), .C(pi085), .D(pi189), .Y(new_n488));
  OR3x1_ASAP7_75t_R    g165(.A(new_n487), .B(new_n488), .C(new_n486), .Y(new_n489));
  OA21x2_ASAP7_75t_R   g166(.A1(new_n484), .A2(new_n489), .B(pi131), .Y(po050));
  AOI21x1_ASAP7_75t_R  g167(.A1(pi063), .A2(new_n444), .B(new_n468), .Y(new_n491));
  OA21x2_ASAP7_75t_R   g168(.A1(pi063), .A2(new_n444), .B(new_n491), .Y(po051));
  AND2x2_ASAP7_75t_R   g169(.A(pi077), .B(pi079), .Y(new_n493));
  NAND2x1_ASAP7_75t_R  g170(.A(pi077), .B(pi079), .Y(new_n494));
  AOI21x1_ASAP7_75t_R  g171(.A1(new_n345), .A2(new_n493), .B(new_n354), .Y(new_n495));
  AO21x1_ASAP7_75t_R   g172(.A1(new_n495), .A2(new_n477), .B(pi065), .Y(new_n496));
  OA21x2_ASAP7_75t_R   g173(.A1(pi087), .A2(new_n494), .B(new_n485), .Y(po078));
  NAND2x1_ASAP7_75t_R  g174(.A(pi147), .B(po078), .Y(new_n498));
  AND2x2_ASAP7_75t_R   g175(.A(pi131), .B(pi197), .Y(new_n499));
  NAND2x1_ASAP7_75t_R  g176(.A(pi131), .B(pi197), .Y(new_n500));
  AND3x1_ASAP7_75t_R   g177(.A(new_n498), .B(new_n499), .C(new_n496), .Y(po052));
  AO21x1_ASAP7_75t_R   g178(.A1(pi067), .A2(new_n352), .B(new_n430), .Y(new_n502));
  AND2x2_ASAP7_75t_R   g179(.A(new_n502), .B(pi197), .Y(po053));
  AOI21x1_ASAP7_75t_R  g180(.A1(pi113), .A2(new_n442), .B(pi069), .Y(new_n504));
  AOI211x1_ASAP7_75t_R g181(.A1(pi069), .A2(pi147), .B(new_n504), .C(new_n468), .Y(po054));
  AOI21x1_ASAP7_75t_R  g182(.A1(pi071), .A2(new_n442), .B(new_n468), .Y(new_n506));
  OA21x2_ASAP7_75t_R   g183(.A1(pi071), .A2(new_n442), .B(new_n506), .Y(po055));
  AO21x1_ASAP7_75t_R   g184(.A1(new_n442), .A2(pi071), .B(pi073), .Y(new_n508));
  AND3x1_ASAP7_75t_R   g185(.A(new_n445), .B(new_n467), .C(new_n508), .Y(po056));
  AND3x1_ASAP7_75t_R   g186(.A(new_n360), .B(pi155), .C(pi129), .Y(new_n510));
  AO21x1_ASAP7_75t_R   g187(.A1(new_n429), .A2(new_n510), .B(new_n464), .Y(po057));
  NAND2x1_ASAP7_75t_R  g188(.A(pi077), .B(pi087), .Y(new_n512));
  AO31x2_ASAP7_75t_R   g189(.A1(pi061), .A2(new_n495), .A3(new_n512), .B(new_n354), .Y(new_n513));
  AND4x2_ASAP7_75t_R   g190(.A(new_n512), .B(pi147), .C(pi087), .D(pi061), .Y(new_n514));
  AO21x1_ASAP7_75t_R   g191(.A1(new_n513), .A2(pi077), .B(new_n514), .Y(new_n515));
  AND2x2_ASAP7_75t_R   g192(.A(new_n515), .B(new_n499), .Y(po058));
  AND5x1_ASAP7_75t_R   g193(.A(new_n342), .B(pi087), .C(pi147), .D(pi077), .E(pi061), .Y(new_n517));
  AO21x1_ASAP7_75t_R   g194(.A1(new_n513), .A2(pi079), .B(new_n517), .Y(new_n518));
  AND2x2_ASAP7_75t_R   g195(.A(new_n518), .B(new_n499), .Y(po059));
  AO21x1_ASAP7_75t_R   g196(.A1(new_n334), .A2(pi055), .B(new_n464), .Y(new_n520));
  OR3x1_ASAP7_75t_R    g197(.A(new_n510), .B(new_n337), .C(pi035), .Y(new_n521));
  AND4x2_ASAP7_75t_R   g198(.A(new_n520), .B(new_n521), .C(pi197), .D(pi202), .Y(po060));
  AND2x2_ASAP7_75t_R   g199(.A(new_n495), .B(pi083), .Y(new_n523));
  NOR2x1_ASAP7_75t_R   g200(.A(new_n500), .B(new_n523), .Y(new_n524));
  OA21x2_ASAP7_75t_R   g201(.A1(pi083), .A2(new_n495), .B(new_n524), .Y(po061));
  OAI21x1_ASAP7_75t_R  g202(.A1(pi085), .A2(new_n523), .B(new_n499), .Y(new_n526));
  AOI21x1_ASAP7_75t_R  g203(.A1(pi085), .A2(new_n523), .B(new_n526), .Y(po062));
  AO21x1_ASAP7_75t_R   g204(.A1(new_n495), .A2(pi061), .B(pi087), .Y(new_n528));
  OA211x2_ASAP7_75t_R  g205(.A1(new_n345), .A2(new_n354), .B(new_n528), .C(new_n499), .Y(po063));
  AND2x2_ASAP7_75t_R   g206(.A(new_n442), .B(pi041), .Y(po064));
  NAND2x1_ASAP7_75t_R  g207(.A(pi001), .B(new_n442), .Y(po065));
  OA21x2_ASAP7_75t_R   g208(.A1(new_n346), .A2(pi121), .B(new_n404), .Y(new_n532));
  NOR2x1_ASAP7_75t_R   g209(.A(new_n363), .B(new_n532), .Y(po067));
  NOR2x1_ASAP7_75t_R   g210(.A(new_n453), .B(new_n455), .Y(new_n534));
  OA21x2_ASAP7_75t_R   g211(.A1(pi109), .A2(new_n452), .B(new_n534), .Y(po068));
  NAND2x1_ASAP7_75t_R  g212(.A(pi143), .B(pi147), .Y(new_n536));
  AO21x1_ASAP7_75t_R   g213(.A1(pi121), .A2(pi198), .B(new_n536), .Y(new_n537));
  OA211x2_ASAP7_75t_R  g214(.A1(new_n347), .A2(pi147), .B(new_n537), .C(pi197), .Y(new_n538));
  INVx1_ASAP7_75t_R    g215(.A(new_n538), .Y(po069));
  XOR2x2_ASAP7_75t_R   g216(.A(pi149), .B(pi151), .Y(new_n540));
  NAND2x1_ASAP7_75t_R  g217(.A(pi113), .B(new_n354), .Y(new_n541));
  OA211x2_ASAP7_75t_R  g218(.A1(new_n354), .A2(new_n540), .B(new_n541), .C(pi005), .Y(new_n542));
  NOR2x1_ASAP7_75t_R   g219(.A(new_n363), .B(new_n542), .Y(po070));
  AO32x1_ASAP7_75t_R   g220(.A1(pi061), .A2(new_n495), .A3(pi131), .B1(pi115), .B2(new_n354), .Y(new_n544));
  AND2x2_ASAP7_75t_R   g221(.A(new_n544), .B(pi197), .Y(po071));
  NOR2x1_ASAP7_75t_R   g222(.A(new_n452), .B(new_n455), .Y(new_n546));
  OA21x2_ASAP7_75t_R   g223(.A1(pi117), .A2(new_n451), .B(new_n546), .Y(po072));
  OAI21x1_ASAP7_75t_R  g224(.A1(pi143), .A2(new_n364), .B(new_n348), .Y(new_n548));
  OA21x2_ASAP7_75t_R   g225(.A1(new_n348), .A2(new_n364), .B(new_n548), .Y(new_n549));
  OA21x2_ASAP7_75t_R   g226(.A1(pi119), .A2(pi147), .B(pi197), .Y(new_n550));
  OA21x2_ASAP7_75t_R   g227(.A1(new_n549), .A2(new_n354), .B(new_n550), .Y(po073));
  AO21x1_ASAP7_75t_R   g228(.A1(pi145), .A2(pi147), .B(new_n348), .Y(new_n552));
  NAND2x1_ASAP7_75t_R  g229(.A(pi137), .B(pi147), .Y(new_n553));
  AOI21x1_ASAP7_75t_R  g230(.A1(new_n553), .A2(new_n552), .B(new_n363), .Y(po074));
  OR3x1_ASAP7_75t_R    g231(.A(new_n354), .B(pi139), .C(pi133), .Y(new_n555));
  OA211x2_ASAP7_75t_R  g232(.A1(new_n349), .A2(pi147), .B(new_n555), .C(pi197), .Y(new_n556));
  INVx1_ASAP7_75t_R    g233(.A(new_n556), .Y(po075));
  AND2x2_ASAP7_75t_R   g234(.A(pi165), .B(pi179), .Y(po092));
  AO21x1_ASAP7_75t_R   g235(.A1(pi165), .A2(pi179), .B(new_n356), .Y(po076));
  AND2x2_ASAP7_75t_R   g236(.A(pi169), .B(pi187), .Y(po093));
  AO21x1_ASAP7_75t_R   g237(.A1(pi169), .A2(pi187), .B(new_n357), .Y(po077));
  OA21x2_ASAP7_75t_R   g238(.A1(pi131), .A2(pi147), .B(pi197), .Y(new_n562));
  OA21x2_ASAP7_75t_R   g239(.A1(pi107), .A2(new_n354), .B(new_n562), .Y(po079));
  OA21x2_ASAP7_75t_R   g240(.A1(pi133), .A2(pi147), .B(pi197), .Y(new_n564));
  OA21x2_ASAP7_75t_R   g241(.A1(pi131), .A2(new_n354), .B(new_n564), .Y(po080));
  OA21x2_ASAP7_75t_R   g242(.A1(pi135), .A2(pi147), .B(pi197), .Y(new_n566));
  OA21x2_ASAP7_75t_R   g243(.A1(pi067), .A2(new_n354), .B(new_n566), .Y(po081));
  OA21x2_ASAP7_75t_R   g244(.A1(pi137), .A2(pi147), .B(pi197), .Y(new_n568));
  OA21x2_ASAP7_75t_R   g245(.A1(pi135), .A2(new_n354), .B(new_n568), .Y(po082));
  OA21x2_ASAP7_75t_R   g246(.A1(pi139), .A2(pi147), .B(pi197), .Y(new_n570));
  OA21x2_ASAP7_75t_R   g247(.A1(pi133), .A2(new_n354), .B(new_n570), .Y(po083));
  OR3x1_ASAP7_75t_R    g248(.A(new_n354), .B(pi143), .C(pi115), .Y(new_n572));
  OAI21x1_ASAP7_75t_R  g249(.A1(pi115), .A2(new_n354), .B(pi143), .Y(new_n573));
  AND4x2_ASAP7_75t_R   g250(.A(new_n572), .B(new_n573), .C(pi133), .D(new_n499), .Y(new_n574));
  INVx1_ASAP7_75t_R    g251(.A(new_n574), .Y(po085));
  OA21x2_ASAP7_75t_R   g252(.A1(new_n354), .A2(pi121), .B(pi197), .Y(new_n576));
  OA21x2_ASAP7_75t_R   g253(.A1(pi145), .A2(pi147), .B(new_n576), .Y(po086));
  MAJx2_ASAP7_75t_R    g254(.A(new_n358), .B(pi175), .C(pi149), .Y(po088));
  OR2x4_ASAP7_75t_R    g255(.A(pi147), .B(pi151), .Y(new_n579));
  OA21x2_ASAP7_75t_R   g256(.A1(new_n354), .A2(pi149), .B(new_n579), .Y(po089));
  OA211x2_ASAP7_75t_R  g257(.A1(new_n346), .A2(pi155), .B(pi197), .C(pi202), .Y(po091));
  assign               po018 = 1'b1;
  BUFx2_ASAP7_75t_R    g258(.A(pi141), .Y(po000));
  BUFx2_ASAP7_75t_R    g259(.A(pi111), .Y(po001));
  BUFx2_ASAP7_75t_R    g260(.A(pi119), .Y(po002));
  BUFx2_ASAP7_75t_R    g261(.A(pi123), .Y(po003));
  BUFx2_ASAP7_75t_R    g262(.A(pi081), .Y(po004));
  BUFx2_ASAP7_75t_R    g263(.A(pi089), .Y(po005));
  BUFx2_ASAP7_75t_R    g264(.A(pi005), .Y(po006));
  BUFx2_ASAP7_75t_R    g265(.A(pi095), .Y(po008));
  BUFx2_ASAP7_75t_R    g266(.A(pi097), .Y(po009));
  BUFx2_ASAP7_75t_R    g267(.A(pi099), .Y(po010));
  BUFx2_ASAP7_75t_R    g268(.A(pi101), .Y(po011));
  BUFx2_ASAP7_75t_R    g269(.A(pi093), .Y(po012));
  BUFx2_ASAP7_75t_R    g270(.A(pi103), .Y(po013));
  BUFx2_ASAP7_75t_R    g271(.A(pi091), .Y(po014));
  BUFx2_ASAP7_75t_R    g272(.A(pi105), .Y(po015));
  BUFx2_ASAP7_75t_R    g273(.A(pi169), .Y(po016));
  BUFx2_ASAP7_75t_R    g274(.A(pi165), .Y(po017));
  BUFx2_ASAP7_75t_R    g275(.A(pi196), .Y(po019));
  BUFx2_ASAP7_75t_R    g276(.A(pi113), .Y(po066));
  BUFx2_ASAP7_75t_R    g277(.A(pi153), .Y(po087));
  BUFx2_ASAP7_75t_R    g278(.A(pi161), .Y(po090));
  BUFx2_ASAP7_75t_R    g279(.A(pi149), .Y(po095));
  BUFx2_ASAP7_75t_R    g280(.A(pi179), .Y(po096));
  BUFx2_ASAP7_75t_R    g281(.A(pi175), .Y(po097));
  BUFx2_ASAP7_75t_R    g282(.A(pi187), .Y(po098));
  BUFx2_ASAP7_75t_R    g283(.A(pi021), .Y(po099));
  BUFx2_ASAP7_75t_R    g284(.A(pi029), .Y(po100));
  BUFx2_ASAP7_75t_R    g285(.A(pi199), .Y(po101));
  BUFx2_ASAP7_75t_R    g286(.A(pi025), .Y(po102));
  BUFx2_ASAP7_75t_R    g287(.A(pi201), .Y(po103));
  BUFx2_ASAP7_75t_R    g288(.A(pi031), .Y(po104));
  BUFx2_ASAP7_75t_R    g289(.A(pi129), .Y(po105));
  BUFx2_ASAP7_75t_R    g290(.A(pi019), .Y(po106));
  BUFx2_ASAP7_75t_R    g291(.A(pi200), .Y(po107));
  BUFx2_ASAP7_75t_R    g292(.A(pi023), .Y(po108));
  BUFx2_ASAP7_75t_R    g293(.A(pi015), .Y(po109));
  BUFx2_ASAP7_75t_R    g294(.A(pi027), .Y(po110));
endmodule


