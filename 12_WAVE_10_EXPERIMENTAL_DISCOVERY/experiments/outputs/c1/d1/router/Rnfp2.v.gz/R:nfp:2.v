// Benchmark "/w/experiments/inputs/c1/c2/router" written by ABC on Fri Sep 25 09:15:01 2026

module \/w/experiments/inputs/c1/c2/router  ( 
    pi00, pi01, pi02, pi03, pi04, pi05, pi06, pi07, pi08, pi09, pi10, pi11,
    pi12, pi13, pi14, pi15, pi16, pi17, pi18, pi19, pi20, pi21, pi22, pi23,
    pi24, pi25, pi26, pi27, pi28, pi29, pi30, pi31, pi32, pi33, pi34, pi35,
    pi36, pi37, pi38, pi39, pi40, pi41, pi42, pi43, pi44, pi45, pi46, pi47,
    pi48, pi49, pi50, pi51, pi52, pi53, pi54, pi55, pi56, pi57, pi58, pi59,
    po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10, po11,
    po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22, po23,
    po24, po25, po26, po27, po28, po29  );
  input  pi00, pi01, pi02, pi03, pi04, pi05, pi06, pi07, pi08, pi09,
    pi10, pi11, pi12, pi13, pi14, pi15, pi16, pi17, pi18, pi19, pi20, pi21,
    pi22, pi23, pi24, pi25, pi26, pi27, pi28, pi29, pi30, pi31, pi32, pi33,
    pi34, pi35, pi36, pi37, pi38, pi39, pi40, pi41, pi42, pi43, pi44, pi45,
    pi46, pi47, pi48, pi49, pi50, pi51, pi52, pi53, pi54, pi55, pi56, pi57,
    pi58, pi59;
  output po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10,
    po11, po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22,
    po23, po24, po25, po26, po27, po28, po29;
  wire new_n92, new_n93, new_n94, new_n95, new_n96, new_n97, new_n98,
    new_n99, new_n100, new_n101, new_n102, new_n103, new_n104, new_n105,
    new_n106, new_n107, new_n108, new_n109, new_n110, new_n111, new_n112,
    new_n113, new_n114, new_n115, new_n116, new_n117, new_n118, new_n119,
    new_n120, new_n121, new_n122, new_n123, new_n124, new_n125, new_n126,
    new_n127, new_n128, new_n129, new_n130, new_n131, new_n132, new_n133,
    new_n134, new_n135, new_n136, new_n137, new_n138, new_n139, new_n140,
    new_n141, new_n142, new_n143, new_n144, new_n145, new_n146, new_n147,
    new_n148, new_n149, new_n150, new_n151, new_n152, new_n153, new_n154,
    new_n155, new_n156, new_n157, new_n159, new_n160, new_n161, new_n162,
    new_n163, new_n164, new_n165, new_n166, new_n167, new_n168, new_n169,
    new_n170, new_n171, new_n172, new_n173, new_n174, new_n175, new_n176,
    new_n177, new_n178, new_n179, new_n180, new_n181, new_n182, new_n183,
    new_n184, new_n185, new_n186, new_n187, new_n188, new_n189, new_n190,
    new_n191, new_n192, new_n193, new_n194, new_n195, new_n196, new_n197,
    new_n198, new_n199, new_n200, new_n201, new_n202, new_n203, new_n205,
    new_n206;
  INVx1_ASAP7_75t_R    g000(.A(pi09), .Y(new_n92));
  INVx1_ASAP7_75t_R    g001(.A(pi14), .Y(new_n93));
  INVx1_ASAP7_75t_R    g002(.A(pi15), .Y(new_n94));
  INVx1_ASAP7_75t_R    g003(.A(pi16), .Y(new_n95));
  INVx1_ASAP7_75t_R    g004(.A(pi17), .Y(new_n96));
  INVx1_ASAP7_75t_R    g005(.A(pi19), .Y(new_n97));
  INVx1_ASAP7_75t_R    g006(.A(pi21), .Y(new_n98));
  INVx1_ASAP7_75t_R    g007(.A(pi22), .Y(new_n99));
  INVx1_ASAP7_75t_R    g008(.A(pi23), .Y(new_n100));
  INVx1_ASAP7_75t_R    g009(.A(pi26), .Y(new_n101));
  INVx1_ASAP7_75t_R    g010(.A(pi39), .Y(new_n102));
  INVx1_ASAP7_75t_R    g011(.A(pi41), .Y(new_n103));
  INVx1_ASAP7_75t_R    g012(.A(pi44), .Y(new_n104));
  INVx1_ASAP7_75t_R    g013(.A(pi48), .Y(new_n105));
  INVx1_ASAP7_75t_R    g014(.A(pi50), .Y(new_n106));
  INVx1_ASAP7_75t_R    g015(.A(pi52), .Y(new_n107));
  INVx1_ASAP7_75t_R    g016(.A(pi57), .Y(new_n108));
  AND3x1_ASAP7_75t_R   g017(.A(pi27), .B(pi28), .C(pi29), .Y(new_n109));
  NOR2x1_ASAP7_75t_R   g018(.A(pi09), .B(pi10), .Y(new_n110));
  OA21x2_ASAP7_75t_R   g019(.A1(pi09), .A2(pi10), .B(pi11), .Y(new_n111));
  OAI21x1_ASAP7_75t_R  g020(.A1(pi09), .A2(pi10), .B(pi11), .Y(new_n112));
  NOR2x1_ASAP7_75t_R   g021(.A(pi12), .B(pi13), .Y(new_n113));
  OR2x4_ASAP7_75t_R    g022(.A(pi12), .B(pi13), .Y(new_n114));
  OA21x2_ASAP7_75t_R   g023(.A1(new_n114), .A2(new_n111), .B(pi14), .Y(new_n115));
  INVx1_ASAP7_75t_R    g024(.A(new_n115), .Y(new_n116));
  AO211x2_ASAP7_75t_R  g025(.A1(new_n112), .A2(new_n113), .B(new_n93), .C(new_n94), .Y(new_n117));
  AO21x1_ASAP7_75t_R   g026(.A1(new_n115), .A2(pi15), .B(pi16), .Y(new_n118));
  AOI21x1_ASAP7_75t_R  g027(.A1(new_n95), .A2(new_n117), .B(new_n96), .Y(new_n119));
  AO21x1_ASAP7_75t_R   g028(.A1(new_n117), .A2(new_n95), .B(new_n96), .Y(new_n120));
  OAI21x1_ASAP7_75t_R  g029(.A1(pi18), .A2(new_n119), .B(pi19), .Y(new_n121));
  OA211x2_ASAP7_75t_R  g030(.A1(new_n119), .A2(pi18), .B(pi19), .C(pi20), .Y(new_n122));
  NOR2x1_ASAP7_75t_R   g031(.A(pi21), .B(new_n122), .Y(new_n123));
  NAND2x1_ASAP7_75t_R  g032(.A(pi24), .B(pi25), .Y(new_n124));
  AND3x1_ASAP7_75t_R   g033(.A(pi23), .B(pi24), .C(pi25), .Y(new_n125));
  OA31x2_ASAP7_75t_R   g034(.A1(pi21), .A2(new_n122), .A3(pi22), .B1(new_n125), .Y(new_n126));
  OA21x2_ASAP7_75t_R   g035(.A1(new_n126), .A2(pi26), .B(new_n109), .Y(new_n127));
  XOR2x2_ASAP7_75t_R   g036(.A(new_n115), .B(pi15), .Y(new_n128));
  NOR2x1_ASAP7_75t_R   g037(.A(new_n95), .B(new_n117), .Y(new_n129));
  OR4x2_ASAP7_75t_R    g038(.A(pi03), .B(pi04), .C(pi05), .D(pi06), .Y(new_n130));
  OR5x1_ASAP7_75t_R    g039(.A(new_n130), .B(new_n92), .C(pi08), .D(pi07), .E(pi10), .Y(new_n131));
  OR3x1_ASAP7_75t_R    g040(.A(new_n100), .B(pi26), .C(pi22), .Y(new_n132));
  OR5x1_ASAP7_75t_R    g041(.A(new_n132), .B(pi18), .C(new_n93), .D(pi13), .E(new_n97), .Y(new_n133));
  AOI21x1_ASAP7_75t_R  g042(.A1(pi12), .A2(new_n110), .B(new_n111), .Y(new_n134));
  AND2x2_ASAP7_75t_R   g043(.A(pi11), .B(pi12), .Y(new_n135));
  OR5x1_ASAP7_75t_R    g044(.A(new_n134), .B(new_n135), .C(pi01), .D(pi02), .E(new_n124), .Y(new_n136));
  OR5x1_ASAP7_75t_R    g045(.A(new_n128), .B(new_n131), .C(new_n133), .D(new_n136), .E(new_n129), .Y(new_n137));
  OR3x1_ASAP7_75t_R    g046(.A(new_n123), .B(new_n137), .C(new_n120), .Y(new_n138));
  AND2x2_ASAP7_75t_R   g047(.A(new_n122), .B(pi21), .Y(new_n139));
  XNOR2x2_ASAP7_75t_R  g048(.A(pi20), .B(new_n121), .Y(new_n140));
  AO21x1_ASAP7_75t_R   g049(.A1(pi21), .A2(new_n122), .B(new_n140), .Y(new_n141));
  OR5x1_ASAP7_75t_R    g050(.A(new_n140), .B(new_n137), .C(new_n123), .D(new_n120), .E(new_n139), .Y(new_n142));
  OA21x2_ASAP7_75t_R   g051(.A1(new_n141), .A2(new_n138), .B(new_n127), .Y(new_n143));
  AND4x2_ASAP7_75t_R   g052(.A(new_n98), .B(pi24), .C(pi25), .D(pi20), .Y(new_n144));
  AND5x1_ASAP7_75t_R   g053(.A(new_n144), .B(new_n101), .C(pi23), .D(new_n99), .E(new_n109), .Y(new_n145));
  AND4x2_ASAP7_75t_R   g054(.A(pi02), .B(pi03), .C(pi04), .D(pi05), .Y(new_n146));
  AND4x2_ASAP7_75t_R   g055(.A(pi06), .B(pi07), .C(pi08), .D(pi11), .Y(new_n147));
  AND4x2_ASAP7_75t_R   g056(.A(new_n147), .B(new_n113), .C(new_n95), .D(pi15), .Y(new_n148));
  AND5x1_ASAP7_75t_R   g057(.A(new_n148), .B(new_n110), .C(pi01), .D(pi00), .E(new_n146), .Y(new_n149));
  OR3x1_ASAP7_75t_R    g058(.A(new_n114), .B(new_n111), .C(pi14), .Y(new_n150));
  AND5x1_ASAP7_75t_R   g059(.A(new_n149), .B(new_n150), .C(new_n116), .D(new_n120), .E(new_n145), .Y(new_n151));
  OA211x2_ASAP7_75t_R  g060(.A1(pi17), .A2(new_n118), .B(new_n151), .C(new_n121), .Y(new_n152));
  OR3x1_ASAP7_75t_R    g061(.A(new_n119), .B(pi19), .C(pi18), .Y(new_n153));
  XNOR2x2_ASAP7_75t_R  g062(.A(pi18), .B(new_n119), .Y(new_n154));
  AND2x2_ASAP7_75t_R   g063(.A(new_n154), .B(new_n153), .Y(new_n155));
  AOI21x1_ASAP7_75t_R  g064(.A1(new_n155), .A2(new_n152), .B(new_n127), .Y(new_n156));
  AO21x1_ASAP7_75t_R   g065(.A1(new_n152), .A2(new_n155), .B(new_n127), .Y(new_n157));
  AO21x1_ASAP7_75t_R   g066(.A1(new_n127), .A2(new_n142), .B(new_n156), .Y(po00));
  OA21x2_ASAP7_75t_R   g067(.A1(pi39), .A2(pi40), .B(pi41), .Y(new_n159));
  OR3x1_ASAP7_75t_R    g068(.A(new_n159), .B(pi43), .C(pi42), .Y(new_n160));
  INVx1_ASAP7_75t_R    g069(.A(new_n160), .Y(new_n161));
  AND2x2_ASAP7_75t_R   g070(.A(pi44), .B(pi45), .Y(new_n162));
  NAND2x1_ASAP7_75t_R  g071(.A(pi44), .B(pi45), .Y(new_n163));
  OA31x2_ASAP7_75t_R   g072(.A1(pi42), .A2(new_n159), .A3(pi43), .B1(new_n162), .Y(new_n164));
  OAI21x1_ASAP7_75t_R  g073(.A1(pi46), .A2(new_n164), .B(pi47), .Y(new_n165));
  INVx1_ASAP7_75t_R    g074(.A(new_n165), .Y(new_n166));
  AND2x2_ASAP7_75t_R   g075(.A(new_n165), .B(new_n105), .Y(new_n167));
  NAND2x1_ASAP7_75t_R  g076(.A(pi49), .B(pi50), .Y(new_n168));
  AOI21x1_ASAP7_75t_R  g077(.A1(new_n105), .A2(new_n165), .B(new_n168), .Y(new_n169));
  AO21x1_ASAP7_75t_R   g078(.A1(new_n165), .A2(new_n105), .B(new_n168), .Y(new_n170));
  OR2x4_ASAP7_75t_R    g079(.A(pi51), .B(pi52), .Y(new_n171));
  NAND2x1_ASAP7_75t_R  g080(.A(pi54), .B(pi55), .Y(new_n172));
  AND3x1_ASAP7_75t_R   g081(.A(pi53), .B(pi54), .C(pi55), .Y(new_n173));
  OA21x2_ASAP7_75t_R   g082(.A1(new_n169), .A2(new_n171), .B(new_n173), .Y(new_n174));
  AND3x1_ASAP7_75t_R   g083(.A(pi57), .B(pi58), .C(pi59), .Y(new_n175));
  OAI21x1_ASAP7_75t_R  g084(.A1(pi56), .A2(new_n174), .B(new_n175), .Y(new_n176));
  OR3x1_ASAP7_75t_R    g085(.A(new_n164), .B(new_n105), .C(pi46), .Y(new_n177));
  OR4x2_ASAP7_75t_R    g086(.A(new_n108), .B(pi56), .C(pi51), .D(pi46), .Y(new_n178));
  OR4x2_ASAP7_75t_R    g087(.A(new_n102), .B(pi40), .C(pi37), .D(pi38), .Y(new_n179));
  OR5x1_ASAP7_75t_R    g088(.A(new_n178), .B(new_n179), .C(new_n103), .D(pi43), .E(new_n163), .Y(new_n180));
  AND2x2_ASAP7_75t_R   g089(.A(pi47), .B(pi48), .Y(new_n181));
  NAND2x1_ASAP7_75t_R  g090(.A(pi53), .B(new_n107), .Y(new_n182));
  OR2x4_ASAP7_75t_R    g091(.A(new_n168), .B(new_n182), .Y(new_n183));
  OR4x2_ASAP7_75t_R    g092(.A(pi33), .B(pi34), .C(pi35), .D(pi36), .Y(new_n184));
  OR3x1_ASAP7_75t_R    g093(.A(new_n172), .B(pi32), .C(pi31), .Y(new_n185));
  XNOR2x2_ASAP7_75t_R  g094(.A(pi42), .B(new_n159), .Y(new_n186));
  OR5x1_ASAP7_75t_R    g095(.A(new_n183), .B(new_n184), .C(new_n186), .D(new_n185), .E(new_n181), .Y(new_n187));
  AOI211x1_ASAP7_75t_R g096(.A1(new_n165), .A2(new_n177), .B(new_n187), .C(new_n180), .Y(new_n188));
  NOR2x1_ASAP7_75t_R   g097(.A(pi00), .B(pi30), .Y(new_n189));
  AO21x1_ASAP7_75t_R   g098(.A1(new_n188), .A2(new_n189), .B(new_n176), .Y(new_n190));
  OA21x2_ASAP7_75t_R   g099(.A1(pi00), .A2(pi51), .B(new_n176), .Y(new_n191));
  AOI21x1_ASAP7_75t_R  g100(.A1(pi46), .A2(new_n164), .B(pi47), .Y(new_n192));
  AND4x2_ASAP7_75t_R   g101(.A(new_n159), .B(new_n104), .C(pi43), .D(pi42), .Y(new_n193));
  AOI21x1_ASAP7_75t_R  g102(.A1(pi44), .A2(new_n161), .B(new_n193), .Y(new_n194));
  OR5x1_ASAP7_75t_R    g103(.A(new_n172), .B(new_n106), .C(pi40), .D(pi39), .E(pi56), .Y(new_n195));
  AND4x2_ASAP7_75t_R   g104(.A(pi34), .B(pi35), .C(pi36), .D(pi37), .Y(new_n196));
  AND5x1_ASAP7_75t_R   g105(.A(new_n196), .B(pi32), .C(pi31), .D(pi30), .E(pi33), .Y(new_n197));
  AND5x1_ASAP7_75t_R   g106(.A(new_n175), .B(pi45), .C(pi41), .D(pi38), .E(new_n105), .Y(new_n198));
  NAND2x1_ASAP7_75t_R  g107(.A(new_n198), .B(new_n197), .Y(new_n199));
  OR5x1_ASAP7_75t_R    g108(.A(new_n194), .B(new_n199), .C(new_n166), .D(new_n195), .E(new_n192), .Y(new_n200));
  XOR2x2_ASAP7_75t_R   g109(.A(new_n167), .B(pi49), .Y(new_n201));
  AO211x2_ASAP7_75t_R  g110(.A1(new_n170), .A2(new_n182), .B(new_n200), .C(new_n201), .Y(new_n202));
  OAI21x1_ASAP7_75t_R  g111(.A1(new_n191), .A2(new_n202), .B(new_n190), .Y(new_n203));
  AOI21x1_ASAP7_75t_R  g112(.A1(new_n157), .A2(new_n203), .B(new_n143), .Y(po01));
  NAND2x1_ASAP7_75t_R  g113(.A(pi00), .B(pi30), .Y(new_n205));
  AO21x1_ASAP7_75t_R   g114(.A1(new_n188), .A2(new_n205), .B(new_n176), .Y(new_n206));
  AOI211x1_ASAP7_75t_R g115(.A1(new_n127), .A2(new_n142), .B(new_n156), .C(new_n206), .Y(po02));
  assign               po03 = 1'b0;
  assign               po04 = 1'b0;
  assign               po05 = 1'b0;
  assign               po06 = 1'b0;
  assign               po07 = 1'b0;
  assign               po08 = 1'b0;
  assign               po09 = 1'b0;
  assign               po10 = 1'b0;
  assign               po11 = 1'b0;
  assign               po12 = 1'b0;
  assign               po13 = 1'b0;
  assign               po14 = 1'b0;
  assign               po15 = 1'b0;
  assign               po16 = 1'b0;
  assign               po17 = 1'b0;
  assign               po18 = 1'b0;
  assign               po19 = 1'b0;
  assign               po20 = 1'b0;
  assign               po21 = 1'b0;
  assign               po22 = 1'b0;
  assign               po23 = 1'b0;
  assign               po24 = 1'b0;
  assign               po25 = 1'b0;
  assign               po26 = 1'b0;
  assign               po27 = 1'b0;
  assign               po28 = 1'b0;
  assign               po29 = 1'b0;
endmodule


