// Benchmark "/w/experiments/inputs/c1/c2/router" written by ABC on Fri Sep 25 09:15:04 2026

module \/w/experiments/inputs/c1/c2/router  ( 
    pi00, pi01, pi02, pi03, pi04, pi05, pi06, pi07, pi08, pi09, pi10, pi11,
    pi12, pi13, pi14, pi15, pi16, pi17, pi18, pi19, pi20, pi21, pi22, pi23,
    pi24, pi25, pi26, pi27, pi28, pi29, pi30, pi31, pi32, pi33, pi34, pi35,
    pi36, pi37, pi38, pi39, pi40, pi41, pi42, pi43, pi44, pi45, pi46, pi47,
    pi48, pi49, pi50, pi51, pi52, pi53, pi54, pi55, pi56, pi57, pi58, pi59,
    po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10, po11,
    po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22, po23,
    po24, po25, po26, po27, po28, po29  );
  input  pi00, pi01, pi02, pi03, pi04, pi05, pi06, pi07, pi08, pi09,
    pi10, pi11, pi12, pi13, pi14, pi15, pi16, pi17, pi18, pi19, pi20, pi21,
    pi22, pi23, pi24, pi25, pi26, pi27, pi28, pi29, pi30, pi31, pi32, pi33,
    pi34, pi35, pi36, pi37, pi38, pi39, pi40, pi41, pi42, pi43, pi44, pi45,
    pi46, pi47, pi48, pi49, pi50, pi51, pi52, pi53, pi54, pi55, pi56, pi57,
    pi58, pi59;
  output po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10,
    po11, po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22,
    po23, po24, po25, po26, po27, po28, po29;
  wire new_n92, new_n93, new_n94, new_n95, new_n96, new_n97, new_n98,
    new_n99, new_n100, new_n101, new_n102, new_n103, new_n104, new_n105,
    new_n106, new_n107, new_n108, new_n109, new_n110, new_n111, new_n112,
    new_n113, new_n114, new_n115, new_n116, new_n117, new_n118, new_n119,
    new_n120, new_n121, new_n122, new_n123, new_n124, new_n125, new_n126,
    new_n127, new_n128, new_n129, new_n130, new_n131, new_n132, new_n133,
    new_n134, new_n135, new_n136, new_n137, new_n138, new_n139, new_n140,
    new_n141, new_n142, new_n143, new_n144, new_n145, new_n146, new_n147,
    new_n148, new_n149, new_n150, new_n151, new_n152, new_n154, new_n155,
    new_n156, new_n157, new_n158, new_n159, new_n160, new_n161, new_n162,
    new_n163, new_n164, new_n165, new_n166, new_n167, new_n168, new_n169,
    new_n170, new_n171, new_n172, new_n173, new_n174, new_n175, new_n176,
    new_n177, new_n178, new_n179, new_n180, new_n181, new_n182, new_n183,
    new_n184, new_n185, new_n186, new_n187, new_n188, new_n189, new_n190,
    new_n191, new_n192, new_n193, new_n194, new_n195, new_n197;
  INVx1_ASAP7_75t_R    g000(.A(pi00), .Y(new_n92));
  INVx1_ASAP7_75t_R    g001(.A(pi09), .Y(new_n93));
  INVx1_ASAP7_75t_R    g002(.A(pi14), .Y(new_n94));
  INVx1_ASAP7_75t_R    g003(.A(pi15), .Y(new_n95));
  INVx1_ASAP7_75t_R    g004(.A(pi19), .Y(new_n96));
  INVx1_ASAP7_75t_R    g005(.A(pi21), .Y(new_n97));
  INVx1_ASAP7_75t_R    g006(.A(pi23), .Y(new_n98));
  INVx1_ASAP7_75t_R    g007(.A(pi39), .Y(new_n99));
  INVx1_ASAP7_75t_R    g008(.A(pi41), .Y(new_n100));
  INVx1_ASAP7_75t_R    g009(.A(pi44), .Y(new_n101));
  INVx1_ASAP7_75t_R    g010(.A(pi45), .Y(new_n102));
  INVx1_ASAP7_75t_R    g011(.A(pi48), .Y(new_n103));
  INVx1_ASAP7_75t_R    g012(.A(pi51), .Y(new_n104));
  INVx1_ASAP7_75t_R    g013(.A(pi52), .Y(new_n105));
  INVx1_ASAP7_75t_R    g014(.A(pi56), .Y(new_n106));
  INVx1_ASAP7_75t_R    g015(.A(pi57), .Y(new_n107));
  AND3x1_ASAP7_75t_R   g016(.A(pi27), .B(pi28), .C(pi29), .Y(new_n108));
  NOR2x1_ASAP7_75t_R   g017(.A(pi09), .B(pi10), .Y(new_n109));
  OA21x2_ASAP7_75t_R   g018(.A1(pi09), .A2(pi10), .B(pi11), .Y(new_n110));
  OR2x4_ASAP7_75t_R    g019(.A(pi12), .B(pi13), .Y(new_n111));
  OR3x1_ASAP7_75t_R    g020(.A(new_n110), .B(pi13), .C(pi12), .Y(new_n112));
  OA211x2_ASAP7_75t_R  g021(.A1(new_n111), .A2(new_n110), .B(pi15), .C(pi14), .Y(new_n113));
  OA21x2_ASAP7_75t_R   g022(.A1(new_n113), .A2(pi16), .B(pi17), .Y(new_n114));
  INVx1_ASAP7_75t_R    g023(.A(new_n114), .Y(new_n115));
  OAI21x1_ASAP7_75t_R  g024(.A1(pi18), .A2(new_n114), .B(pi19), .Y(new_n116));
  OA211x2_ASAP7_75t_R  g025(.A1(new_n114), .A2(pi18), .B(pi19), .C(pi20), .Y(new_n117));
  NOR2x1_ASAP7_75t_R   g026(.A(pi21), .B(new_n117), .Y(new_n118));
  OR3x1_ASAP7_75t_R    g027(.A(new_n117), .B(pi22), .C(pi21), .Y(new_n119));
  NAND2x1_ASAP7_75t_R  g028(.A(pi24), .B(pi25), .Y(new_n120));
  AND3x1_ASAP7_75t_R   g029(.A(pi23), .B(pi24), .C(pi25), .Y(new_n121));
  AO21x1_ASAP7_75t_R   g030(.A1(new_n119), .A2(new_n121), .B(pi26), .Y(new_n122));
  AOI21x1_ASAP7_75t_R  g031(.A1(pi14), .A2(new_n112), .B(pi15), .Y(new_n123));
  NOR2x1_ASAP7_75t_R   g032(.A(new_n113), .B(new_n123), .Y(new_n124));
  AND2x2_ASAP7_75t_R   g033(.A(new_n113), .B(pi16), .Y(new_n125));
  OR4x2_ASAP7_75t_R    g034(.A(pi03), .B(pi04), .C(pi05), .D(pi06), .Y(new_n126));
  OR5x1_ASAP7_75t_R    g035(.A(new_n126), .B(new_n93), .C(pi08), .D(pi07), .E(pi10), .Y(new_n127));
  OR3x1_ASAP7_75t_R    g036(.A(new_n98), .B(pi26), .C(pi22), .Y(new_n128));
  OR5x1_ASAP7_75t_R    g037(.A(new_n128), .B(pi18), .C(new_n94), .D(pi13), .E(new_n96), .Y(new_n129));
  AOI21x1_ASAP7_75t_R  g038(.A1(pi12), .A2(new_n109), .B(new_n110), .Y(new_n130));
  AND2x2_ASAP7_75t_R   g039(.A(pi11), .B(pi12), .Y(new_n131));
  OR5x1_ASAP7_75t_R    g040(.A(new_n130), .B(new_n131), .C(pi01), .D(pi02), .E(new_n120), .Y(new_n132));
  OR5x1_ASAP7_75t_R    g041(.A(new_n124), .B(new_n125), .C(new_n127), .D(new_n129), .E(new_n132), .Y(new_n133));
  AND2x2_ASAP7_75t_R   g042(.A(new_n117), .B(pi21), .Y(new_n134));
  XNOR2x2_ASAP7_75t_R  g043(.A(pi20), .B(new_n116), .Y(new_n135));
  OR5x1_ASAP7_75t_R    g044(.A(new_n133), .B(new_n134), .C(new_n135), .D(new_n118), .E(new_n115), .Y(new_n136));
  AND3x1_ASAP7_75t_R   g045(.A(new_n136), .B(new_n122), .C(new_n108), .Y(new_n137));
  INVx1_ASAP7_75t_R    g046(.A(new_n137), .Y(new_n138));
  OR3x1_ASAP7_75t_R    g047(.A(new_n113), .B(pi17), .C(pi16), .Y(new_n139));
  NAND2x1_ASAP7_75t_R  g048(.A(pi20), .B(new_n97), .Y(new_n140));
  NOR3x1_ASAP7_75t_R   g049(.A(new_n128), .B(new_n140), .C(new_n120), .Y(new_n141));
  AND3x1_ASAP7_75t_R   g050(.A(new_n109), .B(pi01), .C(pi00), .Y(new_n142));
  AND5x1_ASAP7_75t_R   g051(.A(new_n142), .B(pi04), .C(pi03), .D(pi02), .E(pi05), .Y(new_n143));
  OR3x1_ASAP7_75t_R    g052(.A(new_n111), .B(pi16), .C(new_n95), .Y(new_n144));
  INVx1_ASAP7_75t_R    g053(.A(new_n144), .Y(new_n145));
  AND5x1_ASAP7_75t_R   g054(.A(new_n145), .B(pi08), .C(pi07), .D(pi06), .E(pi11), .Y(new_n146));
  XOR2x2_ASAP7_75t_R   g055(.A(new_n112), .B(pi14), .Y(new_n147));
  AND5x1_ASAP7_75t_R   g056(.A(new_n146), .B(new_n147), .C(new_n108), .D(new_n141), .E(new_n143), .Y(new_n148));
  AND4x2_ASAP7_75t_R   g057(.A(new_n148), .B(new_n139), .C(new_n116), .D(new_n115), .Y(new_n149));
  OR3x1_ASAP7_75t_R    g058(.A(new_n114), .B(pi19), .C(pi18), .Y(new_n150));
  XNOR2x2_ASAP7_75t_R  g059(.A(pi18), .B(new_n114), .Y(new_n151));
  AO32x1_ASAP7_75t_R   g060(.A1(new_n151), .A2(new_n149), .A3(new_n150), .B1(new_n122), .B2(new_n108), .Y(new_n152));
  NAND2x1_ASAP7_75t_R  g061(.A(new_n152), .B(new_n138), .Y(po00));
  NOR2x1_ASAP7_75t_R   g062(.A(pi39), .B(pi40), .Y(new_n154));
  OR2x4_ASAP7_75t_R    g063(.A(pi39), .B(pi40), .Y(new_n155));
  AO21x1_ASAP7_75t_R   g064(.A1(new_n155), .A2(pi41), .B(pi42), .Y(new_n156));
  INVx1_ASAP7_75t_R    g065(.A(new_n156), .Y(new_n157));
  NOR2x1_ASAP7_75t_R   g066(.A(pi43), .B(new_n156), .Y(new_n158));
  OA211x2_ASAP7_75t_R  g067(.A1(new_n156), .A2(pi43), .B(pi44), .C(pi45), .Y(new_n159));
  OA21x2_ASAP7_75t_R   g068(.A1(new_n159), .A2(pi46), .B(pi47), .Y(new_n160));
  INVx1_ASAP7_75t_R    g069(.A(new_n160), .Y(new_n161));
  NOR2x1_ASAP7_75t_R   g070(.A(pi48), .B(new_n160), .Y(new_n162));
  OA211x2_ASAP7_75t_R  g071(.A1(new_n160), .A2(pi48), .B(pi49), .C(pi50), .Y(new_n163));
  NAND2x1_ASAP7_75t_R  g072(.A(new_n104), .B(new_n105), .Y(new_n164));
  NAND2x1_ASAP7_75t_R  g073(.A(pi54), .B(pi55), .Y(new_n165));
  AND3x1_ASAP7_75t_R   g074(.A(pi53), .B(pi54), .C(pi55), .Y(new_n166));
  OA21x2_ASAP7_75t_R   g075(.A1(new_n163), .A2(new_n164), .B(new_n166), .Y(new_n167));
  AND3x1_ASAP7_75t_R   g076(.A(pi57), .B(pi58), .C(pi59), .Y(new_n168));
  OA21x2_ASAP7_75t_R   g077(.A1(new_n167), .A2(pi56), .B(new_n168), .Y(new_n169));
  OR3x1_ASAP7_75t_R    g078(.A(new_n159), .B(new_n103), .C(pi46), .Y(new_n170));
  OR4x2_ASAP7_75t_R    g079(.A(new_n99), .B(pi40), .C(pi37), .D(pi38), .Y(new_n171));
  OR5x1_ASAP7_75t_R    g080(.A(new_n171), .B(new_n101), .C(pi43), .D(new_n100), .E(new_n102), .Y(new_n172));
  OR5x1_ASAP7_75t_R    g081(.A(new_n172), .B(pi56), .C(pi51), .D(pi46), .E(new_n107), .Y(new_n173));
  AND4x2_ASAP7_75t_R   g082(.A(new_n105), .B(pi53), .C(pi49), .D(pi50), .Y(new_n174));
  INVx1_ASAP7_75t_R    g083(.A(new_n174), .Y(new_n175));
  AO21x1_ASAP7_75t_R   g084(.A1(pi47), .A2(pi48), .B(new_n175), .Y(new_n176));
  OR4x2_ASAP7_75t_R    g085(.A(pi33), .B(pi34), .C(pi35), .D(pi36), .Y(new_n177));
  OR5x1_ASAP7_75t_R    g086(.A(new_n176), .B(new_n177), .C(pi31), .D(pi32), .E(new_n165), .Y(new_n178));
  AND3x1_ASAP7_75t_R   g087(.A(new_n155), .B(pi42), .C(pi41), .Y(new_n179));
  OR4x2_ASAP7_75t_R    g088(.A(new_n178), .B(new_n179), .C(new_n157), .D(new_n173), .Y(new_n180));
  AO21x1_ASAP7_75t_R   g089(.A1(new_n161), .A2(new_n170), .B(new_n180), .Y(new_n181));
  OR3x1_ASAP7_75t_R    g090(.A(new_n181), .B(pi30), .C(pi00), .Y(new_n182));
  AO21x1_ASAP7_75t_R   g091(.A1(new_n92), .A2(new_n104), .B(new_n169), .Y(new_n183));
  AO21x1_ASAP7_75t_R   g092(.A1(new_n105), .A2(pi53), .B(new_n163), .Y(new_n184));
  AO21x1_ASAP7_75t_R   g093(.A1(new_n159), .A2(pi46), .B(pi47), .Y(new_n185));
  AND3x1_ASAP7_75t_R   g094(.A(new_n179), .B(new_n101), .C(pi43), .Y(new_n186));
  AO21x1_ASAP7_75t_R   g095(.A1(pi44), .A2(new_n158), .B(new_n186), .Y(new_n187));
  AND5x1_ASAP7_75t_R   g096(.A(new_n154), .B(pi55), .C(pi54), .D(pi50), .E(new_n106), .Y(new_n188));
  AND4x2_ASAP7_75t_R   g097(.A(pi34), .B(pi35), .C(pi36), .D(pi37), .Y(new_n189));
  AND5x1_ASAP7_75t_R   g098(.A(new_n189), .B(pi32), .C(pi31), .D(pi30), .E(pi33), .Y(new_n190));
  AND5x1_ASAP7_75t_R   g099(.A(new_n168), .B(pi45), .C(pi41), .D(pi38), .E(new_n103), .Y(new_n191));
  AND5x1_ASAP7_75t_R   g100(.A(new_n161), .B(new_n187), .C(new_n188), .D(new_n190), .E(new_n191), .Y(new_n192));
  AND3x1_ASAP7_75t_R   g101(.A(new_n192), .B(new_n184), .C(new_n185), .Y(new_n193));
  XNOR2x2_ASAP7_75t_R  g102(.A(pi49), .B(new_n162), .Y(new_n194));
  AO32x1_ASAP7_75t_R   g103(.A1(new_n194), .A2(new_n183), .A3(new_n193), .B1(new_n182), .B2(new_n169), .Y(new_n195));
  AOI21x1_ASAP7_75t_R  g104(.A1(new_n152), .A2(new_n195), .B(new_n137), .Y(po01));
  AO21x1_ASAP7_75t_R   g105(.A1(pi00), .A2(pi30), .B(new_n181), .Y(new_n197));
  AND4x2_ASAP7_75t_R   g106(.A(new_n138), .B(new_n152), .C(new_n169), .D(new_n197), .Y(po02));
  assign               po03 = 1'b0;
  assign               po04 = 1'b0;
  assign               po05 = 1'b0;
  assign               po06 = 1'b0;
  assign               po07 = 1'b0;
  assign               po08 = 1'b0;
  assign               po09 = 1'b0;
  assign               po10 = 1'b0;
  assign               po11 = 1'b0;
  assign               po12 = 1'b0;
  assign               po13 = 1'b0;
  assign               po14 = 1'b0;
  assign               po15 = 1'b0;
  assign               po16 = 1'b0;
  assign               po17 = 1'b0;
  assign               po18 = 1'b0;
  assign               po19 = 1'b0;
  assign               po20 = 1'b0;
  assign               po21 = 1'b0;
  assign               po22 = 1'b0;
  assign               po23 = 1'b0;
  assign               po24 = 1'b0;
  assign               po25 = 1'b0;
  assign               po26 = 1'b0;
  assign               po27 = 1'b0;
  assign               po28 = 1'b0;
  assign               po29 = 1'b0;
endmodule


