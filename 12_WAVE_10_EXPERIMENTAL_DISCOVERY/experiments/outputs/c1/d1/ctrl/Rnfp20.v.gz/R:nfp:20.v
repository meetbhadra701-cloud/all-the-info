// Benchmark "/w/experiments/inputs/c1/c2/ctrl" written by ABC on Fri Sep 25 09:13:54 2026

module \/w/experiments/inputs/c1/c2/ctrl  ( 
    pi0, pi1, pi2, pi3, pi4, pi5, pi6,
    po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10, po11,
    po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22, po23,
    po24, po25  );
  input  pi0, pi1, pi2, pi3, pi4, pi5, pi6;
  output po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10,
    po11, po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22,
    po23, po24, po25;
  wire new_n35, new_n36, new_n37, new_n38, new_n39, new_n40, new_n41,
    new_n42, new_n43, new_n44, new_n45, new_n47, new_n48, new_n49, new_n50,
    new_n51, new_n52, new_n54, new_n55, new_n57, new_n59, new_n60, new_n61,
    new_n62, new_n63, new_n66, new_n67, new_n68, new_n70, new_n71, new_n73,
    new_n76, new_n77, new_n78, new_n80, new_n82, new_n83, new_n84, new_n89,
    new_n94, new_n95, new_n96, new_n98, new_n100;
  INVx1_ASAP7_75t_R    g00(.A(pi0), .Y(new_n35));
  INVx1_ASAP7_75t_R    g01(.A(pi1), .Y(new_n36));
  INVx1_ASAP7_75t_R    g02(.A(pi2), .Y(new_n37));
  INVx1_ASAP7_75t_R    g03(.A(pi3), .Y(new_n38));
  INVx1_ASAP7_75t_R    g04(.A(pi4), .Y(new_n39));
  INVx1_ASAP7_75t_R    g05(.A(pi6), .Y(new_n40));
  AND2x2_ASAP7_75t_R   g06(.A(pi3), .B(pi4), .Y(new_n41));
  NAND2x1_ASAP7_75t_R  g07(.A(pi3), .B(pi4), .Y(new_n42));
  NOR2x1_ASAP7_75t_R   g08(.A(pi0), .B(pi1), .Y(new_n43));
  NOR2x1_ASAP7_75t_R   g09(.A(pi3), .B(pi4), .Y(new_n44));
  AOI21x1_ASAP7_75t_R  g10(.A1(pi1), .A2(new_n44), .B(new_n41), .Y(new_n45));
  OAI22x1_ASAP7_75t_R  g11(.A1(new_n42), .A2(new_n43), .B1(new_n45), .B2(new_n37), .Y(po00));
  AND2x2_ASAP7_75t_R   g12(.A(new_n38), .B(pi4), .Y(new_n47));
  NAND2x1_ASAP7_75t_R  g13(.A(pi4), .B(new_n38), .Y(new_n48));
  AND3x1_ASAP7_75t_R   g14(.A(new_n35), .B(pi3), .C(pi4), .Y(new_n49));
  NOR2x1_ASAP7_75t_R   g15(.A(pi1), .B(new_n49), .Y(new_n50));
  AOI21x1_ASAP7_75t_R  g16(.A1(pi1), .A2(new_n48), .B(new_n50), .Y(new_n51));
  AO21x1_ASAP7_75t_R   g17(.A1(new_n44), .A2(pi1), .B(new_n37), .Y(new_n52));
  OA21x2_ASAP7_75t_R   g18(.A1(new_n51), .A2(pi2), .B(new_n52), .Y(po01));
  OA21x2_ASAP7_75t_R   g19(.A1(new_n48), .A2(pi0), .B(pi1), .Y(new_n54));
  NAND2x1_ASAP7_75t_R  g20(.A(pi3), .B(new_n39), .Y(new_n55));
  AOI211x1_ASAP7_75t_R g21(.A1(new_n54), .A2(new_n55), .B(new_n50), .C(pi2), .Y(po02));
  NAND2x1_ASAP7_75t_R  g22(.A(new_n36), .B(new_n37), .Y(new_n57));
  AOI221x1_ASAP7_75t_R g23(.A1(pi0), .A2(new_n41), .B1(pi3), .B2(new_n57), .C(new_n44), .Y(po03));
  OA21x2_ASAP7_75t_R   g24(.A1(new_n39), .A2(pi6), .B(pi3), .Y(new_n59));
  OR3x1_ASAP7_75t_R    g25(.A(new_n39), .B(new_n40), .C(pi5), .Y(new_n60));
  AO32x1_ASAP7_75t_R   g26(.A1(pi0), .A2(new_n60), .A3(new_n59), .B1(new_n49), .B2(pi5), .Y(new_n61));
  AO21x1_ASAP7_75t_R   g27(.A1(new_n61), .A2(pi1), .B(pi2), .Y(new_n62));
  AO21x1_ASAP7_75t_R   g28(.A1(new_n38), .A2(pi4), .B(new_n37), .Y(new_n63));
  OA211x2_ASAP7_75t_R  g29(.A1(pi0), .A2(new_n37), .B(new_n62), .C(new_n63), .Y(po04));
  OA211x2_ASAP7_75t_R  g30(.A1(pi2), .A2(new_n59), .B(new_n63), .C(pi1), .Y(po05));
  AND2x2_ASAP7_75t_R   g31(.A(pi0), .B(pi1), .Y(new_n66));
  OR3x1_ASAP7_75t_R    g32(.A(new_n42), .B(new_n66), .C(pi2), .Y(new_n67));
  AO21x1_ASAP7_75t_R   g33(.A1(pi3), .A2(pi4), .B(new_n37), .Y(new_n68));
  OA211x2_ASAP7_75t_R  g34(.A1(pi3), .A2(pi4), .B(new_n67), .C(new_n68), .Y(po06));
  AO22x1_ASAP7_75t_R   g35(.A1(new_n44), .A2(pi1), .B1(pi0), .B2(new_n41), .Y(new_n70));
  AND3x1_ASAP7_75t_R   g36(.A(new_n49), .B(new_n37), .C(new_n36), .Y(new_n71));
  AO21x1_ASAP7_75t_R   g37(.A1(pi2), .A2(new_n70), .B(new_n71), .Y(po07));
  NAND2x1_ASAP7_75t_R  g38(.A(new_n37), .B(new_n54), .Y(new_n73));
  OA211x2_ASAP7_75t_R  g39(.A1(new_n44), .A2(new_n68), .B(new_n73), .C(pi1), .Y(po08));
  OA211x2_ASAP7_75t_R  g40(.A1(new_n41), .A2(new_n57), .B(new_n73), .C(new_n52), .Y(po09));
  OA21x2_ASAP7_75t_R   g41(.A1(new_n39), .A2(pi1), .B(pi3), .Y(new_n76));
  NAND2x1_ASAP7_75t_R  g42(.A(pi1), .B(new_n35), .Y(new_n77));
  AO21x1_ASAP7_75t_R   g43(.A1(new_n47), .A2(new_n77), .B(pi2), .Y(new_n78));
  OA21x2_ASAP7_75t_R   g44(.A1(new_n78), .A2(new_n76), .B(new_n63), .Y(po10));
  OR5x1_ASAP7_75t_R    g45(.A(pi0), .B(pi1), .C(pi2), .D(pi3), .E(pi4), .Y(new_n80));
  INVx1_ASAP7_75t_R    g46(.A(new_n80), .Y(po11));
  NOR2x1_ASAP7_75t_R   g47(.A(new_n39), .B(new_n43), .Y(new_n82));
  OA21x2_ASAP7_75t_R   g48(.A1(new_n82), .A2(pi3), .B(new_n37), .Y(new_n83));
  AO21x1_ASAP7_75t_R   g49(.A1(new_n38), .A2(pi1), .B(pi4), .Y(new_n84));
  AO21x1_ASAP7_75t_R   g50(.A1(pi2), .A2(new_n84), .B(new_n83), .Y(po12));
  AND3x1_ASAP7_75t_R   g51(.A(new_n38), .B(new_n39), .C(pi2), .Y(po19));
  AND3x1_ASAP7_75t_R   g52(.A(new_n44), .B(pi2), .C(pi0), .Y(po13));
  AND3x1_ASAP7_75t_R   g53(.A(new_n44), .B(pi2), .C(new_n35), .Y(po14));
  AND3x1_ASAP7_75t_R   g54(.A(new_n36), .B(new_n39), .C(pi3), .Y(new_n89));
  AND3x1_ASAP7_75t_R   g55(.A(new_n89), .B(pi2), .C(new_n35), .Y(po15));
  AND3x1_ASAP7_75t_R   g56(.A(new_n89), .B(pi2), .C(pi0), .Y(po16));
  AND5x1_ASAP7_75t_R   g57(.A(new_n39), .B(pi2), .C(pi1), .D(pi0), .E(pi3), .Y(po17));
  AND5x1_ASAP7_75t_R   g58(.A(new_n35), .B(new_n39), .C(pi3), .D(pi2), .E(pi1), .Y(po18));
  OAI21x1_ASAP7_75t_R  g59(.A1(new_n66), .A2(new_n42), .B(pi2), .Y(new_n94));
  OA211x2_ASAP7_75t_R  g60(.A1(new_n39), .A2(pi5), .B(new_n66), .C(pi3), .Y(new_n95));
  AO21x1_ASAP7_75t_R   g61(.A1(new_n89), .A2(pi0), .B(pi2), .Y(new_n96));
  OA21x2_ASAP7_75t_R   g62(.A1(new_n96), .A2(new_n95), .B(new_n94), .Y(po20));
  AND5x1_ASAP7_75t_R   g63(.A(new_n40), .B(pi4), .C(pi3), .D(pi1), .E(pi5), .Y(new_n98));
  OA211x2_ASAP7_75t_R  g64(.A1(new_n98), .A2(new_n89), .B(new_n37), .C(pi0), .Y(po21));
  AND3x1_ASAP7_75t_R   g65(.A(new_n60), .B(new_n66), .C(new_n59), .Y(new_n100));
  OA21x2_ASAP7_75t_R   g66(.A1(new_n100), .A2(pi2), .B(new_n94), .Y(po22));
  OA211x2_ASAP7_75t_R  g67(.A1(new_n43), .A2(new_n66), .B(new_n47), .C(new_n37), .Y(po24));
  AND5x1_ASAP7_75t_R   g68(.A(new_n36), .B(new_n37), .C(new_n38), .D(pi4), .E(pi0), .Y(po25));
  assign               po23 = 1'b1;
endmodule


