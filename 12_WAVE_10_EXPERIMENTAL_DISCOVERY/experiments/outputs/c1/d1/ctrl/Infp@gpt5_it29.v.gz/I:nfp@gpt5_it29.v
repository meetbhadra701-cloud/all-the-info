// Benchmark "/w/experiments/inputs/c1/c2/ctrl" written by ABC on Fri Sep 25 09:13:50 2026

module \/w/experiments/inputs/c1/c2/ctrl  ( 
    pi0, pi1, pi2, pi3, pi4, pi5, pi6,
    po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10, po11,
    po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22, po23,
    po24, po25  );
  input  pi0, pi1, pi2, pi3, pi4, pi5, pi6;
  output po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10,
    po11, po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22,
    po23, po24, po25;
  wire new_n35, new_n36, new_n37, new_n38, new_n39, new_n40, new_n41,
    new_n42, new_n43, new_n44, new_n45, new_n46, new_n48, new_n49, new_n50,
    new_n51, new_n52, new_n53, new_n55, new_n56, new_n58, new_n59, new_n60,
    new_n62, new_n63, new_n64, new_n65, new_n66, new_n67, new_n68, new_n69,
    new_n70, new_n73, new_n74, new_n75, new_n77, new_n79, new_n80, new_n82,
    new_n84, new_n85, new_n86, new_n88, new_n90, new_n91, new_n92, new_n97,
    new_n102, new_n103, new_n104, new_n106, new_n108, new_n111;
  INVx1_ASAP7_75t_R    g00(.A(pi0), .Y(new_n35));
  INVx1_ASAP7_75t_R    g01(.A(pi1), .Y(new_n36));
  INVx1_ASAP7_75t_R    g02(.A(pi2), .Y(new_n37));
  INVx1_ASAP7_75t_R    g03(.A(pi3), .Y(new_n38));
  INVx1_ASAP7_75t_R    g04(.A(pi4), .Y(new_n39));
  INVx1_ASAP7_75t_R    g05(.A(pi5), .Y(new_n40));
  INVx1_ASAP7_75t_R    g06(.A(pi6), .Y(new_n41));
  NAND2x1_ASAP7_75t_R  g07(.A(pi3), .B(pi4), .Y(new_n42));
  NOR2x1_ASAP7_75t_R   g08(.A(pi0), .B(pi1), .Y(new_n43));
  NOR2x1_ASAP7_75t_R   g09(.A(pi3), .B(pi4), .Y(new_n44));
  OR3x1_ASAP7_75t_R    g10(.A(new_n36), .B(pi3), .C(pi4), .Y(new_n45));
  AO21x1_ASAP7_75t_R   g11(.A1(new_n45), .A2(new_n42), .B(new_n37), .Y(new_n46));
  OAI21x1_ASAP7_75t_R  g12(.A1(new_n42), .A2(new_n43), .B(new_n46), .Y(po00));
  AND2x2_ASAP7_75t_R   g13(.A(new_n38), .B(pi4), .Y(new_n48));
  NAND2x1_ASAP7_75t_R  g14(.A(pi4), .B(new_n38), .Y(new_n49));
  AO21x1_ASAP7_75t_R   g15(.A1(new_n38), .A2(pi4), .B(new_n36), .Y(new_n50));
  AND3x1_ASAP7_75t_R   g16(.A(new_n35), .B(pi3), .C(pi4), .Y(new_n51));
  OA21x2_ASAP7_75t_R   g17(.A1(new_n51), .A2(pi1), .B(new_n50), .Y(new_n52));
  AO21x1_ASAP7_75t_R   g18(.A1(new_n44), .A2(pi1), .B(new_n37), .Y(new_n53));
  OA21x2_ASAP7_75t_R   g19(.A1(new_n52), .A2(pi2), .B(new_n53), .Y(po01));
  OAI21x1_ASAP7_75t_R  g20(.A1(pi0), .A2(new_n49), .B(pi1), .Y(new_n55));
  AO21x1_ASAP7_75t_R   g21(.A1(pi3), .A2(new_n39), .B(new_n55), .Y(new_n56));
  OA211x2_ASAP7_75t_R  g22(.A1(pi1), .A2(new_n51), .B(new_n56), .C(new_n37), .Y(po02));
  NOR2x1_ASAP7_75t_R   g23(.A(pi1), .B(pi2), .Y(new_n58));
  NOR2x1_ASAP7_75t_R   g24(.A(new_n38), .B(new_n58), .Y(new_n59));
  NOR2x1_ASAP7_75t_R   g25(.A(new_n44), .B(new_n59), .Y(new_n60));
  OA21x2_ASAP7_75t_R   g26(.A1(new_n35), .A2(new_n42), .B(new_n60), .Y(po03));
  AO21x1_ASAP7_75t_R   g27(.A1(new_n41), .A2(pi4), .B(new_n38), .Y(new_n62));
  INVx1_ASAP7_75t_R    g28(.A(new_n62), .Y(new_n63));
  AND2x2_ASAP7_75t_R   g29(.A(new_n40), .B(pi4), .Y(new_n64));
  NAND2x1_ASAP7_75t_R  g30(.A(pi4), .B(new_n40), .Y(new_n65));
  AOI211x1_ASAP7_75t_R g31(.A1(new_n64), .A2(pi6), .B(new_n35), .C(new_n62), .Y(new_n66));
  AND2x2_ASAP7_75t_R   g32(.A(new_n51), .B(pi5), .Y(new_n67));
  OAI21x1_ASAP7_75t_R  g33(.A1(new_n67), .A2(new_n66), .B(pi1), .Y(new_n68));
  AO21x1_ASAP7_75t_R   g34(.A1(new_n38), .A2(pi4), .B(new_n37), .Y(new_n69));
  OA21x2_ASAP7_75t_R   g35(.A1(new_n49), .A2(new_n35), .B(pi2), .Y(new_n70));
  AOI21x1_ASAP7_75t_R  g36(.A1(new_n37), .A2(new_n68), .B(new_n70), .Y(po04));
  OA211x2_ASAP7_75t_R  g37(.A1(new_n63), .A2(pi2), .B(pi1), .C(new_n69), .Y(po05));
  AND2x2_ASAP7_75t_R   g38(.A(pi0), .B(pi1), .Y(new_n73));
  OR3x1_ASAP7_75t_R    g39(.A(new_n42), .B(new_n73), .C(pi2), .Y(new_n74));
  AO21x1_ASAP7_75t_R   g40(.A1(pi3), .A2(pi4), .B(new_n37), .Y(new_n75));
  OA211x2_ASAP7_75t_R  g41(.A1(pi3), .A2(pi4), .B(new_n74), .C(new_n75), .Y(po06));
  OAI21x1_ASAP7_75t_R  g42(.A1(new_n35), .A2(new_n42), .B(new_n45), .Y(new_n77));
  AO22x1_ASAP7_75t_R   g43(.A1(new_n77), .A2(pi2), .B1(new_n51), .B2(new_n58), .Y(po07));
  OA211x2_ASAP7_75t_R  g44(.A1(new_n49), .A2(pi0), .B(pi1), .C(new_n37), .Y(new_n79));
  INVx1_ASAP7_75t_R    g45(.A(new_n79), .Y(new_n80));
  OA211x2_ASAP7_75t_R  g46(.A1(new_n44), .A2(new_n75), .B(new_n80), .C(pi1), .Y(po08));
  NAND2x1_ASAP7_75t_R  g47(.A(new_n42), .B(new_n58), .Y(new_n82));
  AND3x1_ASAP7_75t_R   g48(.A(new_n80), .B(new_n82), .C(new_n53), .Y(po09));
  OA21x2_ASAP7_75t_R   g49(.A1(new_n39), .A2(pi1), .B(pi3), .Y(new_n84));
  NAND2x1_ASAP7_75t_R  g50(.A(pi1), .B(new_n35), .Y(new_n85));
  AO21x1_ASAP7_75t_R   g51(.A1(new_n48), .A2(new_n85), .B(pi2), .Y(new_n86));
  OA21x2_ASAP7_75t_R   g52(.A1(new_n86), .A2(new_n84), .B(new_n69), .Y(po10));
  OR5x1_ASAP7_75t_R    g53(.A(pi0), .B(pi1), .C(pi2), .D(pi3), .E(pi4), .Y(new_n88));
  INVx1_ASAP7_75t_R    g54(.A(new_n88), .Y(po11));
  NOR2x1_ASAP7_75t_R   g55(.A(new_n39), .B(new_n43), .Y(new_n90));
  OA21x2_ASAP7_75t_R   g56(.A1(new_n90), .A2(pi3), .B(new_n37), .Y(new_n91));
  AO21x1_ASAP7_75t_R   g57(.A1(new_n38), .A2(pi1), .B(pi4), .Y(new_n92));
  AO21x1_ASAP7_75t_R   g58(.A1(pi2), .A2(new_n92), .B(new_n91), .Y(po12));
  AND3x1_ASAP7_75t_R   g59(.A(new_n38), .B(new_n39), .C(pi2), .Y(po19));
  AND3x1_ASAP7_75t_R   g60(.A(new_n44), .B(pi2), .C(pi0), .Y(po13));
  AND3x1_ASAP7_75t_R   g61(.A(new_n44), .B(pi2), .C(new_n35), .Y(po14));
  AND3x1_ASAP7_75t_R   g62(.A(new_n36), .B(new_n39), .C(pi3), .Y(new_n97));
  AND3x1_ASAP7_75t_R   g63(.A(new_n97), .B(pi2), .C(new_n35), .Y(po15));
  AND3x1_ASAP7_75t_R   g64(.A(new_n97), .B(pi2), .C(pi0), .Y(po16));
  AND5x1_ASAP7_75t_R   g65(.A(new_n39), .B(pi2), .C(pi1), .D(pi0), .E(pi3), .Y(po17));
  AND5x1_ASAP7_75t_R   g66(.A(new_n35), .B(new_n39), .C(pi3), .D(pi2), .E(pi1), .Y(po18));
  OAI21x1_ASAP7_75t_R  g67(.A1(new_n73), .A2(new_n42), .B(pi2), .Y(new_n102));
  AND3x1_ASAP7_75t_R   g68(.A(new_n65), .B(new_n73), .C(pi3), .Y(new_n103));
  AO21x1_ASAP7_75t_R   g69(.A1(new_n97), .A2(pi0), .B(pi2), .Y(new_n104));
  OA21x2_ASAP7_75t_R   g70(.A1(new_n103), .A2(new_n104), .B(new_n102), .Y(po20));
  AND5x1_ASAP7_75t_R   g71(.A(new_n41), .B(pi4), .C(pi3), .D(pi1), .E(pi5), .Y(new_n106));
  OA211x2_ASAP7_75t_R  g72(.A1(new_n106), .A2(new_n97), .B(new_n37), .C(pi0), .Y(po21));
  OA211x2_ASAP7_75t_R  g73(.A1(new_n41), .A2(new_n65), .B(new_n63), .C(new_n73), .Y(new_n108));
  OA21x2_ASAP7_75t_R   g74(.A1(new_n108), .A2(pi2), .B(new_n102), .Y(po22));
  OA211x2_ASAP7_75t_R  g75(.A1(new_n43), .A2(new_n73), .B(new_n48), .C(new_n37), .Y(po24));
  OR5x1_ASAP7_75t_R    g76(.A(new_n35), .B(new_n39), .C(pi3), .D(pi2), .E(pi1), .Y(new_n111));
  INVx1_ASAP7_75t_R    g77(.A(new_n111), .Y(po25));
  assign               po23 = 1'b1;
endmodule


