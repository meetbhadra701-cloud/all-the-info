// Benchmark "/w/experiments/inputs/c1/c2/c880" written by ABC on Fri Sep 25 10:26:43 2026

module \/w/experiments/inputs/c1/c2/c880  ( 
    pi00, pi01, pi02, pi03, pi04, pi05, pi06, pi07, pi08, pi09, pi10, pi11,
    pi12, pi13, pi14, pi15, pi16, pi17, pi18, pi19, pi20, pi21, pi22, pi23,
    pi24, pi25, pi26, pi27, pi28, pi29, pi30, pi31, pi32, pi33, pi34, pi35,
    pi36, pi37, pi38, pi39, pi40, pi41, pi42, pi43, pi44, pi45, pi46, pi47,
    pi48, pi49, pi50, pi51, pi52, pi53, pi54, pi55, pi56, pi57, pi58, pi59,
    po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10, po11,
    po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22, po23,
    po24, po25  );
  input  pi00, pi01, pi02, pi03, pi04, pi05, pi06, pi07, pi08, pi09,
    pi10, pi11, pi12, pi13, pi14, pi15, pi16, pi17, pi18, pi19, pi20, pi21,
    pi22, pi23, pi24, pi25, pi26, pi27, pi28, pi29, pi30, pi31, pi32, pi33,
    pi34, pi35, pi36, pi37, pi38, pi39, pi40, pi41, pi42, pi43, pi44, pi45,
    pi46, pi47, pi48, pi49, pi50, pi51, pi52, pi53, pi54, pi55, pi56, pi57,
    pi58, pi59;
  output po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10,
    po11, po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22,
    po23, po24, po25;
  wire new_n87, new_n88, new_n89, new_n90, new_n91, new_n92, new_n93,
    new_n94, new_n95, new_n96, new_n97, new_n99, new_n101, new_n104,
    new_n112, new_n114, new_n115, new_n117, new_n120, new_n121, new_n122,
    new_n123, new_n124, new_n125, new_n126, new_n127, new_n129, new_n130,
    new_n131, new_n132, new_n133, new_n134, new_n135, new_n136, new_n138,
    new_n139, new_n140, new_n141, new_n142, new_n143, new_n144, new_n145,
    new_n146, new_n147, new_n148, new_n149, new_n150, new_n151, new_n152,
    new_n153, new_n154, new_n155, new_n156, new_n157, new_n159, new_n160,
    new_n161, new_n162, new_n163, new_n164, new_n165, new_n166, new_n167,
    new_n168, new_n169, new_n170, new_n171, new_n172, new_n173, new_n174,
    new_n176, new_n177, new_n178, new_n179, new_n180, new_n181, new_n183,
    new_n184, new_n185, new_n186, new_n187, new_n188, new_n190, new_n191,
    new_n192, new_n193, new_n194, new_n195, new_n196, new_n197, new_n198,
    new_n199, new_n200, new_n201, new_n202, new_n203, new_n204, new_n205,
    new_n206, new_n207, new_n209, new_n210, new_n211, new_n212, new_n213,
    new_n214, new_n216, new_n217, new_n218, new_n219, new_n220, new_n221,
    new_n223, new_n224, new_n225, new_n226, new_n227, new_n228, new_n230,
    new_n231, new_n232, new_n233, new_n234, new_n235;
  INVx1_ASAP7_75t_R    g000(.A(pi10), .Y(new_n87));
  INVx1_ASAP7_75t_R    g001(.A(pi31), .Y(new_n88));
  INVx1_ASAP7_75t_R    g002(.A(pi32), .Y(new_n89));
  INVx1_ASAP7_75t_R    g003(.A(pi33), .Y(new_n90));
  INVx1_ASAP7_75t_R    g004(.A(pi34), .Y(new_n91));
  INVx1_ASAP7_75t_R    g005(.A(pi35), .Y(new_n92));
  INVx1_ASAP7_75t_R    g006(.A(pi36), .Y(new_n93));
  INVx1_ASAP7_75t_R    g007(.A(pi45), .Y(new_n94));
  INVx1_ASAP7_75t_R    g008(.A(pi48), .Y(new_n95));
  INVx1_ASAP7_75t_R    g009(.A(pi51), .Y(new_n96));
  AND2x2_ASAP7_75t_R   g010(.A(pi01), .B(pi02), .Y(new_n97));
  NAND2x1_ASAP7_75t_R  g011(.A(pi00), .B(new_n97), .Y(po00));
  AND3x1_ASAP7_75t_R   g012(.A(pi02), .B(pi03), .C(pi04), .Y(new_n99));
  INVx1_ASAP7_75t_R    g013(.A(new_n99), .Y(po01));
  AND3x1_ASAP7_75t_R   g014(.A(pi00), .B(pi02), .C(pi04), .Y(new_n101));
  INVx1_ASAP7_75t_R    g015(.A(new_n101), .Y(po02));
  NAND2x1_ASAP7_75t_R  g016(.A(pi05), .B(pi06), .Y(po03));
  AND4x2_ASAP7_75t_R   g017(.A(pi07), .B(pi08), .C(pi09), .D(pi10), .Y(new_n104));
  INVx1_ASAP7_75t_R    g018(.A(new_n104), .Y(po04));
  AND5x1_ASAP7_75t_R   g019(.A(po02), .B(pi10), .C(pi08), .D(pi07), .E(pi11), .Y(po05));
  AND3x1_ASAP7_75t_R   g020(.A(pi01), .B(pi03), .C(pi12), .Y(po06));
  AND3x1_ASAP7_75t_R   g021(.A(pi03), .B(pi04), .C(pi12), .Y(po07));
  AND3x1_ASAP7_75t_R   g022(.A(pi00), .B(pi04), .C(pi12), .Y(po08));
  OAI21x1_ASAP7_75t_R  g023(.A1(pi14), .A2(pi15), .B(pi13), .Y(po09));
  AND5x1_ASAP7_75t_R   g024(.A(new_n101), .B(pi10), .C(pi08), .D(pi07), .E(pi11), .Y(po10));
  AND3x1_ASAP7_75t_R   g025(.A(pi10), .B(pi11), .C(pi16), .Y(new_n112));
  INVx1_ASAP7_75t_R    g026(.A(new_n112), .Y(po11));
  AND4x2_ASAP7_75t_R   g027(.A(pi08), .B(pi09), .C(pi10), .D(pi17), .Y(new_n114));
  AND3x1_ASAP7_75t_R   g028(.A(new_n114), .B(pi18), .C(pi02), .Y(new_n115));
  INVx1_ASAP7_75t_R    g029(.A(new_n115), .Y(po12));
  AND3x1_ASAP7_75t_R   g030(.A(new_n114), .B(pi18), .C(pi12), .Y(new_n117));
  NAND2x1_ASAP7_75t_R  g031(.A(pi19), .B(new_n117), .Y(po13));
  OAI21x1_ASAP7_75t_R  g032(.A1(pi14), .A2(pi15), .B(pi20), .Y(po14));
  XOR2x2_ASAP7_75t_R   g033(.A(pi22), .B(pi23), .Y(new_n120));
  XOR2x2_ASAP7_75t_R   g034(.A(new_n120), .B(pi21), .Y(new_n121));
  XNOR2x2_ASAP7_75t_R  g035(.A(pi28), .B(pi29), .Y(new_n122));
  XOR2x2_ASAP7_75t_R   g036(.A(new_n121), .B(new_n122), .Y(new_n123));
  XOR2x2_ASAP7_75t_R   g037(.A(pi26), .B(pi27), .Y(new_n124));
  XOR2x2_ASAP7_75t_R   g038(.A(new_n124), .B(pi30), .Y(new_n125));
  XOR2x2_ASAP7_75t_R   g039(.A(pi24), .B(pi25), .Y(new_n126));
  XOR2x2_ASAP7_75t_R   g040(.A(new_n125), .B(new_n126), .Y(new_n127));
  XOR2x2_ASAP7_75t_R   g041(.A(new_n123), .B(new_n127), .Y(po15));
  XOR2x2_ASAP7_75t_R   g042(.A(pi31), .B(pi32), .Y(new_n129));
  XOR2x2_ASAP7_75t_R   g043(.A(new_n129), .B(pi21), .Y(new_n130));
  XNOR2x2_ASAP7_75t_R  g044(.A(pi37), .B(pi38), .Y(new_n131));
  XOR2x2_ASAP7_75t_R   g045(.A(new_n130), .B(new_n131), .Y(new_n132));
  XOR2x2_ASAP7_75t_R   g046(.A(pi35), .B(pi36), .Y(new_n133));
  XOR2x2_ASAP7_75t_R   g047(.A(new_n133), .B(pi39), .Y(new_n134));
  XOR2x2_ASAP7_75t_R   g048(.A(pi33), .B(pi34), .Y(new_n135));
  XOR2x2_ASAP7_75t_R   g049(.A(new_n134), .B(new_n135), .Y(new_n136));
  XOR2x2_ASAP7_75t_R   g050(.A(new_n132), .B(new_n136), .Y(po16));
  OR2x4_ASAP7_75t_R    g051(.A(pi00), .B(pi07), .Y(new_n138));
  NAND2x1_ASAP7_75t_R  g052(.A(pi12), .B(pi47), .Y(new_n139));
  AOI21x1_ASAP7_75t_R  g053(.A1(pi00), .A2(pi07), .B(new_n139), .Y(new_n140));
  AND3x1_ASAP7_75t_R   g054(.A(pi00), .B(pi01), .C(pi12), .Y(new_n141));
  INVx1_ASAP7_75t_R    g055(.A(new_n141), .Y(new_n142));
  AND4x2_ASAP7_75t_R   g056(.A(pi07), .B(pi09), .C(pi10), .D(pi16), .Y(new_n143));
  AO32x1_ASAP7_75t_R   g057(.A1(new_n112), .A2(new_n140), .A3(new_n138), .B1(new_n143), .B2(new_n142), .Y(new_n144));
  AND2x2_ASAP7_75t_R   g058(.A(new_n112), .B(new_n139), .Y(new_n145));
  AO21x1_ASAP7_75t_R   g059(.A1(new_n145), .A2(pi07), .B(new_n87), .Y(new_n146));
  AND3x1_ASAP7_75t_R   g060(.A(new_n112), .B(new_n97), .C(pi03), .Y(new_n147));
  AND3x1_ASAP7_75t_R   g061(.A(new_n147), .B(new_n94), .C(pi17), .Y(new_n148));
  AO221x2_ASAP7_75t_R  g062(.A1(pi29), .A2(new_n144), .B1(new_n146), .B2(pi46), .C(new_n148), .Y(new_n149));
  XOR2x2_ASAP7_75t_R   g063(.A(new_n149), .B(pi38), .Y(new_n150));
  OAI21x1_ASAP7_75t_R  g064(.A1(pi38), .A2(new_n149), .B(pi52), .Y(new_n151));
  AO21x1_ASAP7_75t_R   g065(.A1(pi38), .A2(new_n149), .B(new_n151), .Y(new_n152));
  OA211x2_ASAP7_75t_R  g066(.A1(pi52), .A2(new_n150), .B(new_n152), .C(pi51), .Y(new_n153));
  AO21x1_ASAP7_75t_R   g067(.A1(pi38), .A2(pi49), .B(pi44), .Y(new_n154));
  AND4x2_ASAP7_75t_R   g068(.A(new_n117), .B(pi41), .C(pi40), .D(pi00), .Y(new_n155));
  AO222x2_ASAP7_75t_R  g069(.A1(pi42), .A2(pi43), .B1(pi50), .B2(pi28), .C1(pi38), .C2(new_n155), .Y(new_n156));
  AO21x1_ASAP7_75t_R   g070(.A1(new_n149), .A2(new_n154), .B(new_n156), .Y(new_n157));
  AOI211x1_ASAP7_75t_R g071(.A1(pi48), .A2(new_n150), .B(new_n153), .C(new_n157), .Y(po17));
  AOI221x1_ASAP7_75t_R g072(.A1(pi26), .A2(new_n144), .B1(new_n146), .B2(pi53), .C(new_n148), .Y(new_n159));
  INVx1_ASAP7_75t_R    g073(.A(new_n159), .Y(new_n160));
  XOR2x2_ASAP7_75t_R   g074(.A(new_n159), .B(pi35), .Y(new_n161));
  AOI221x1_ASAP7_75t_R g075(.A1(pi27), .A2(new_n144), .B1(new_n146), .B2(pi55), .C(new_n148), .Y(new_n162));
  INVx1_ASAP7_75t_R    g076(.A(new_n162), .Y(new_n163));
  NOR2x1_ASAP7_75t_R   g077(.A(new_n93), .B(new_n162), .Y(new_n164));
  NAND2x1_ASAP7_75t_R  g078(.A(new_n93), .B(new_n162), .Y(new_n165));
  AO221x2_ASAP7_75t_R  g079(.A1(pi28), .A2(new_n144), .B1(new_n146), .B2(pi54), .C(new_n148), .Y(new_n166));
  MAJx2_ASAP7_75t_R    g080(.A(new_n149), .B(pi52), .C(pi38), .Y(new_n167));
  MAJx2_ASAP7_75t_R    g081(.A(new_n167), .B(new_n166), .C(pi37), .Y(new_n168));
  AOI21x1_ASAP7_75t_R  g082(.A1(new_n165), .A2(new_n168), .B(new_n164), .Y(new_n169));
  OAI21x1_ASAP7_75t_R  g083(.A1(new_n161), .A2(new_n169), .B(pi51), .Y(new_n170));
  AO21x1_ASAP7_75t_R   g084(.A1(new_n161), .A2(new_n169), .B(new_n170), .Y(new_n171));
  AO21x1_ASAP7_75t_R   g085(.A1(pi35), .A2(pi49), .B(pi44), .Y(new_n172));
  AO222x2_ASAP7_75t_R  g086(.A1(pi25), .A2(pi50), .B1(new_n155), .B2(pi35), .C1(new_n172), .C2(new_n160), .Y(new_n173));
  INVx1_ASAP7_75t_R    g087(.A(new_n173), .Y(new_n174));
  OA211x2_ASAP7_75t_R  g088(.A1(new_n95), .A2(new_n161), .B(new_n171), .C(new_n174), .Y(po18));
  XOR2x2_ASAP7_75t_R   g089(.A(new_n162), .B(new_n93), .Y(new_n176));
  AOI21x1_ASAP7_75t_R  g090(.A1(new_n176), .A2(new_n168), .B(new_n96), .Y(new_n177));
  OA21x2_ASAP7_75t_R   g091(.A1(new_n168), .A2(new_n176), .B(new_n177), .Y(new_n178));
  AO21x1_ASAP7_75t_R   g092(.A1(pi36), .A2(pi49), .B(pi44), .Y(new_n179));
  AO222x2_ASAP7_75t_R  g093(.A1(pi26), .A2(pi50), .B1(pi56), .B2(pi42), .C1(pi36), .C2(new_n155), .Y(new_n180));
  AO221x2_ASAP7_75t_R  g094(.A1(new_n163), .A2(new_n179), .B1(pi48), .B2(new_n176), .C(new_n180), .Y(new_n181));
  NOR2x1_ASAP7_75t_R   g095(.A(new_n181), .B(new_n178), .Y(po19));
  XOR2x2_ASAP7_75t_R   g096(.A(new_n166), .B(pi37), .Y(new_n183));
  OAI21x1_ASAP7_75t_R  g097(.A1(new_n167), .A2(new_n183), .B(pi51), .Y(new_n184));
  AOI21x1_ASAP7_75t_R  g098(.A1(new_n167), .A2(new_n183), .B(new_n184), .Y(new_n185));
  AO21x1_ASAP7_75t_R   g099(.A1(pi37), .A2(pi49), .B(pi44), .Y(new_n186));
  AO222x2_ASAP7_75t_R  g100(.A1(pi27), .A2(pi50), .B1(pi57), .B2(pi42), .C1(pi37), .C2(new_n155), .Y(new_n187));
  AO221x2_ASAP7_75t_R  g101(.A1(new_n166), .A2(new_n186), .B1(pi48), .B2(new_n183), .C(new_n187), .Y(new_n188));
  NOR2x1_ASAP7_75t_R   g102(.A(new_n188), .B(new_n185), .Y(po20));
  AND3x1_ASAP7_75t_R   g103(.A(new_n112), .B(new_n139), .C(pi17), .Y(new_n190));
  AND3x1_ASAP7_75t_R   g104(.A(new_n147), .B(new_n94), .C(pi07), .Y(new_n191));
  AO221x2_ASAP7_75t_R  g105(.A1(pi09), .A2(pi58), .B1(new_n190), .B2(pi53), .C(new_n191), .Y(new_n192));
  AO21x1_ASAP7_75t_R   g106(.A1(pi22), .A2(new_n144), .B(new_n192), .Y(new_n193));
  INVx1_ASAP7_75t_R    g107(.A(new_n193), .Y(new_n194));
  AO221x2_ASAP7_75t_R  g108(.A1(pi16), .A2(pi58), .B1(new_n190), .B2(pi55), .C(new_n191), .Y(new_n195));
  AO21x1_ASAP7_75t_R   g109(.A1(pi23), .A2(new_n144), .B(new_n195), .Y(new_n196));
  INVx1_ASAP7_75t_R    g110(.A(new_n196), .Y(new_n197));
  AO221x2_ASAP7_75t_R  g111(.A1(pi07), .A2(pi58), .B1(new_n190), .B2(pi54), .C(new_n191), .Y(new_n198));
  AO21x1_ASAP7_75t_R   g112(.A1(pi24), .A2(new_n144), .B(new_n198), .Y(new_n199));
  INVx1_ASAP7_75t_R    g113(.A(new_n199), .Y(new_n200));
  AO221x2_ASAP7_75t_R  g114(.A1(pi58), .A2(pi59), .B1(new_n190), .B2(pi46), .C(new_n191), .Y(new_n201));
  AO21x1_ASAP7_75t_R   g115(.A1(pi25), .A2(new_n144), .B(new_n201), .Y(new_n202));
  INVx1_ASAP7_75t_R    g116(.A(new_n202), .Y(new_n203));
  MAJx2_ASAP7_75t_R    g117(.A(new_n169), .B(new_n159), .C(new_n92), .Y(new_n204));
  MAJx2_ASAP7_75t_R    g118(.A(new_n204), .B(new_n203), .C(new_n91), .Y(new_n205));
  MAJx2_ASAP7_75t_R    g119(.A(new_n205), .B(new_n200), .C(new_n90), .Y(new_n206));
  MAJx2_ASAP7_75t_R    g120(.A(new_n206), .B(new_n197), .C(new_n89), .Y(new_n207));
  MAJx2_ASAP7_75t_R    g121(.A(new_n207), .B(new_n194), .C(new_n88), .Y(po21));
  XOR2x2_ASAP7_75t_R   g122(.A(new_n202), .B(new_n91), .Y(new_n209));
  OAI21x1_ASAP7_75t_R  g123(.A1(new_n209), .A2(new_n204), .B(pi51), .Y(new_n210));
  AO21x1_ASAP7_75t_R   g124(.A1(new_n204), .A2(new_n209), .B(new_n210), .Y(new_n211));
  AO21x1_ASAP7_75t_R   g125(.A1(pi34), .A2(pi49), .B(pi44), .Y(new_n212));
  AO222x2_ASAP7_75t_R  g126(.A1(pi24), .A2(pi50), .B1(new_n155), .B2(pi34), .C1(new_n212), .C2(new_n202), .Y(new_n213));
  INVx1_ASAP7_75t_R    g127(.A(new_n213), .Y(new_n214));
  OA211x2_ASAP7_75t_R  g128(.A1(new_n95), .A2(new_n209), .B(new_n211), .C(new_n214), .Y(po22));
  XOR2x2_ASAP7_75t_R   g129(.A(new_n193), .B(new_n88), .Y(new_n216));
  INVx1_ASAP7_75t_R    g130(.A(new_n216), .Y(new_n217));
  NAND2x1_ASAP7_75t_R  g131(.A(new_n216), .B(new_n207), .Y(new_n218));
  OA21x2_ASAP7_75t_R   g132(.A1(new_n207), .A2(new_n216), .B(pi51), .Y(new_n219));
  AO21x1_ASAP7_75t_R   g133(.A1(pi31), .A2(pi49), .B(pi44), .Y(new_n220));
  AO222x2_ASAP7_75t_R  g134(.A1(pi45), .A2(pi50), .B1(new_n155), .B2(pi31), .C1(new_n220), .C2(new_n193), .Y(new_n221));
  AOI221x1_ASAP7_75t_R g135(.A1(pi48), .A2(new_n217), .B1(new_n219), .B2(new_n218), .C(new_n221), .Y(po23));
  XOR2x2_ASAP7_75t_R   g136(.A(new_n196), .B(new_n89), .Y(new_n223));
  OAI21x1_ASAP7_75t_R  g137(.A1(new_n223), .A2(new_n206), .B(pi51), .Y(new_n224));
  AO21x1_ASAP7_75t_R   g138(.A1(new_n206), .A2(new_n223), .B(new_n224), .Y(new_n225));
  AO21x1_ASAP7_75t_R   g139(.A1(pi32), .A2(pi49), .B(pi44), .Y(new_n226));
  AO222x2_ASAP7_75t_R  g140(.A1(pi22), .A2(pi50), .B1(new_n155), .B2(pi32), .C1(new_n226), .C2(new_n196), .Y(new_n227));
  INVx1_ASAP7_75t_R    g141(.A(new_n227), .Y(new_n228));
  OA211x2_ASAP7_75t_R  g142(.A1(new_n95), .A2(new_n223), .B(new_n225), .C(new_n228), .Y(po24));
  XOR2x2_ASAP7_75t_R   g143(.A(new_n199), .B(new_n90), .Y(new_n230));
  OAI21x1_ASAP7_75t_R  g144(.A1(new_n230), .A2(new_n205), .B(pi51), .Y(new_n231));
  AO21x1_ASAP7_75t_R   g145(.A1(new_n205), .A2(new_n230), .B(new_n231), .Y(new_n232));
  AO21x1_ASAP7_75t_R   g146(.A1(pi33), .A2(pi49), .B(pi44), .Y(new_n233));
  AO222x2_ASAP7_75t_R  g147(.A1(pi23), .A2(pi50), .B1(new_n155), .B2(pi33), .C1(new_n233), .C2(new_n199), .Y(new_n234));
  INVx1_ASAP7_75t_R    g148(.A(new_n234), .Y(new_n235));
  OA211x2_ASAP7_75t_R  g149(.A1(new_n95), .A2(new_n230), .B(new_n232), .C(new_n235), .Y(po25));
endmodule


