// Benchmark "/w/experiments/inputs/c1/c2/c880" written by ABC on Fri Sep 25 10:26:42 2026

module \/w/experiments/inputs/c1/c2/c880  ( 
    pi00, pi01, pi02, pi03, pi04, pi05, pi06, pi07, pi08, pi09, pi10, pi11,
    pi12, pi13, pi14, pi15, pi16, pi17, pi18, pi19, pi20, pi21, pi22, pi23,
    pi24, pi25, pi26, pi27, pi28, pi29, pi30, pi31, pi32, pi33, pi34, pi35,
    pi36, pi37, pi38, pi39, pi40, pi41, pi42, pi43, pi44, pi45, pi46, pi47,
    pi48, pi49, pi50, pi51, pi52, pi53, pi54, pi55, pi56, pi57, pi58, pi59,
    po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10, po11,
    po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22, po23,
    po24, po25  );
  input  pi00, pi01, pi02, pi03, pi04, pi05, pi06, pi07, pi08, pi09,
    pi10, pi11, pi12, pi13, pi14, pi15, pi16, pi17, pi18, pi19, pi20, pi21,
    pi22, pi23, pi24, pi25, pi26, pi27, pi28, pi29, pi30, pi31, pi32, pi33,
    pi34, pi35, pi36, pi37, pi38, pi39, pi40, pi41, pi42, pi43, pi44, pi45,
    pi46, pi47, pi48, pi49, pi50, pi51, pi52, pi53, pi54, pi55, pi56, pi57,
    pi58, pi59;
  output po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10,
    po11, po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22,
    po23, po24, po25;
  wire new_n87, new_n88, new_n89, new_n90, new_n91, new_n92, new_n93,
    new_n94, new_n95, new_n97, new_n99, new_n102, new_n105, new_n111,
    new_n113, new_n114, new_n116, new_n119, new_n120, new_n121, new_n122,
    new_n123, new_n124, new_n125, new_n126, new_n128, new_n129, new_n130,
    new_n131, new_n132, new_n133, new_n134, new_n135, new_n137, new_n138,
    new_n139, new_n140, new_n141, new_n142, new_n143, new_n144, new_n145,
    new_n146, new_n147, new_n148, new_n149, new_n150, new_n151, new_n152,
    new_n153, new_n154, new_n155, new_n156, new_n157, new_n158, new_n159,
    new_n160, new_n161, new_n163, new_n164, new_n165, new_n166, new_n167,
    new_n168, new_n169, new_n170, new_n171, new_n172, new_n173, new_n174,
    new_n175, new_n176, new_n177, new_n178, new_n179, new_n180, new_n181,
    new_n183, new_n184, new_n185, new_n186, new_n187, new_n188, new_n190,
    new_n191, new_n192, new_n193, new_n194, new_n195, new_n196, new_n198,
    new_n199, new_n200, new_n201, new_n202, new_n203, new_n204, new_n205,
    new_n206, new_n207, new_n208, new_n209, new_n210, new_n211, new_n212,
    new_n213, new_n214, new_n215, new_n217, new_n218, new_n219, new_n220,
    new_n221, new_n222, new_n224, new_n225, new_n226, new_n227, new_n228,
    new_n229, new_n231, new_n232, new_n233, new_n234, new_n235, new_n236,
    new_n238, new_n239, new_n240, new_n241, new_n242, new_n243;
  INVx1_ASAP7_75t_R    g000(.A(pi00), .Y(new_n87));
  INVx1_ASAP7_75t_R    g001(.A(pi10), .Y(new_n88));
  INVx1_ASAP7_75t_R    g002(.A(pi31), .Y(new_n89));
  INVx1_ASAP7_75t_R    g003(.A(pi32), .Y(new_n90));
  INVx1_ASAP7_75t_R    g004(.A(pi33), .Y(new_n91));
  INVx1_ASAP7_75t_R    g005(.A(pi34), .Y(new_n92));
  INVx1_ASAP7_75t_R    g006(.A(pi45), .Y(new_n93));
  INVx1_ASAP7_75t_R    g007(.A(pi48), .Y(new_n94));
  INVx1_ASAP7_75t_R    g008(.A(pi51), .Y(new_n95));
  NAND3x1_ASAP7_75t_R  g009(.A(pi00), .B(pi01), .C(pi02), .Y(po00));
  AND3x1_ASAP7_75t_R   g010(.A(pi02), .B(pi03), .C(pi04), .Y(new_n97));
  INVx1_ASAP7_75t_R    g011(.A(new_n97), .Y(po01));
  AND3x1_ASAP7_75t_R   g012(.A(pi00), .B(pi02), .C(pi04), .Y(new_n99));
  INVx1_ASAP7_75t_R    g013(.A(new_n99), .Y(po02));
  NAND2x1_ASAP7_75t_R  g014(.A(pi05), .B(pi06), .Y(po03));
  AND4x2_ASAP7_75t_R   g015(.A(pi07), .B(pi08), .C(pi09), .D(pi10), .Y(new_n102));
  INVx1_ASAP7_75t_R    g016(.A(new_n102), .Y(po04));
  AND5x1_ASAP7_75t_R   g017(.A(po02), .B(pi10), .C(pi08), .D(pi07), .E(pi11), .Y(po05));
  NAND2x1_ASAP7_75t_R  g018(.A(pi01), .B(pi12), .Y(new_n105));
  AND3x1_ASAP7_75t_R   g019(.A(pi01), .B(pi03), .C(pi12), .Y(po06));
  AND3x1_ASAP7_75t_R   g020(.A(pi03), .B(pi04), .C(pi12), .Y(po07));
  AND3x1_ASAP7_75t_R   g021(.A(pi00), .B(pi04), .C(pi12), .Y(po08));
  OAI21x1_ASAP7_75t_R  g022(.A1(pi14), .A2(pi15), .B(pi13), .Y(po09));
  AND5x1_ASAP7_75t_R   g023(.A(new_n99), .B(pi10), .C(pi08), .D(pi07), .E(pi11), .Y(po10));
  AND3x1_ASAP7_75t_R   g024(.A(pi10), .B(pi11), .C(pi16), .Y(new_n111));
  INVx1_ASAP7_75t_R    g025(.A(new_n111), .Y(po11));
  AND4x2_ASAP7_75t_R   g026(.A(pi08), .B(pi09), .C(pi10), .D(pi17), .Y(new_n113));
  AND3x1_ASAP7_75t_R   g027(.A(new_n113), .B(pi18), .C(pi02), .Y(new_n114));
  INVx1_ASAP7_75t_R    g028(.A(new_n114), .Y(po12));
  AND3x1_ASAP7_75t_R   g029(.A(new_n113), .B(pi18), .C(pi12), .Y(new_n116));
  NAND2x1_ASAP7_75t_R  g030(.A(pi19), .B(new_n116), .Y(po13));
  OAI21x1_ASAP7_75t_R  g031(.A1(pi14), .A2(pi15), .B(pi20), .Y(po14));
  XOR2x2_ASAP7_75t_R   g032(.A(pi22), .B(pi23), .Y(new_n119));
  XOR2x2_ASAP7_75t_R   g033(.A(new_n119), .B(pi21), .Y(new_n120));
  XNOR2x2_ASAP7_75t_R  g034(.A(pi28), .B(pi29), .Y(new_n121));
  XOR2x2_ASAP7_75t_R   g035(.A(new_n120), .B(new_n121), .Y(new_n122));
  XOR2x2_ASAP7_75t_R   g036(.A(pi26), .B(pi27), .Y(new_n123));
  XOR2x2_ASAP7_75t_R   g037(.A(new_n123), .B(pi30), .Y(new_n124));
  XOR2x2_ASAP7_75t_R   g038(.A(pi24), .B(pi25), .Y(new_n125));
  XOR2x2_ASAP7_75t_R   g039(.A(new_n124), .B(new_n125), .Y(new_n126));
  XOR2x2_ASAP7_75t_R   g040(.A(new_n122), .B(new_n126), .Y(po15));
  XOR2x2_ASAP7_75t_R   g041(.A(pi31), .B(pi32), .Y(new_n128));
  XOR2x2_ASAP7_75t_R   g042(.A(new_n128), .B(pi21), .Y(new_n129));
  XNOR2x2_ASAP7_75t_R  g043(.A(pi37), .B(pi38), .Y(new_n130));
  XOR2x2_ASAP7_75t_R   g044(.A(new_n129), .B(new_n130), .Y(new_n131));
  XOR2x2_ASAP7_75t_R   g045(.A(pi35), .B(pi36), .Y(new_n132));
  XOR2x2_ASAP7_75t_R   g046(.A(new_n132), .B(pi39), .Y(new_n133));
  XOR2x2_ASAP7_75t_R   g047(.A(pi33), .B(pi34), .Y(new_n134));
  XOR2x2_ASAP7_75t_R   g048(.A(new_n133), .B(new_n134), .Y(new_n135));
  XOR2x2_ASAP7_75t_R   g049(.A(new_n131), .B(new_n135), .Y(po16));
  OR2x4_ASAP7_75t_R    g050(.A(pi00), .B(pi07), .Y(new_n137));
  AND2x2_ASAP7_75t_R   g051(.A(pi12), .B(pi47), .Y(new_n138));
  NAND2x1_ASAP7_75t_R  g052(.A(pi12), .B(pi47), .Y(new_n139));
  NAND2x1_ASAP7_75t_R  g053(.A(pi00), .B(pi07), .Y(new_n140));
  AND3x1_ASAP7_75t_R   g054(.A(new_n137), .B(new_n138), .C(new_n140), .Y(new_n141));
  AND4x2_ASAP7_75t_R   g055(.A(new_n111), .B(new_n137), .C(new_n138), .D(new_n140), .Y(new_n142));
  AND4x2_ASAP7_75t_R   g056(.A(pi07), .B(pi09), .C(pi10), .D(pi16), .Y(new_n143));
  OA21x2_ASAP7_75t_R   g057(.A1(new_n87), .A2(new_n105), .B(new_n143), .Y(new_n144));
  AO21x1_ASAP7_75t_R   g058(.A1(new_n141), .A2(new_n111), .B(new_n144), .Y(new_n145));
  OAI21x1_ASAP7_75t_R  g059(.A1(new_n144), .A2(new_n142), .B(pi29), .Y(new_n146));
  AO31x2_ASAP7_75t_R   g060(.A1(pi07), .A2(new_n111), .A3(new_n139), .B(new_n88), .Y(new_n147));
  AND3x1_ASAP7_75t_R   g061(.A(pi01), .B(pi02), .C(pi03), .Y(new_n148));
  AND2x2_ASAP7_75t_R   g062(.A(new_n111), .B(new_n148), .Y(new_n149));
  AND2x2_ASAP7_75t_R   g063(.A(new_n93), .B(pi17), .Y(new_n150));
  AND3x1_ASAP7_75t_R   g064(.A(new_n150), .B(new_n148), .C(new_n111), .Y(new_n151));
  AOI22x1_ASAP7_75t_R  g065(.A1(new_n149), .A2(new_n150), .B1(new_n147), .B2(pi46), .Y(new_n152));
  NAND2x1_ASAP7_75t_R  g066(.A(new_n152), .B(new_n146), .Y(new_n153));
  XOR2x2_ASAP7_75t_R   g067(.A(new_n153), .B(pi38), .Y(new_n154));
  OAI21x1_ASAP7_75t_R  g068(.A1(pi38), .A2(new_n153), .B(pi52), .Y(new_n155));
  AO21x1_ASAP7_75t_R   g069(.A1(new_n153), .A2(pi38), .B(new_n155), .Y(new_n156));
  OA211x2_ASAP7_75t_R  g070(.A1(pi52), .A2(new_n154), .B(new_n156), .C(pi51), .Y(new_n157));
  AO21x1_ASAP7_75t_R   g071(.A1(pi38), .A2(pi49), .B(pi44), .Y(new_n158));
  AND4x2_ASAP7_75t_R   g072(.A(new_n116), .B(pi41), .C(pi40), .D(pi00), .Y(new_n159));
  AO222x2_ASAP7_75t_R  g073(.A1(pi42), .A2(pi43), .B1(pi50), .B2(pi28), .C1(pi38), .C2(new_n159), .Y(new_n160));
  AO221x2_ASAP7_75t_R  g074(.A1(new_n153), .A2(new_n158), .B1(pi48), .B2(new_n154), .C(new_n160), .Y(new_n161));
  NOR2x1_ASAP7_75t_R   g075(.A(new_n157), .B(new_n161), .Y(po17));
  AO221x2_ASAP7_75t_R  g076(.A1(pi53), .A2(new_n147), .B1(pi26), .B2(new_n145), .C(new_n151), .Y(new_n163));
  OR2x4_ASAP7_75t_R    g077(.A(pi35), .B(new_n163), .Y(new_n164));
  AND2x2_ASAP7_75t_R   g078(.A(new_n163), .B(pi35), .Y(new_n165));
  XOR2x2_ASAP7_75t_R   g079(.A(new_n163), .B(pi35), .Y(new_n166));
  AO221x2_ASAP7_75t_R  g080(.A1(pi55), .A2(new_n147), .B1(pi27), .B2(new_n145), .C(new_n151), .Y(new_n167));
  NAND2x1_ASAP7_75t_R  g081(.A(pi36), .B(new_n167), .Y(new_n168));
  NOR2x1_ASAP7_75t_R   g082(.A(pi36), .B(new_n167), .Y(new_n169));
  AO221x2_ASAP7_75t_R  g083(.A1(pi54), .A2(new_n147), .B1(pi28), .B2(new_n145), .C(new_n151), .Y(new_n170));
  AND2x2_ASAP7_75t_R   g084(.A(new_n170), .B(pi37), .Y(new_n171));
  OR2x4_ASAP7_75t_R    g085(.A(pi37), .B(new_n170), .Y(new_n172));
  MAJx2_ASAP7_75t_R    g086(.A(new_n153), .B(pi52), .C(pi38), .Y(new_n173));
  AOI21x1_ASAP7_75t_R  g087(.A1(new_n173), .A2(new_n172), .B(new_n171), .Y(new_n174));
  AO21x1_ASAP7_75t_R   g088(.A1(new_n172), .A2(new_n173), .B(new_n171), .Y(new_n175));
  OAI21x1_ASAP7_75t_R  g089(.A1(new_n169), .A2(new_n174), .B(new_n168), .Y(new_n176));
  AOI21x1_ASAP7_75t_R  g090(.A1(new_n166), .A2(new_n176), .B(new_n95), .Y(new_n177));
  OAI21x1_ASAP7_75t_R  g091(.A1(new_n166), .A2(new_n176), .B(new_n177), .Y(new_n178));
  AO21x1_ASAP7_75t_R   g092(.A1(pi35), .A2(pi49), .B(pi44), .Y(new_n179));
  AO222x2_ASAP7_75t_R  g093(.A1(pi25), .A2(pi50), .B1(new_n159), .B2(pi35), .C1(new_n179), .C2(new_n163), .Y(new_n180));
  AOI21x1_ASAP7_75t_R  g094(.A1(pi48), .A2(new_n166), .B(new_n180), .Y(new_n181));
  AND2x2_ASAP7_75t_R   g095(.A(new_n178), .B(new_n181), .Y(po18));
  XOR2x2_ASAP7_75t_R   g096(.A(new_n167), .B(pi36), .Y(new_n183));
  AOI21x1_ASAP7_75t_R  g097(.A1(new_n183), .A2(new_n175), .B(new_n95), .Y(new_n184));
  OA21x2_ASAP7_75t_R   g098(.A1(new_n175), .A2(new_n183), .B(new_n184), .Y(new_n185));
  AO21x1_ASAP7_75t_R   g099(.A1(pi36), .A2(pi49), .B(pi44), .Y(new_n186));
  AO222x2_ASAP7_75t_R  g100(.A1(pi26), .A2(pi50), .B1(pi56), .B2(pi42), .C1(pi36), .C2(new_n159), .Y(new_n187));
  AO221x2_ASAP7_75t_R  g101(.A1(new_n167), .A2(new_n186), .B1(pi48), .B2(new_n183), .C(new_n187), .Y(new_n188));
  NOR2x1_ASAP7_75t_R   g102(.A(new_n188), .B(new_n185), .Y(po19));
  XNOR2x2_ASAP7_75t_R  g103(.A(pi37), .B(new_n170), .Y(new_n190));
  INVx1_ASAP7_75t_R    g104(.A(new_n190), .Y(new_n191));
  OAI21x1_ASAP7_75t_R  g105(.A1(new_n173), .A2(new_n191), .B(pi51), .Y(new_n192));
  AO21x1_ASAP7_75t_R   g106(.A1(new_n173), .A2(new_n191), .B(new_n192), .Y(new_n193));
  AO21x1_ASAP7_75t_R   g107(.A1(pi37), .A2(pi49), .B(pi44), .Y(new_n194));
  AO222x2_ASAP7_75t_R  g108(.A1(pi27), .A2(pi50), .B1(pi57), .B2(pi42), .C1(pi37), .C2(new_n159), .Y(new_n195));
  AOI21x1_ASAP7_75t_R  g109(.A1(new_n170), .A2(new_n194), .B(new_n195), .Y(new_n196));
  OA211x2_ASAP7_75t_R  g110(.A1(new_n94), .A2(new_n190), .B(new_n193), .C(new_n196), .Y(po20));
  AND3x1_ASAP7_75t_R   g111(.A(new_n111), .B(new_n139), .C(pi17), .Y(new_n198));
  AND3x1_ASAP7_75t_R   g112(.A(new_n149), .B(new_n93), .C(pi07), .Y(new_n199));
  AO221x2_ASAP7_75t_R  g113(.A1(pi09), .A2(pi58), .B1(new_n198), .B2(pi53), .C(new_n199), .Y(new_n200));
  AO21x1_ASAP7_75t_R   g114(.A1(pi22), .A2(new_n145), .B(new_n200), .Y(new_n201));
  INVx1_ASAP7_75t_R    g115(.A(new_n201), .Y(new_n202));
  AO221x2_ASAP7_75t_R  g116(.A1(pi16), .A2(pi58), .B1(new_n198), .B2(pi55), .C(new_n199), .Y(new_n203));
  AO21x1_ASAP7_75t_R   g117(.A1(pi23), .A2(new_n145), .B(new_n203), .Y(new_n204));
  INVx1_ASAP7_75t_R    g118(.A(new_n204), .Y(new_n205));
  AO221x2_ASAP7_75t_R  g119(.A1(pi07), .A2(pi58), .B1(new_n198), .B2(pi54), .C(new_n199), .Y(new_n206));
  AO21x1_ASAP7_75t_R   g120(.A1(pi24), .A2(new_n145), .B(new_n206), .Y(new_n207));
  INVx1_ASAP7_75t_R    g121(.A(new_n207), .Y(new_n208));
  AO221x2_ASAP7_75t_R  g122(.A1(pi58), .A2(pi59), .B1(new_n198), .B2(pi46), .C(new_n199), .Y(new_n209));
  AO21x1_ASAP7_75t_R   g123(.A1(pi25), .A2(new_n145), .B(new_n209), .Y(new_n210));
  INVx1_ASAP7_75t_R    g124(.A(new_n210), .Y(new_n211));
  AOI21x1_ASAP7_75t_R  g125(.A1(new_n164), .A2(new_n176), .B(new_n165), .Y(new_n212));
  MAJx2_ASAP7_75t_R    g126(.A(new_n212), .B(new_n211), .C(new_n92), .Y(new_n213));
  MAJx2_ASAP7_75t_R    g127(.A(new_n213), .B(new_n208), .C(new_n91), .Y(new_n214));
  MAJx2_ASAP7_75t_R    g128(.A(new_n214), .B(new_n205), .C(new_n90), .Y(new_n215));
  MAJx2_ASAP7_75t_R    g129(.A(new_n215), .B(new_n202), .C(new_n89), .Y(po21));
  XOR2x2_ASAP7_75t_R   g130(.A(new_n210), .B(new_n92), .Y(new_n217));
  INVx1_ASAP7_75t_R    g131(.A(new_n217), .Y(new_n218));
  NAND2x1_ASAP7_75t_R  g132(.A(new_n217), .B(new_n212), .Y(new_n219));
  OA21x2_ASAP7_75t_R   g133(.A1(new_n212), .A2(new_n217), .B(pi51), .Y(new_n220));
  AO21x1_ASAP7_75t_R   g134(.A1(pi34), .A2(pi49), .B(pi44), .Y(new_n221));
  AO222x2_ASAP7_75t_R  g135(.A1(pi24), .A2(pi50), .B1(new_n159), .B2(pi34), .C1(new_n221), .C2(new_n210), .Y(new_n222));
  AOI221x1_ASAP7_75t_R g136(.A1(pi48), .A2(new_n218), .B1(new_n220), .B2(new_n219), .C(new_n222), .Y(po22));
  XOR2x2_ASAP7_75t_R   g137(.A(new_n201), .B(new_n89), .Y(new_n224));
  INVx1_ASAP7_75t_R    g138(.A(new_n224), .Y(new_n225));
  NAND2x1_ASAP7_75t_R  g139(.A(new_n224), .B(new_n215), .Y(new_n226));
  OA21x2_ASAP7_75t_R   g140(.A1(new_n215), .A2(new_n224), .B(pi51), .Y(new_n227));
  AO21x1_ASAP7_75t_R   g141(.A1(pi31), .A2(pi49), .B(pi44), .Y(new_n228));
  AO222x2_ASAP7_75t_R  g142(.A1(pi45), .A2(pi50), .B1(new_n159), .B2(pi31), .C1(new_n228), .C2(new_n201), .Y(new_n229));
  AOI221x1_ASAP7_75t_R g143(.A1(pi48), .A2(new_n225), .B1(new_n227), .B2(new_n226), .C(new_n229), .Y(po23));
  XOR2x2_ASAP7_75t_R   g144(.A(new_n204), .B(new_n90), .Y(new_n231));
  OAI21x1_ASAP7_75t_R  g145(.A1(new_n231), .A2(new_n214), .B(pi51), .Y(new_n232));
  AO21x1_ASAP7_75t_R   g146(.A1(new_n214), .A2(new_n231), .B(new_n232), .Y(new_n233));
  AO21x1_ASAP7_75t_R   g147(.A1(pi32), .A2(pi49), .B(pi44), .Y(new_n234));
  AO222x2_ASAP7_75t_R  g148(.A1(pi22), .A2(pi50), .B1(new_n159), .B2(pi32), .C1(new_n234), .C2(new_n204), .Y(new_n235));
  INVx1_ASAP7_75t_R    g149(.A(new_n235), .Y(new_n236));
  OA211x2_ASAP7_75t_R  g150(.A1(new_n94), .A2(new_n231), .B(new_n233), .C(new_n236), .Y(po24));
  XOR2x2_ASAP7_75t_R   g151(.A(new_n207), .B(new_n91), .Y(new_n238));
  OAI21x1_ASAP7_75t_R  g152(.A1(new_n238), .A2(new_n213), .B(pi51), .Y(new_n239));
  AO21x1_ASAP7_75t_R   g153(.A1(new_n213), .A2(new_n238), .B(new_n239), .Y(new_n240));
  AO21x1_ASAP7_75t_R   g154(.A1(pi33), .A2(pi49), .B(pi44), .Y(new_n241));
  AO222x2_ASAP7_75t_R  g155(.A1(pi23), .A2(pi50), .B1(new_n159), .B2(pi33), .C1(new_n241), .C2(new_n207), .Y(new_n242));
  INVx1_ASAP7_75t_R    g156(.A(new_n242), .Y(new_n243));
  OA211x2_ASAP7_75t_R  g157(.A1(new_n94), .A2(new_n238), .B(new_n240), .C(new_n243), .Y(po25));
endmodule


