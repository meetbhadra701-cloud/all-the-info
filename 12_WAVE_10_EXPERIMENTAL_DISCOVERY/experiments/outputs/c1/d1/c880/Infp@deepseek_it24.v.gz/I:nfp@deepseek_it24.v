// Benchmark "/w/experiments/inputs/c1/c2/c880" written by ABC on Fri Sep 25 10:26:39 2026

module \/w/experiments/inputs/c1/c2/c880  ( 
    pi00, pi01, pi02, pi03, pi04, pi05, pi06, pi07, pi08, pi09, pi10, pi11,
    pi12, pi13, pi14, pi15, pi16, pi17, pi18, pi19, pi20, pi21, pi22, pi23,
    pi24, pi25, pi26, pi27, pi28, pi29, pi30, pi31, pi32, pi33, pi34, pi35,
    pi36, pi37, pi38, pi39, pi40, pi41, pi42, pi43, pi44, pi45, pi46, pi47,
    pi48, pi49, pi50, pi51, pi52, pi53, pi54, pi55, pi56, pi57, pi58, pi59,
    po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10, po11,
    po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22, po23,
    po24, po25  );
  input  pi00, pi01, pi02, pi03, pi04, pi05, pi06, pi07, pi08, pi09,
    pi10, pi11, pi12, pi13, pi14, pi15, pi16, pi17, pi18, pi19, pi20, pi21,
    pi22, pi23, pi24, pi25, pi26, pi27, pi28, pi29, pi30, pi31, pi32, pi33,
    pi34, pi35, pi36, pi37, pi38, pi39, pi40, pi41, pi42, pi43, pi44, pi45,
    pi46, pi47, pi48, pi49, pi50, pi51, pi52, pi53, pi54, pi55, pi56, pi57,
    pi58, pi59;
  output po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10,
    po11, po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22,
    po23, po24, po25;
  wire new_n87, new_n88, new_n89, new_n90, new_n91, new_n92, new_n93,
    new_n94, new_n96, new_n98, new_n101, new_n109, new_n111, new_n112,
    new_n114, new_n117, new_n118, new_n119, new_n120, new_n121, new_n122,
    new_n123, new_n124, new_n126, new_n127, new_n128, new_n129, new_n130,
    new_n131, new_n132, new_n133, new_n135, new_n136, new_n137, new_n138,
    new_n139, new_n140, new_n141, new_n142, new_n143, new_n144, new_n145,
    new_n146, new_n147, new_n148, new_n149, new_n150, new_n151, new_n152,
    new_n153, new_n154, new_n155, new_n156, new_n157, new_n158, new_n159,
    new_n161, new_n162, new_n163, new_n164, new_n165, new_n166, new_n167,
    new_n168, new_n169, new_n170, new_n171, new_n172, new_n173, new_n174,
    new_n175, new_n176, new_n177, new_n178, new_n180, new_n181, new_n182,
    new_n183, new_n184, new_n185, new_n186, new_n188, new_n189, new_n190,
    new_n191, new_n192, new_n193, new_n194, new_n196, new_n197, new_n198,
    new_n199, new_n200, new_n201, new_n202, new_n203, new_n204, new_n205,
    new_n206, new_n207, new_n208, new_n209, new_n210, new_n211, new_n212,
    new_n213, new_n214, new_n215, new_n216, new_n218, new_n219, new_n220,
    new_n221, new_n222, new_n223, new_n225, new_n226, new_n227, new_n228,
    new_n229, new_n230, new_n232, new_n233, new_n234, new_n235, new_n236,
    new_n237, new_n239, new_n240, new_n241, new_n242, new_n243, new_n244;
  INVx1_ASAP7_75t_R    g000(.A(pi00), .Y(new_n87));
  INVx1_ASAP7_75t_R    g001(.A(pi07), .Y(new_n88));
  INVx1_ASAP7_75t_R    g002(.A(pi10), .Y(new_n89));
  INVx1_ASAP7_75t_R    g003(.A(pi45), .Y(new_n90));
  INVx1_ASAP7_75t_R    g004(.A(pi48), .Y(new_n91));
  INVx1_ASAP7_75t_R    g005(.A(pi51), .Y(new_n92));
  INVx1_ASAP7_75t_R    g006(.A(pi52), .Y(new_n93));
  AND3x1_ASAP7_75t_R   g007(.A(pi00), .B(pi01), .C(pi02), .Y(new_n94));
  INVx1_ASAP7_75t_R    g008(.A(new_n94), .Y(po00));
  AND3x1_ASAP7_75t_R   g009(.A(pi02), .B(pi03), .C(pi04), .Y(new_n96));
  INVx1_ASAP7_75t_R    g010(.A(new_n96), .Y(po01));
  AND3x1_ASAP7_75t_R   g011(.A(pi00), .B(pi02), .C(pi04), .Y(new_n98));
  INVx1_ASAP7_75t_R    g012(.A(new_n98), .Y(po02));
  NAND2x1_ASAP7_75t_R  g013(.A(pi05), .B(pi06), .Y(po03));
  AND4x2_ASAP7_75t_R   g014(.A(pi07), .B(pi08), .C(pi09), .D(pi10), .Y(new_n101));
  INVx1_ASAP7_75t_R    g015(.A(new_n101), .Y(po04));
  AND5x1_ASAP7_75t_R   g016(.A(po02), .B(pi10), .C(pi08), .D(pi07), .E(pi11), .Y(po05));
  AND3x1_ASAP7_75t_R   g017(.A(pi01), .B(pi03), .C(pi12), .Y(po06));
  AND3x1_ASAP7_75t_R   g018(.A(pi03), .B(pi04), .C(pi12), .Y(po07));
  AND3x1_ASAP7_75t_R   g019(.A(pi00), .B(pi04), .C(pi12), .Y(po08));
  OAI21x1_ASAP7_75t_R  g020(.A1(pi14), .A2(pi15), .B(pi13), .Y(po09));
  AND5x1_ASAP7_75t_R   g021(.A(new_n98), .B(pi10), .C(pi08), .D(pi07), .E(pi11), .Y(po10));
  AND3x1_ASAP7_75t_R   g022(.A(pi10), .B(pi11), .C(pi16), .Y(new_n109));
  INVx1_ASAP7_75t_R    g023(.A(new_n109), .Y(po11));
  AND4x2_ASAP7_75t_R   g024(.A(pi08), .B(pi09), .C(pi10), .D(pi17), .Y(new_n111));
  AND3x1_ASAP7_75t_R   g025(.A(new_n111), .B(pi18), .C(pi02), .Y(new_n112));
  INVx1_ASAP7_75t_R    g026(.A(new_n112), .Y(po12));
  AND3x1_ASAP7_75t_R   g027(.A(new_n111), .B(pi18), .C(pi12), .Y(new_n114));
  NAND2x1_ASAP7_75t_R  g028(.A(pi19), .B(new_n114), .Y(po13));
  OAI21x1_ASAP7_75t_R  g029(.A1(pi14), .A2(pi15), .B(pi20), .Y(po14));
  XOR2x2_ASAP7_75t_R   g030(.A(pi22), .B(pi23), .Y(new_n117));
  XOR2x2_ASAP7_75t_R   g031(.A(new_n117), .B(pi21), .Y(new_n118));
  XNOR2x2_ASAP7_75t_R  g032(.A(pi28), .B(pi29), .Y(new_n119));
  XOR2x2_ASAP7_75t_R   g033(.A(new_n118), .B(new_n119), .Y(new_n120));
  XOR2x2_ASAP7_75t_R   g034(.A(pi26), .B(pi27), .Y(new_n121));
  XOR2x2_ASAP7_75t_R   g035(.A(new_n121), .B(pi30), .Y(new_n122));
  XOR2x2_ASAP7_75t_R   g036(.A(pi24), .B(pi25), .Y(new_n123));
  XOR2x2_ASAP7_75t_R   g037(.A(new_n122), .B(new_n123), .Y(new_n124));
  XOR2x2_ASAP7_75t_R   g038(.A(new_n120), .B(new_n124), .Y(po15));
  XOR2x2_ASAP7_75t_R   g039(.A(pi31), .B(pi32), .Y(new_n126));
  XOR2x2_ASAP7_75t_R   g040(.A(new_n126), .B(pi21), .Y(new_n127));
  XNOR2x2_ASAP7_75t_R  g041(.A(pi37), .B(pi38), .Y(new_n128));
  XOR2x2_ASAP7_75t_R   g042(.A(new_n127), .B(new_n128), .Y(new_n129));
  XOR2x2_ASAP7_75t_R   g043(.A(pi35), .B(pi36), .Y(new_n130));
  XOR2x2_ASAP7_75t_R   g044(.A(new_n130), .B(pi39), .Y(new_n131));
  XOR2x2_ASAP7_75t_R   g045(.A(pi33), .B(pi34), .Y(new_n132));
  XOR2x2_ASAP7_75t_R   g046(.A(new_n131), .B(new_n132), .Y(new_n133));
  XOR2x2_ASAP7_75t_R   g047(.A(new_n129), .B(new_n133), .Y(po16));
  OR2x4_ASAP7_75t_R    g048(.A(pi00), .B(pi07), .Y(new_n135));
  NAND2x1_ASAP7_75t_R  g049(.A(pi12), .B(pi47), .Y(new_n136));
  NAND2x1_ASAP7_75t_R  g050(.A(pi00), .B(pi07), .Y(new_n137));
  OA211x2_ASAP7_75t_R  g051(.A1(new_n87), .A2(new_n88), .B(pi12), .C(pi47), .Y(new_n138));
  AND5x1_ASAP7_75t_R   g052(.A(new_n109), .B(new_n135), .C(new_n137), .D(pi47), .E(pi12), .Y(new_n139));
  NAND3x1_ASAP7_75t_R  g053(.A(pi00), .B(pi01), .C(pi12), .Y(new_n140));
  AND4x2_ASAP7_75t_R   g054(.A(pi07), .B(pi09), .C(pi10), .D(pi16), .Y(new_n141));
  AND2x2_ASAP7_75t_R   g055(.A(new_n140), .B(new_n141), .Y(new_n142));
  AO32x1_ASAP7_75t_R   g056(.A1(new_n109), .A2(new_n138), .A3(new_n135), .B1(new_n141), .B2(new_n140), .Y(new_n143));
  OA21x2_ASAP7_75t_R   g057(.A1(new_n139), .A2(new_n142), .B(pi29), .Y(new_n144));
  AO31x2_ASAP7_75t_R   g058(.A1(pi07), .A2(new_n109), .A3(new_n136), .B(new_n89), .Y(new_n145));
  AND3x1_ASAP7_75t_R   g059(.A(pi01), .B(pi02), .C(pi03), .Y(new_n146));
  AND4x2_ASAP7_75t_R   g060(.A(new_n109), .B(new_n146), .C(pi17), .D(new_n90), .Y(new_n147));
  AO21x1_ASAP7_75t_R   g061(.A1(pi46), .A2(new_n145), .B(new_n147), .Y(new_n148));
  AO21x1_ASAP7_75t_R   g062(.A1(pi29), .A2(new_n143), .B(new_n148), .Y(new_n149));
  AND2x2_ASAP7_75t_R   g063(.A(new_n149), .B(pi38), .Y(new_n150));
  OAI21x1_ASAP7_75t_R  g064(.A1(new_n148), .A2(new_n144), .B(pi38), .Y(new_n151));
  AOI211x1_ASAP7_75t_R g065(.A1(pi29), .A2(new_n143), .B(new_n148), .C(pi38), .Y(new_n152));
  NOR2x1_ASAP7_75t_R   g066(.A(new_n152), .B(new_n150), .Y(new_n153));
  OR3x1_ASAP7_75t_R    g067(.A(new_n150), .B(new_n152), .C(new_n93), .Y(new_n154));
  OA211x2_ASAP7_75t_R  g068(.A1(pi52), .A2(new_n153), .B(new_n154), .C(pi51), .Y(new_n155));
  AO21x1_ASAP7_75t_R   g069(.A1(pi38), .A2(pi49), .B(pi44), .Y(new_n156));
  AND4x2_ASAP7_75t_R   g070(.A(new_n114), .B(pi41), .C(pi40), .D(pi00), .Y(new_n157));
  AO222x2_ASAP7_75t_R  g071(.A1(pi42), .A2(pi43), .B1(pi50), .B2(pi28), .C1(pi38), .C2(new_n157), .Y(new_n158));
  AO221x2_ASAP7_75t_R  g072(.A1(new_n149), .A2(new_n156), .B1(pi48), .B2(new_n153), .C(new_n158), .Y(new_n159));
  NOR2x1_ASAP7_75t_R   g073(.A(new_n159), .B(new_n155), .Y(po17));
  AO221x2_ASAP7_75t_R  g074(.A1(pi53), .A2(new_n145), .B1(pi26), .B2(new_n143), .C(new_n147), .Y(new_n161));
  OR2x4_ASAP7_75t_R    g075(.A(pi35), .B(new_n161), .Y(new_n162));
  AND2x2_ASAP7_75t_R   g076(.A(new_n161), .B(pi35), .Y(new_n163));
  XOR2x2_ASAP7_75t_R   g077(.A(new_n161), .B(pi35), .Y(new_n164));
  AO221x2_ASAP7_75t_R  g078(.A1(pi55), .A2(new_n145), .B1(pi27), .B2(new_n143), .C(new_n147), .Y(new_n165));
  NAND2x1_ASAP7_75t_R  g079(.A(pi36), .B(new_n165), .Y(new_n166));
  NOR2x1_ASAP7_75t_R   g080(.A(pi36), .B(new_n165), .Y(new_n167));
  AO221x2_ASAP7_75t_R  g081(.A1(pi54), .A2(new_n145), .B1(pi28), .B2(new_n143), .C(new_n147), .Y(new_n168));
  AND2x2_ASAP7_75t_R   g082(.A(new_n168), .B(pi37), .Y(new_n169));
  OR2x4_ASAP7_75t_R    g083(.A(pi37), .B(new_n168), .Y(new_n170));
  OAI21x1_ASAP7_75t_R  g084(.A1(new_n93), .A2(new_n152), .B(new_n151), .Y(new_n171));
  AOI21x1_ASAP7_75t_R  g085(.A1(new_n170), .A2(new_n171), .B(new_n169), .Y(new_n172));
  OAI21x1_ASAP7_75t_R  g086(.A1(new_n167), .A2(new_n172), .B(new_n166), .Y(new_n173));
  AOI21x1_ASAP7_75t_R  g087(.A1(new_n164), .A2(new_n173), .B(new_n92), .Y(new_n174));
  OAI21x1_ASAP7_75t_R  g088(.A1(new_n164), .A2(new_n173), .B(new_n174), .Y(new_n175));
  AO21x1_ASAP7_75t_R   g089(.A1(pi35), .A2(pi49), .B(pi44), .Y(new_n176));
  AO222x2_ASAP7_75t_R  g090(.A1(pi25), .A2(pi50), .B1(new_n157), .B2(pi35), .C1(new_n176), .C2(new_n161), .Y(new_n177));
  AOI21x1_ASAP7_75t_R  g091(.A1(pi48), .A2(new_n164), .B(new_n177), .Y(new_n178));
  AND2x2_ASAP7_75t_R   g092(.A(new_n175), .B(new_n178), .Y(po18));
  XOR2x2_ASAP7_75t_R   g093(.A(new_n165), .B(pi36), .Y(new_n180));
  INVx1_ASAP7_75t_R    g094(.A(new_n180), .Y(new_n181));
  OAI21x1_ASAP7_75t_R  g095(.A1(new_n172), .A2(new_n181), .B(pi51), .Y(new_n182));
  AO21x1_ASAP7_75t_R   g096(.A1(new_n172), .A2(new_n181), .B(new_n182), .Y(new_n183));
  AO21x1_ASAP7_75t_R   g097(.A1(pi36), .A2(pi49), .B(pi44), .Y(new_n184));
  AO222x2_ASAP7_75t_R  g098(.A1(pi26), .A2(pi50), .B1(pi56), .B2(pi42), .C1(pi36), .C2(new_n157), .Y(new_n185));
  AOI21x1_ASAP7_75t_R  g099(.A1(new_n165), .A2(new_n184), .B(new_n185), .Y(new_n186));
  OA211x2_ASAP7_75t_R  g100(.A1(new_n91), .A2(new_n181), .B(new_n183), .C(new_n186), .Y(po19));
  XNOR2x2_ASAP7_75t_R  g101(.A(pi37), .B(new_n168), .Y(new_n188));
  INVx1_ASAP7_75t_R    g102(.A(new_n188), .Y(new_n189));
  OAI21x1_ASAP7_75t_R  g103(.A1(new_n171), .A2(new_n189), .B(pi51), .Y(new_n190));
  AOI21x1_ASAP7_75t_R  g104(.A1(new_n171), .A2(new_n189), .B(new_n190), .Y(new_n191));
  AO21x1_ASAP7_75t_R   g105(.A1(pi37), .A2(pi49), .B(pi44), .Y(new_n192));
  AO222x2_ASAP7_75t_R  g106(.A1(pi27), .A2(pi50), .B1(pi57), .B2(pi42), .C1(pi37), .C2(new_n157), .Y(new_n193));
  AO221x2_ASAP7_75t_R  g107(.A1(new_n168), .A2(new_n192), .B1(pi48), .B2(new_n189), .C(new_n193), .Y(new_n194));
  NOR2x1_ASAP7_75t_R   g108(.A(new_n194), .B(new_n191), .Y(po20));
  AND3x1_ASAP7_75t_R   g109(.A(new_n109), .B(new_n136), .C(pi17), .Y(new_n196));
  AND4x2_ASAP7_75t_R   g110(.A(new_n109), .B(new_n146), .C(pi07), .D(new_n90), .Y(new_n197));
  AO221x2_ASAP7_75t_R  g111(.A1(pi09), .A2(pi58), .B1(new_n196), .B2(pi53), .C(new_n197), .Y(new_n198));
  AO21x1_ASAP7_75t_R   g112(.A1(pi22), .A2(new_n143), .B(new_n198), .Y(new_n199));
  AO221x2_ASAP7_75t_R  g113(.A1(pi16), .A2(pi58), .B1(new_n196), .B2(pi55), .C(new_n197), .Y(new_n200));
  AO21x1_ASAP7_75t_R   g114(.A1(pi23), .A2(new_n143), .B(new_n200), .Y(new_n201));
  NAND2x1_ASAP7_75t_R  g115(.A(pi32), .B(new_n201), .Y(new_n202));
  NOR2x1_ASAP7_75t_R   g116(.A(pi32), .B(new_n201), .Y(new_n203));
  AO221x2_ASAP7_75t_R  g117(.A1(pi07), .A2(pi58), .B1(new_n196), .B2(pi54), .C(new_n197), .Y(new_n204));
  AO21x1_ASAP7_75t_R   g118(.A1(pi24), .A2(new_n143), .B(new_n204), .Y(new_n205));
  AND2x2_ASAP7_75t_R   g119(.A(new_n205), .B(pi33), .Y(new_n206));
  OR2x4_ASAP7_75t_R    g120(.A(pi33), .B(new_n205), .Y(new_n207));
  AO221x2_ASAP7_75t_R  g121(.A1(pi58), .A2(pi59), .B1(new_n196), .B2(pi46), .C(new_n197), .Y(new_n208));
  AO21x1_ASAP7_75t_R   g122(.A1(pi25), .A2(new_n143), .B(new_n208), .Y(new_n209));
  NAND2x1_ASAP7_75t_R  g123(.A(pi34), .B(new_n209), .Y(new_n210));
  NOR2x1_ASAP7_75t_R   g124(.A(pi34), .B(new_n209), .Y(new_n211));
  AOI21x1_ASAP7_75t_R  g125(.A1(new_n162), .A2(new_n173), .B(new_n163), .Y(new_n212));
  OAI21x1_ASAP7_75t_R  g126(.A1(new_n211), .A2(new_n212), .B(new_n210), .Y(new_n213));
  AOI21x1_ASAP7_75t_R  g127(.A1(new_n207), .A2(new_n213), .B(new_n206), .Y(new_n214));
  OAI21x1_ASAP7_75t_R  g128(.A1(new_n203), .A2(new_n214), .B(new_n202), .Y(new_n215));
  MAJx2_ASAP7_75t_R    g129(.A(new_n215), .B(new_n199), .C(pi31), .Y(new_n216));
  INVx1_ASAP7_75t_R    g130(.A(new_n216), .Y(po21));
  XNOR2x2_ASAP7_75t_R  g131(.A(pi34), .B(new_n209), .Y(new_n218));
  OAI21x1_ASAP7_75t_R  g132(.A1(new_n218), .A2(new_n212), .B(pi51), .Y(new_n219));
  AO21x1_ASAP7_75t_R   g133(.A1(new_n212), .A2(new_n218), .B(new_n219), .Y(new_n220));
  AO21x1_ASAP7_75t_R   g134(.A1(pi34), .A2(pi49), .B(pi44), .Y(new_n221));
  AO222x2_ASAP7_75t_R  g135(.A1(pi24), .A2(pi50), .B1(new_n157), .B2(pi34), .C1(new_n221), .C2(new_n209), .Y(new_n222));
  INVx1_ASAP7_75t_R    g136(.A(new_n222), .Y(new_n223));
  OA211x2_ASAP7_75t_R  g137(.A1(new_n91), .A2(new_n218), .B(new_n220), .C(new_n223), .Y(po22));
  XOR2x2_ASAP7_75t_R   g138(.A(new_n199), .B(pi31), .Y(new_n225));
  NOR2x1_ASAP7_75t_R   g139(.A(new_n225), .B(new_n215), .Y(new_n226));
  AO21x1_ASAP7_75t_R   g140(.A1(new_n215), .A2(new_n225), .B(new_n92), .Y(new_n227));
  AO21x1_ASAP7_75t_R   g141(.A1(pi31), .A2(pi49), .B(pi44), .Y(new_n228));
  AO222x2_ASAP7_75t_R  g142(.A1(pi45), .A2(pi50), .B1(new_n157), .B2(pi31), .C1(new_n228), .C2(new_n199), .Y(new_n229));
  AOI21x1_ASAP7_75t_R  g143(.A1(pi48), .A2(new_n225), .B(new_n229), .Y(new_n230));
  OA21x2_ASAP7_75t_R   g144(.A1(new_n226), .A2(new_n227), .B(new_n230), .Y(po23));
  XNOR2x2_ASAP7_75t_R  g145(.A(pi32), .B(new_n201), .Y(new_n232));
  INVx1_ASAP7_75t_R    g146(.A(new_n232), .Y(new_n233));
  NAND2x1_ASAP7_75t_R  g147(.A(new_n232), .B(new_n214), .Y(new_n234));
  OA21x2_ASAP7_75t_R   g148(.A1(new_n214), .A2(new_n232), .B(pi51), .Y(new_n235));
  AO21x1_ASAP7_75t_R   g149(.A1(pi32), .A2(pi49), .B(pi44), .Y(new_n236));
  AO222x2_ASAP7_75t_R  g150(.A1(pi22), .A2(pi50), .B1(new_n157), .B2(pi32), .C1(new_n236), .C2(new_n201), .Y(new_n237));
  AOI221x1_ASAP7_75t_R g151(.A1(pi48), .A2(new_n233), .B1(new_n235), .B2(new_n234), .C(new_n237), .Y(po24));
  XOR2x2_ASAP7_75t_R   g152(.A(new_n205), .B(pi33), .Y(new_n239));
  AOI21x1_ASAP7_75t_R  g153(.A1(new_n239), .A2(new_n213), .B(new_n92), .Y(new_n240));
  OAI21x1_ASAP7_75t_R  g154(.A1(new_n213), .A2(new_n239), .B(new_n240), .Y(new_n241));
  AO21x1_ASAP7_75t_R   g155(.A1(pi33), .A2(pi49), .B(pi44), .Y(new_n242));
  AO222x2_ASAP7_75t_R  g156(.A1(pi23), .A2(pi50), .B1(new_n157), .B2(pi33), .C1(new_n242), .C2(new_n205), .Y(new_n243));
  AOI21x1_ASAP7_75t_R  g157(.A1(pi48), .A2(new_n239), .B(new_n243), .Y(new_n244));
  AND2x2_ASAP7_75t_R   g158(.A(new_n241), .B(new_n244), .Y(po25));
endmodule


