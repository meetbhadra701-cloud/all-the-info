// Benchmark "/w/experiments/inputs/c1/c2/c2670" written by ABC on Fri Sep 25 10:27:09 2026

module \/w/experiments/inputs/c1/c2/c2670  ( 
    pi000, pi001, pi002, pi003, pi004, pi005, pi006, pi007, pi008, pi009,
    pi010, pi011, pi012, pi013, pi014, pi015, pi016, pi017, pi018, pi019,
    pi020, pi021, pi022, pi023, pi024, pi025, pi026, pi027, pi028, pi029,
    pi030, pi031, pi032, pi033, pi034, pi035, pi036, pi037, pi038, pi039,
    pi040, pi041, pi042, pi043, pi044, pi045, pi046, pi047, pi048, pi049,
    pi050, pi051, pi052, pi053, pi054, pi055, pi056, pi057, pi058, pi059,
    pi060, pi061, pi062, pi063, pi064, pi065, pi066, pi067, pi068, pi069,
    pi070, pi071, pi072, pi073, pi074, pi075, pi076, pi077, pi078, pi079,
    pi080, pi081, pi082, pi083, pi084, pi085, pi086, pi087, pi088, pi089,
    pi090, pi091, pi092, pi093, pi094, pi095, pi096, pi097, pi098, pi099,
    pi100, pi101, pi102, pi103, pi104, pi105, pi106, pi107, pi108, pi109,
    pi110, pi111, pi112, pi113, pi114, pi115, pi116, pi117, pi118, pi119,
    pi120, pi121, pi122, pi123, pi124, pi125, pi126, pi127, pi128, pi129,
    pi130, pi131, pi132, pi133, pi134, pi135, pi136, pi137, pi138, pi139,
    pi140, pi141, pi142, pi143, pi144, pi145, pi146, pi147, pi148, pi149,
    pi150, pi151, pi152, pi153, pi154, pi155, pi156,
    po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10, po11,
    po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22, po23,
    po24, po25, po26, po27, po28, po29, po30, po31, po32, po33, po34, po35,
    po36, po37, po38, po39, po40, po41, po42, po43, po44, po45, po46, po47,
    po48, po49, po50, po51, po52, po53, po54, po55, po56, po57, po58, po59,
    po60, po61, po62, po63  );
  input  pi000, pi001, pi002, pi003, pi004, pi005, pi006, pi007, pi008,
    pi009, pi010, pi011, pi012, pi013, pi014, pi015, pi016, pi017, pi018,
    pi019, pi020, pi021, pi022, pi023, pi024, pi025, pi026, pi027, pi028,
    pi029, pi030, pi031, pi032, pi033, pi034, pi035, pi036, pi037, pi038,
    pi039, pi040, pi041, pi042, pi043, pi044, pi045, pi046, pi047, pi048,
    pi049, pi050, pi051, pi052, pi053, pi054, pi055, pi056, pi057, pi058,
    pi059, pi060, pi061, pi062, pi063, pi064, pi065, pi066, pi067, pi068,
    pi069, pi070, pi071, pi072, pi073, pi074, pi075, pi076, pi077, pi078,
    pi079, pi080, pi081, pi082, pi083, pi084, pi085, pi086, pi087, pi088,
    pi089, pi090, pi091, pi092, pi093, pi094, pi095, pi096, pi097, pi098,
    pi099, pi100, pi101, pi102, pi103, pi104, pi105, pi106, pi107, pi108,
    pi109, pi110, pi111, pi112, pi113, pi114, pi115, pi116, pi117, pi118,
    pi119, pi120, pi121, pi122, pi123, pi124, pi125, pi126, pi127, pi128,
    pi129, pi130, pi131, pi132, pi133, pi134, pi135, pi136, pi137, pi138,
    pi139, pi140, pi141, pi142, pi143, pi144, pi145, pi146, pi147, pi148,
    pi149, pi150, pi151, pi152, pi153, pi154, pi155, pi156;
  output po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10,
    po11, po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22,
    po23, po24, po25, po26, po27, po28, po29, po30, po31, po32, po33, po34,
    po35, po36, po37, po38, po39, po40, po41, po42, po43, po44, po45, po46,
    po47, po48, po49, po50, po51, po52, po53, po54, po55, po56, po57, po58,
    po59, po60, po61, po62, po63;
  wire new_n231, new_n235, new_n236, new_n237, new_n238, new_n239, new_n240,
    new_n241, new_n242, new_n243, new_n244, new_n245, new_n246, new_n247,
    new_n248, new_n249, new_n250, new_n251, new_n252, new_n253, new_n254,
    new_n255, new_n257, new_n259, new_n261, new_n262, new_n263, new_n264,
    new_n267, new_n268, new_n269, new_n270, new_n271, new_n273, new_n275,
    new_n278, new_n279, new_n281, new_n282, new_n284, new_n285, new_n286,
    new_n287, new_n288, new_n291, new_n294, new_n297, new_n298, new_n299,
    new_n300, new_n302, new_n305, new_n306, new_n308, new_n310, new_n311,
    new_n313, new_n315, new_n316, new_n317, new_n318, new_n319, new_n321,
    new_n324, new_n325, new_n327, new_n328, new_n329, new_n331, new_n332,
    new_n333, new_n334, new_n335, new_n336, new_n337, new_n338, new_n339,
    new_n340, new_n342, new_n343, new_n344, new_n345, new_n346, new_n347,
    new_n349, new_n350, new_n351, new_n352, new_n353, new_n354, new_n355,
    new_n356, new_n358, new_n359, new_n360, new_n361, new_n362, new_n363,
    new_n364, new_n365, new_n366, new_n367, new_n368, new_n369, new_n370,
    new_n371, new_n372, new_n373, new_n374, new_n375, new_n376, new_n377,
    new_n378, new_n379, new_n380, new_n381, new_n382, new_n383, new_n384,
    new_n385, new_n386, new_n387, new_n388, new_n389, new_n390, new_n391,
    new_n392, new_n393, new_n394, new_n395, new_n396, new_n397, new_n398,
    new_n399, new_n400, new_n401, new_n402, new_n403, new_n404, new_n405,
    new_n406, new_n407, new_n408, new_n409, new_n410, new_n411, new_n412,
    new_n413, new_n414, new_n415, new_n416, new_n417, new_n418, new_n419,
    new_n420, new_n421, new_n422, new_n423, new_n424, new_n425, new_n427,
    new_n428, new_n429, new_n430, new_n431, new_n432, new_n433, new_n434,
    new_n436, new_n437, new_n438, new_n439, new_n440, new_n441, new_n442,
    new_n443, new_n444, new_n445, new_n447, new_n448, new_n449, new_n450,
    new_n451, new_n452, new_n453, new_n454, new_n455, new_n456, new_n457,
    new_n459, new_n460, new_n461, new_n463, new_n464, new_n465, new_n466,
    new_n467, new_n468, new_n469, new_n470, new_n471, new_n472, new_n473,
    new_n474, new_n475, new_n476, new_n477, new_n478, new_n479, new_n480,
    new_n481, new_n482, new_n483, new_n484, new_n485, new_n486, new_n487,
    new_n488, new_n489, new_n490, new_n491, new_n492, new_n493, new_n494,
    new_n495, new_n496, new_n497, new_n498, new_n499, new_n500, new_n501,
    new_n502, new_n503, new_n504, new_n505, new_n506, new_n507, new_n508,
    new_n509, new_n510, new_n512, new_n513;
  INVx1_ASAP7_75t_R    g000(.A(pi004), .Y(po19));
  INVx1_ASAP7_75t_R    g001(.A(pi005), .Y(po22));
  INVx1_ASAP7_75t_R    g002(.A(pi006), .Y(po21));
  INVx1_ASAP7_75t_R    g003(.A(pi007), .Y(po20));
  INVx1_ASAP7_75t_R    g004(.A(pi008), .Y(po15));
  INVx1_ASAP7_75t_R    g005(.A(pi009), .Y(po18));
  INVx1_ASAP7_75t_R    g006(.A(pi010), .Y(po17));
  INVx1_ASAP7_75t_R    g007(.A(pi011), .Y(po16));
  INVx1_ASAP7_75t_R    g008(.A(pi012), .Y(new_n231));
  INVx1_ASAP7_75t_R    g009(.A(pi018), .Y(po07));
  INVx1_ASAP7_75t_R    g010(.A(pi019), .Y(po10));
  INVx1_ASAP7_75t_R    g011(.A(pi020), .Y(po12));
  INVx1_ASAP7_75t_R    g012(.A(pi036), .Y(new_n235));
  INVx1_ASAP7_75t_R    g013(.A(pi050), .Y(new_n236));
  INVx1_ASAP7_75t_R    g014(.A(pi055), .Y(new_n237));
  INVx1_ASAP7_75t_R    g015(.A(pi056), .Y(new_n238));
  INVx1_ASAP7_75t_R    g016(.A(pi089), .Y(new_n239));
  INVx1_ASAP7_75t_R    g017(.A(pi096), .Y(new_n240));
  INVx1_ASAP7_75t_R    g018(.A(pi098), .Y(new_n241));
  INVx1_ASAP7_75t_R    g019(.A(pi102), .Y(new_n242));
  INVx1_ASAP7_75t_R    g020(.A(pi108), .Y(new_n243));
  INVx1_ASAP7_75t_R    g021(.A(pi111), .Y(new_n244));
  INVx1_ASAP7_75t_R    g022(.A(pi123), .Y(new_n245));
  INVx1_ASAP7_75t_R    g023(.A(pi130), .Y(new_n246));
  INVx1_ASAP7_75t_R    g024(.A(pi133), .Y(new_n247));
  INVx1_ASAP7_75t_R    g025(.A(pi134), .Y(new_n248));
  INVx1_ASAP7_75t_R    g026(.A(pi135), .Y(new_n249));
  INVx1_ASAP7_75t_R    g027(.A(pi140), .Y(new_n250));
  INVx1_ASAP7_75t_R    g028(.A(pi141), .Y(new_n251));
  INVx1_ASAP7_75t_R    g029(.A(pi142), .Y(new_n252));
  INVx1_ASAP7_75t_R    g030(.A(pi143), .Y(new_n253));
  INVx1_ASAP7_75t_R    g031(.A(pi144), .Y(new_n254));
  INVx1_ASAP7_75t_R    g032(.A(pi156), .Y(new_n255));
  NAND2x1_ASAP7_75t_R  g033(.A(pi000), .B(pi001), .Y(po00));
  AND3x1_ASAP7_75t_R   g034(.A(pi000), .B(pi001), .C(pi002), .Y(new_n257));
  INVx1_ASAP7_75t_R    g035(.A(new_n257), .Y(po01));
  AND3x1_ASAP7_75t_R   g036(.A(pi000), .B(pi001), .C(pi003), .Y(new_n259));
  INVx1_ASAP7_75t_R    g037(.A(new_n259), .Y(po02));
  AND4x2_ASAP7_75t_R   g038(.A(pi004), .B(pi005), .C(pi006), .D(pi007), .Y(new_n261));
  INVx1_ASAP7_75t_R    g039(.A(new_n261), .Y(new_n262));
  AND4x2_ASAP7_75t_R   g040(.A(pi008), .B(pi009), .C(pi010), .D(pi011), .Y(new_n263));
  INVx1_ASAP7_75t_R    g041(.A(new_n263), .Y(new_n264));
  NAND2x1_ASAP7_75t_R  g042(.A(new_n261), .B(new_n263), .Y(po03));
  AO22x1_ASAP7_75t_R   g043(.A1(new_n264), .A2(pi003), .B1(new_n262), .B2(pi002), .Y(po05));
  NOR2x1_ASAP7_75t_R   g044(.A(pi012), .B(pi013), .Y(new_n267));
  AND2x2_ASAP7_75t_R   g045(.A(new_n231), .B(pi013), .Y(new_n268));
  AO22x1_ASAP7_75t_R   g046(.A1(new_n268), .A2(pi015), .B1(pi014), .B2(new_n267), .Y(new_n269));
  NOR2x1_ASAP7_75t_R   g047(.A(pi013), .B(new_n231), .Y(new_n270));
  AND2x2_ASAP7_75t_R   g048(.A(pi012), .B(pi013), .Y(new_n271));
  AOI221x1_ASAP7_75t_R g049(.A1(pi016), .A2(new_n270), .B1(new_n271), .B2(pi017), .C(new_n269), .Y(po06));
  AND4x2_ASAP7_75t_R   g050(.A(pi021), .B(pi022), .C(pi023), .D(pi024), .Y(new_n273));
  INVx1_ASAP7_75t_R    g051(.A(new_n273), .Y(po23));
  AND3x1_ASAP7_75t_R   g052(.A(pi001), .B(pi025), .C(pi026), .Y(new_n275));
  INVx1_ASAP7_75t_R    g053(.A(new_n275), .Y(po24));
  AND2x2_ASAP7_75t_R   g054(.A(po07), .B(pi027), .Y(po26));
  AO22x1_ASAP7_75t_R   g055(.A1(new_n268), .A2(pi029), .B1(pi028), .B2(new_n267), .Y(new_n278));
  AO221x2_ASAP7_75t_R  g056(.A1(pi030), .A2(new_n270), .B1(new_n271), .B2(pi031), .C(new_n278), .Y(new_n279));
  INVx1_ASAP7_75t_R    g057(.A(new_n279), .Y(po27));
  AOI22x1_ASAP7_75t_R  g058(.A1(pi032), .A2(new_n267), .B1(new_n268), .B2(pi033), .Y(new_n281));
  AOI22x1_ASAP7_75t_R  g059(.A1(pi035), .A2(new_n271), .B1(new_n270), .B2(pi034), .Y(new_n282));
  AND2x2_ASAP7_75t_R   g060(.A(new_n282), .B(new_n281), .Y(po28));
  NOR2x1_ASAP7_75t_R   g061(.A(pi036), .B(pi037), .Y(new_n284));
  AND2x2_ASAP7_75t_R   g062(.A(new_n235), .B(pi037), .Y(new_n285));
  AO22x1_ASAP7_75t_R   g063(.A1(new_n285), .A2(pi039), .B1(pi038), .B2(new_n284), .Y(new_n286));
  NOR2x1_ASAP7_75t_R   g064(.A(pi037), .B(new_n235), .Y(new_n287));
  AND2x2_ASAP7_75t_R   g065(.A(pi036), .B(pi037), .Y(new_n288));
  AO221x2_ASAP7_75t_R  g066(.A1(pi040), .A2(new_n287), .B1(new_n288), .B2(pi041), .C(new_n286), .Y(po38));
  INVx1_ASAP7_75t_R    g067(.A(po38), .Y(po29));
  AO22x1_ASAP7_75t_R   g068(.A1(new_n285), .A2(pi043), .B1(pi042), .B2(new_n284), .Y(new_n291));
  AO221x2_ASAP7_75t_R  g069(.A1(pi044), .A2(new_n287), .B1(new_n288), .B2(pi045), .C(new_n291), .Y(po37));
  INVx1_ASAP7_75t_R    g070(.A(po37), .Y(po30));
  AO22x1_ASAP7_75t_R   g071(.A1(new_n285), .A2(pi047), .B1(pi046), .B2(new_n284), .Y(new_n294));
  AO221x2_ASAP7_75t_R  g072(.A1(pi048), .A2(new_n287), .B1(new_n288), .B2(pi049), .C(new_n294), .Y(po36));
  INVx1_ASAP7_75t_R    g073(.A(po36), .Y(po31));
  AOI22x1_ASAP7_75t_R  g074(.A1(pi051), .A2(new_n284), .B1(new_n285), .B2(pi052), .Y(new_n297));
  AOI22x1_ASAP7_75t_R  g075(.A1(pi054), .A2(new_n288), .B1(new_n287), .B2(pi053), .Y(new_n298));
  NAND2x1_ASAP7_75t_R  g076(.A(new_n297), .B(new_n298), .Y(new_n299));
  INVx1_ASAP7_75t_R    g077(.A(new_n299), .Y(new_n300));
  NAND2x1_ASAP7_75t_R  g078(.A(pi050), .B(new_n300), .Y(po32));
  OR3x1_ASAP7_75t_R    g079(.A(po05), .B(new_n238), .C(pi001), .Y(new_n302));
  OR4x2_ASAP7_75t_R    g080(.A(po05), .B(new_n238), .C(new_n237), .D(pi001), .Y(po33));
  AO21x1_ASAP7_75t_R   g081(.A1(pi057), .A2(pi058), .B(new_n302), .Y(po34));
  AOI22x1_ASAP7_75t_R  g082(.A1(pi059), .A2(new_n284), .B1(new_n285), .B2(pi060), .Y(new_n305));
  AOI22x1_ASAP7_75t_R  g083(.A1(pi062), .A2(new_n288), .B1(new_n287), .B2(pi061), .Y(new_n306));
  NAND2x1_ASAP7_75t_R  g084(.A(new_n305), .B(new_n306), .Y(po35));
  AO21x1_ASAP7_75t_R   g085(.A1(pi063), .A2(new_n284), .B(new_n285), .Y(new_n308));
  AO221x2_ASAP7_75t_R  g086(.A1(pi064), .A2(new_n287), .B1(new_n288), .B2(pi065), .C(new_n308), .Y(po39));
  INVx1_ASAP7_75t_R    g087(.A(po39), .Y(new_n310));
  AO22x1_ASAP7_75t_R   g088(.A1(new_n285), .A2(pi067), .B1(pi066), .B2(new_n284), .Y(new_n311));
  AO221x2_ASAP7_75t_R  g089(.A1(pi068), .A2(new_n287), .B1(new_n288), .B2(pi069), .C(new_n311), .Y(po40));
  AO22x1_ASAP7_75t_R   g090(.A1(new_n285), .A2(pi071), .B1(pi070), .B2(new_n284), .Y(new_n313));
  AO221x2_ASAP7_75t_R  g091(.A1(pi072), .A2(new_n287), .B1(new_n288), .B2(pi073), .C(new_n313), .Y(po41));
  INVx1_ASAP7_75t_R    g092(.A(po41), .Y(new_n315));
  AO22x1_ASAP7_75t_R   g093(.A1(new_n285), .A2(pi075), .B1(pi074), .B2(new_n284), .Y(new_n316));
  AO221x2_ASAP7_75t_R  g094(.A1(pi076), .A2(new_n287), .B1(new_n288), .B2(pi077), .C(new_n316), .Y(new_n317));
  INVx1_ASAP7_75t_R    g095(.A(new_n317), .Y(new_n318));
  NOR2x1_ASAP7_75t_R   g096(.A(pi078), .B(new_n317), .Y(new_n319));
  AO21x1_ASAP7_75t_R   g097(.A1(pi078), .A2(po36), .B(new_n319), .Y(po42));
  AOI21x1_ASAP7_75t_R  g098(.A1(new_n305), .A2(new_n306), .B(pi078), .Y(new_n321));
  AO21x1_ASAP7_75t_R   g099(.A1(po30), .A2(pi078), .B(new_n321), .Y(po44));
  AO21x1_ASAP7_75t_R   g100(.A1(new_n236), .A2(pi079), .B(new_n317), .Y(po46));
  NOR2x1_ASAP7_75t_R   g101(.A(pi079), .B(new_n317), .Y(new_n324));
  OAI21x1_ASAP7_75t_R  g102(.A1(pi079), .A2(new_n317), .B(pi078), .Y(new_n325));
  OA21x2_ASAP7_75t_R   g103(.A1(pi078), .A2(new_n300), .B(new_n325), .Y(po47));
  AO22x1_ASAP7_75t_R   g104(.A1(new_n268), .A2(pi083), .B1(pi082), .B2(new_n267), .Y(new_n327));
  AO221x2_ASAP7_75t_R  g105(.A1(pi084), .A2(new_n270), .B1(new_n271), .B2(pi085), .C(new_n327), .Y(new_n328));
  AOI21x1_ASAP7_75t_R  g106(.A1(pi081), .A2(new_n328), .B(pi080), .Y(new_n329));
  OAI21x1_ASAP7_75t_R  g107(.A1(pi081), .A2(new_n328), .B(new_n329), .Y(po49));
  XNOR2x2_ASAP7_75t_R  g108(.A(pi088), .B(pi089), .Y(new_n331));
  XNOR2x2_ASAP7_75t_R  g109(.A(pi090), .B(pi091), .Y(new_n332));
  XOR2x2_ASAP7_75t_R   g110(.A(new_n332), .B(pi094), .Y(new_n333));
  XOR2x2_ASAP7_75t_R   g111(.A(pi086), .B(pi087), .Y(new_n334));
  XOR2x2_ASAP7_75t_R   g112(.A(pi092), .B(pi093), .Y(new_n335));
  XOR2x2_ASAP7_75t_R   g113(.A(new_n335), .B(pi095), .Y(new_n336));
  XOR2x2_ASAP7_75t_R   g114(.A(new_n336), .B(new_n334), .Y(new_n337));
  XOR2x2_ASAP7_75t_R   g115(.A(new_n337), .B(new_n333), .Y(new_n338));
  AOI21x1_ASAP7_75t_R  g116(.A1(new_n331), .A2(new_n338), .B(new_n240), .Y(new_n339));
  OA21x2_ASAP7_75t_R   g117(.A1(new_n331), .A2(new_n338), .B(new_n339), .Y(new_n340));
  INVx1_ASAP7_75t_R    g118(.A(new_n340), .Y(po50));
  XOR2x2_ASAP7_75t_R   g119(.A(pi097), .B(pi098), .Y(new_n342));
  XOR2x2_ASAP7_75t_R   g120(.A(pi023), .B(pi024), .Y(new_n343));
  XOR2x2_ASAP7_75t_R   g121(.A(pi021), .B(pi022), .Y(new_n344));
  XOR2x2_ASAP7_75t_R   g122(.A(new_n343), .B(new_n344), .Y(new_n345));
  XNOR2x2_ASAP7_75t_R  g123(.A(pi080), .B(pi081), .Y(new_n346));
  XOR2x2_ASAP7_75t_R   g124(.A(new_n345), .B(new_n346), .Y(new_n347));
  XOR2x2_ASAP7_75t_R   g125(.A(new_n347), .B(new_n342), .Y(po51));
  XOR2x2_ASAP7_75t_R   g126(.A(pi099), .B(pi100), .Y(new_n349));
  XOR2x2_ASAP7_75t_R   g127(.A(pi107), .B(pi108), .Y(new_n350));
  XOR2x2_ASAP7_75t_R   g128(.A(new_n349), .B(new_n350), .Y(new_n351));
  XOR2x2_ASAP7_75t_R   g129(.A(pi105), .B(pi106), .Y(new_n352));
  XOR2x2_ASAP7_75t_R   g130(.A(pi103), .B(pi104), .Y(new_n353));
  XOR2x2_ASAP7_75t_R   g131(.A(new_n352), .B(new_n353), .Y(new_n354));
  XNOR2x2_ASAP7_75t_R  g132(.A(pi101), .B(pi102), .Y(new_n355));
  XOR2x2_ASAP7_75t_R   g133(.A(new_n354), .B(new_n355), .Y(new_n356));
  XOR2x2_ASAP7_75t_R   g134(.A(new_n356), .B(new_n351), .Y(po52));
  NOR2x1_ASAP7_75t_R   g135(.A(pi113), .B(new_n244), .Y(new_n358));
  AO22x1_ASAP7_75t_R   g136(.A1(new_n268), .A2(pi115), .B1(pi114), .B2(new_n267), .Y(new_n359));
  AO221x2_ASAP7_75t_R  g137(.A1(pi116), .A2(new_n270), .B1(new_n271), .B2(pi117), .C(new_n359), .Y(new_n360));
  INVx1_ASAP7_75t_R    g138(.A(new_n360), .Y(new_n361));
  AO21x1_ASAP7_75t_R   g139(.A1(new_n361), .A2(new_n244), .B(new_n358), .Y(new_n362));
  NOR2x1_ASAP7_75t_R   g140(.A(pi102), .B(new_n362), .Y(new_n363));
  NOR2x1_ASAP7_75t_R   g141(.A(pi131), .B(po35), .Y(new_n364));
  AO21x1_ASAP7_75t_R   g142(.A1(pi131), .A2(new_n252), .B(new_n364), .Y(new_n365));
  INVx1_ASAP7_75t_R    g143(.A(new_n365), .Y(new_n366));
  AO22x1_ASAP7_75t_R   g144(.A1(new_n362), .A2(pi102), .B1(pi108), .B2(new_n365), .Y(new_n367));
  NOR2x1_ASAP7_75t_R   g145(.A(pi131), .B(new_n317), .Y(new_n368));
  AO21x1_ASAP7_75t_R   g146(.A1(pi131), .A2(new_n251), .B(new_n368), .Y(new_n369));
  NOR2x1_ASAP7_75t_R   g147(.A(pi131), .B(po36), .Y(new_n370));
  AO21x1_ASAP7_75t_R   g148(.A1(pi131), .A2(new_n253), .B(new_n370), .Y(new_n371));
  OAI22x1_ASAP7_75t_R  g149(.A1(new_n371), .A2(pi105), .B1(new_n369), .B2(pi089), .Y(new_n372));
  NAND2x1_ASAP7_75t_R  g150(.A(new_n244), .B(po28), .Y(new_n373));
  OAI21x1_ASAP7_75t_R  g151(.A1(new_n244), .A2(pi128), .B(new_n373), .Y(new_n374));
  NOR2x1_ASAP7_75t_R   g152(.A(pi131), .B(po38), .Y(new_n375));
  AO21x1_ASAP7_75t_R   g153(.A1(new_n246), .A2(pi131), .B(new_n375), .Y(new_n376));
  NOR2x1_ASAP7_75t_R   g154(.A(pi103), .B(new_n376), .Y(new_n377));
  AO21x1_ASAP7_75t_R   g155(.A1(pi022), .A2(new_n374), .B(new_n377), .Y(new_n378));
  AO22x1_ASAP7_75t_R   g156(.A1(new_n268), .A2(pi137), .B1(pi136), .B2(new_n267), .Y(new_n379));
  AO221x2_ASAP7_75t_R  g157(.A1(pi138), .A2(new_n270), .B1(new_n271), .B2(pi139), .C(new_n379), .Y(new_n380));
  NOR2x1_ASAP7_75t_R   g158(.A(pi111), .B(new_n380), .Y(new_n381));
  AO21x1_ASAP7_75t_R   g159(.A1(pi111), .A2(new_n249), .B(new_n381), .Y(new_n382));
  NOR2x1_ASAP7_75t_R   g160(.A(pi118), .B(new_n244), .Y(new_n383));
  AO22x1_ASAP7_75t_R   g161(.A1(new_n268), .A2(pi120), .B1(pi119), .B2(new_n267), .Y(new_n384));
  AO221x2_ASAP7_75t_R  g162(.A1(pi121), .A2(new_n270), .B1(new_n271), .B2(pi122), .C(new_n384), .Y(new_n385));
  INVx1_ASAP7_75t_R    g163(.A(new_n385), .Y(new_n386));
  AO21x1_ASAP7_75t_R   g164(.A1(new_n386), .A2(new_n244), .B(new_n383), .Y(new_n387));
  NOR2x1_ASAP7_75t_R   g165(.A(pi098), .B(new_n387), .Y(new_n388));
  AO21x1_ASAP7_75t_R   g166(.A1(pi101), .A2(new_n382), .B(new_n388), .Y(new_n389));
  NAND2x1_ASAP7_75t_R  g167(.A(pi131), .B(new_n250), .Y(new_n390));
  OAI21x1_ASAP7_75t_R  g168(.A1(pi131), .A2(new_n299), .B(new_n390), .Y(new_n391));
  AO221x2_ASAP7_75t_R  g169(.A1(pi098), .A2(new_n387), .B1(new_n391), .B2(pi088), .C(new_n389), .Y(new_n392));
  OR5x1_ASAP7_75t_R    g170(.A(new_n392), .B(new_n372), .C(new_n367), .D(new_n363), .E(new_n378), .Y(new_n393));
  AO22x1_ASAP7_75t_R   g171(.A1(new_n268), .A2(pi125), .B1(pi124), .B2(new_n267), .Y(new_n394));
  AO221x2_ASAP7_75t_R  g172(.A1(pi126), .A2(new_n270), .B1(new_n271), .B2(pi127), .C(new_n394), .Y(new_n395));
  NOR2x1_ASAP7_75t_R   g173(.A(pi111), .B(new_n395), .Y(new_n396));
  AO21x1_ASAP7_75t_R   g174(.A1(pi111), .A2(new_n245), .B(new_n396), .Y(new_n397));
  XNOR2x2_ASAP7_75t_R  g175(.A(pi021), .B(new_n397), .Y(new_n398));
  NOR2x1_ASAP7_75t_R   g176(.A(pi129), .B(new_n244), .Y(new_n399));
  AO21x1_ASAP7_75t_R   g177(.A1(po06), .A2(new_n244), .B(new_n399), .Y(new_n400));
  XNOR2x2_ASAP7_75t_R  g178(.A(pi023), .B(new_n400), .Y(new_n401));
  NOR2x1_ASAP7_75t_R   g179(.A(pi112), .B(new_n244), .Y(new_n402));
  AO21x1_ASAP7_75t_R   g180(.A1(po27), .A2(new_n244), .B(new_n402), .Y(new_n403));
  XNOR2x2_ASAP7_75t_R  g181(.A(pi024), .B(new_n403), .Y(new_n404));
  NOR2x1_ASAP7_75t_R   g182(.A(pi131), .B(po37), .Y(new_n405));
  AO21x1_ASAP7_75t_R   g183(.A1(pi131), .A2(new_n254), .B(new_n405), .Y(new_n406));
  AO22x1_ASAP7_75t_R   g184(.A1(new_n406), .A2(pi106), .B1(new_n243), .B2(new_n366), .Y(new_n407));
  NOR2x1_ASAP7_75t_R   g185(.A(pi131), .B(po41), .Y(new_n408));
  AO21x1_ASAP7_75t_R   g186(.A1(pi131), .A2(new_n248), .B(new_n408), .Y(new_n409));
  XNOR2x2_ASAP7_75t_R  g187(.A(pi100), .B(new_n409), .Y(new_n410));
  NAND2x1_ASAP7_75t_R  g188(.A(pi131), .B(pi132), .Y(new_n411));
  OA21x2_ASAP7_75t_R   g189(.A1(new_n310), .A2(pi131), .B(new_n411), .Y(new_n412));
  NOR2x1_ASAP7_75t_R   g190(.A(pi104), .B(new_n412), .Y(new_n413));
  OA21x2_ASAP7_75t_R   g191(.A1(new_n244), .A2(pi110), .B(pi109), .Y(new_n414));
  OAI21x1_ASAP7_75t_R  g192(.A1(pi111), .A2(new_n328), .B(new_n414), .Y(new_n415));
  NOR2x1_ASAP7_75t_R   g193(.A(pi131), .B(po40), .Y(new_n416));
  AO21x1_ASAP7_75t_R   g194(.A1(pi131), .A2(new_n247), .B(new_n416), .Y(new_n417));
  AO22x1_ASAP7_75t_R   g195(.A1(new_n417), .A2(pi099), .B1(pi104), .B2(new_n412), .Y(new_n418));
  OR5x1_ASAP7_75t_R    g196(.A(new_n410), .B(new_n413), .C(new_n415), .D(new_n418), .E(new_n407), .Y(new_n419));
  OAI22x1_ASAP7_75t_R  g197(.A1(pi088), .A2(new_n391), .B1(new_n382), .B2(pi101), .Y(new_n420));
  OAI22x1_ASAP7_75t_R  g198(.A1(new_n417), .A2(pi099), .B1(new_n406), .B2(pi106), .Y(new_n421));
  NAND2x1_ASAP7_75t_R  g199(.A(pi103), .B(new_n376), .Y(new_n422));
  OAI21x1_ASAP7_75t_R  g200(.A1(pi022), .A2(new_n374), .B(new_n422), .Y(new_n423));
  AO221x2_ASAP7_75t_R  g201(.A1(pi089), .A2(new_n369), .B1(new_n371), .B2(pi105), .C(new_n423), .Y(new_n424));
  OR4x2_ASAP7_75t_R    g202(.A(new_n419), .B(new_n420), .C(new_n421), .D(new_n424), .Y(new_n425));
  OR5x1_ASAP7_75t_R    g203(.A(new_n425), .B(new_n404), .C(new_n393), .D(new_n401), .E(new_n398), .Y(po53));
  AO21x1_ASAP7_75t_R   g204(.A1(new_n318), .A2(pi079), .B(pi050), .Y(new_n427));
  AND2x2_ASAP7_75t_R   g205(.A(new_n427), .B(po32), .Y(new_n428));
  AOI22x1_ASAP7_75t_R  g206(.A1(pi145), .A2(new_n284), .B1(new_n285), .B2(pi146), .Y(new_n429));
  AOI22x1_ASAP7_75t_R  g207(.A1(pi148), .A2(new_n288), .B1(new_n287), .B2(pi147), .Y(new_n430));
  NAND2x1_ASAP7_75t_R  g208(.A(new_n429), .B(new_n430), .Y(new_n431));
  AOI22x1_ASAP7_75t_R  g209(.A1(new_n430), .A2(new_n429), .B1(new_n298), .B2(new_n297), .Y(new_n432));
  AND4x2_ASAP7_75t_R   g210(.A(new_n298), .B(new_n430), .C(new_n429), .D(new_n297), .Y(new_n433));
  NOR2x1_ASAP7_75t_R   g211(.A(new_n432), .B(new_n433), .Y(new_n434));
  XOR2x2_ASAP7_75t_R   g212(.A(new_n428), .B(new_n434), .Y(po55));
  XOR2x2_ASAP7_75t_R   g213(.A(po06), .B(new_n279), .Y(new_n436));
  XNOR2x2_ASAP7_75t_R  g214(.A(new_n328), .B(new_n436), .Y(new_n437));
  AO22x1_ASAP7_75t_R   g215(.A1(new_n268), .A2(pi150), .B1(pi149), .B2(new_n267), .Y(new_n438));
  AO221x2_ASAP7_75t_R  g216(.A1(pi151), .A2(new_n270), .B1(new_n271), .B2(pi152), .C(new_n438), .Y(new_n439));
  XOR2x2_ASAP7_75t_R   g217(.A(new_n385), .B(new_n439), .Y(new_n440));
  XNOR2x2_ASAP7_75t_R  g218(.A(po28), .B(new_n380), .Y(new_n441));
  XOR2x2_ASAP7_75t_R   g219(.A(new_n441), .B(new_n395), .Y(new_n442));
  XOR2x2_ASAP7_75t_R   g220(.A(new_n442), .B(new_n360), .Y(new_n443));
  XOR2x2_ASAP7_75t_R   g221(.A(new_n443), .B(new_n440), .Y(new_n444));
  AOI21x1_ASAP7_75t_R  g222(.A1(new_n437), .A2(new_n444), .B(pi153), .Y(new_n445));
  OAI21x1_ASAP7_75t_R  g223(.A1(new_n437), .A2(new_n444), .B(new_n445), .Y(po56));
  XOR2x2_ASAP7_75t_R   g224(.A(po38), .B(po40), .Y(new_n447));
  XNOR2x2_ASAP7_75t_R  g225(.A(po39), .B(po41), .Y(new_n448));
  XOR2x2_ASAP7_75t_R   g226(.A(new_n448), .B(new_n447), .Y(new_n449));
  OA211x2_ASAP7_75t_R  g227(.A1(new_n433), .A2(new_n432), .B(new_n306), .C(new_n305), .Y(new_n450));
  AOI211x1_ASAP7_75t_R g228(.A1(new_n305), .A2(new_n306), .B(new_n433), .C(new_n432), .Y(new_n451));
  OR2x4_ASAP7_75t_R    g229(.A(new_n451), .B(new_n450), .Y(new_n452));
  XOR2x2_ASAP7_75t_R   g230(.A(new_n452), .B(new_n318), .Y(new_n453));
  OA21x2_ASAP7_75t_R   g231(.A1(pi079), .A2(new_n317), .B(new_n453), .Y(new_n454));
  AOI21x1_ASAP7_75t_R  g232(.A1(new_n324), .A2(new_n452), .B(new_n454), .Y(new_n455));
  XOR2x2_ASAP7_75t_R   g233(.A(new_n455), .B(new_n449), .Y(new_n456));
  NAND2x1_ASAP7_75t_R  g234(.A(pi078), .B(new_n456), .Y(new_n457));
  OA21x2_ASAP7_75t_R   g235(.A1(pi078), .A2(new_n431), .B(new_n457), .Y(po57));
  XOR2x2_ASAP7_75t_R   g236(.A(new_n453), .B(po30), .Y(new_n459));
  XOR2x2_ASAP7_75t_R   g237(.A(new_n459), .B(po36), .Y(new_n460));
  AOI21x1_ASAP7_75t_R  g238(.A1(new_n449), .A2(new_n460), .B(pi153), .Y(new_n461));
  OAI21x1_ASAP7_75t_R  g239(.A1(new_n449), .A2(new_n460), .B(new_n461), .Y(po59));
  AOI21x1_ASAP7_75t_R  g240(.A1(new_n281), .A2(new_n282), .B(pi155), .Y(new_n463));
  AND3x1_ASAP7_75t_R   g241(.A(po06), .B(new_n463), .C(pi154), .Y(new_n464));
  INVx1_ASAP7_75t_R    g242(.A(new_n464), .Y(new_n465));
  AND2x2_ASAP7_75t_R   g243(.A(new_n464), .B(pi022), .Y(new_n466));
  AOI21x1_ASAP7_75t_R  g244(.A1(pi105), .A2(new_n465), .B(new_n466), .Y(new_n467));
  OR2x4_ASAP7_75t_R    g245(.A(po36), .B(new_n467), .Y(new_n468));
  NAND2x1_ASAP7_75t_R  g246(.A(pi021), .B(new_n464), .Y(new_n469));
  OA21x2_ASAP7_75t_R   g247(.A1(new_n243), .A2(new_n464), .B(new_n469), .Y(new_n470));
  AO21x1_ASAP7_75t_R   g248(.A1(new_n464), .A2(pi102), .B(new_n299), .Y(new_n471));
  AOI21x1_ASAP7_75t_R  g249(.A1(pi088), .A2(new_n465), .B(new_n471), .Y(new_n472));
  NAND2x1_ASAP7_75t_R  g250(.A(pi098), .B(new_n464), .Y(new_n473));
  OA21x2_ASAP7_75t_R   g251(.A1(new_n239), .A2(new_n464), .B(new_n473), .Y(new_n474));
  MAJx2_ASAP7_75t_R    g252(.A(new_n472), .B(new_n318), .C(new_n474), .Y(new_n475));
  MAJx2_ASAP7_75t_R    g253(.A(new_n475), .B(new_n470), .C(po35), .Y(new_n476));
  AND2x2_ASAP7_75t_R   g254(.A(new_n464), .B(pi023), .Y(new_n477));
  AOI21x1_ASAP7_75t_R  g255(.A1(pi106), .A2(new_n465), .B(new_n477), .Y(new_n478));
  AO32x1_ASAP7_75t_R   g256(.A1(pi156), .A2(new_n478), .A3(po37), .B1(po36), .B2(new_n467), .Y(new_n479));
  AO21x1_ASAP7_75t_R   g257(.A1(new_n476), .A2(new_n468), .B(new_n479), .Y(new_n480));
  OR3x1_ASAP7_75t_R    g258(.A(new_n478), .B(po37), .C(new_n255), .Y(new_n481));
  AND2x2_ASAP7_75t_R   g259(.A(new_n464), .B(pi024), .Y(new_n482));
  AO21x1_ASAP7_75t_R   g260(.A1(pi103), .A2(new_n465), .B(new_n482), .Y(new_n483));
  INVx1_ASAP7_75t_R    g261(.A(new_n483), .Y(new_n484));
  AO32x1_ASAP7_75t_R   g262(.A1(pi156), .A2(po38), .A3(new_n484), .B1(new_n481), .B2(new_n480), .Y(new_n485));
  NAND2x1_ASAP7_75t_R  g263(.A(pi099), .B(pi104), .Y(new_n486));
  AND3x1_ASAP7_75t_R   g264(.A(new_n464), .B(po40), .C(po39), .Y(new_n487));
  INVx1_ASAP7_75t_R    g265(.A(new_n487), .Y(new_n488));
  OA211x2_ASAP7_75t_R  g266(.A1(new_n464), .A2(new_n486), .B(new_n488), .C(pi156), .Y(new_n489));
  AND3x1_ASAP7_75t_R   g267(.A(new_n483), .B(po29), .C(pi156), .Y(new_n490));
  NOR2x1_ASAP7_75t_R   g268(.A(new_n489), .B(new_n490), .Y(new_n491));
  AO32x1_ASAP7_75t_R   g269(.A1(pi156), .A2(new_n465), .A3(new_n486), .B1(new_n491), .B2(new_n485), .Y(new_n492));
  OA211x2_ASAP7_75t_R  g270(.A1(pi155), .A2(po28), .B(po06), .C(pi154), .Y(new_n493));
  INVx1_ASAP7_75t_R    g271(.A(new_n493), .Y(new_n494));
  AND3x1_ASAP7_75t_R   g272(.A(new_n493), .B(new_n380), .C(pi101), .Y(new_n495));
  NOR3x1_ASAP7_75t_R   g273(.A(new_n494), .B(new_n380), .C(pi101), .Y(new_n496));
  AND3x1_ASAP7_75t_R   g274(.A(new_n493), .B(new_n386), .C(pi098), .Y(new_n497));
  OR3x1_ASAP7_75t_R    g275(.A(new_n494), .B(new_n385), .C(new_n241), .Y(new_n498));
  AND3x1_ASAP7_75t_R   g276(.A(new_n493), .B(new_n385), .C(new_n241), .Y(new_n499));
  OR4x2_ASAP7_75t_R    g277(.A(new_n496), .B(new_n497), .C(new_n499), .D(new_n495), .Y(new_n500));
  AND3x1_ASAP7_75t_R   g278(.A(new_n493), .B(new_n361), .C(new_n242), .Y(new_n501));
  AND2x2_ASAP7_75t_R   g279(.A(new_n360), .B(pi102), .Y(new_n502));
  INVx1_ASAP7_75t_R    g280(.A(new_n502), .Y(new_n503));
  AO21x1_ASAP7_75t_R   g281(.A1(new_n493), .A2(new_n502), .B(new_n501), .Y(new_n504));
  XOR2x2_ASAP7_75t_R   g282(.A(po41), .B(pi100), .Y(new_n505));
  AOI211x1_ASAP7_75t_R g283(.A1(new_n493), .A2(new_n505), .B(new_n500), .C(new_n504), .Y(new_n506));
  OR5x1_ASAP7_75t_R    g284(.A(new_n501), .B(new_n502), .C(pi100), .D(new_n315), .E(new_n494), .Y(new_n507));
  NOR2x1_ASAP7_75t_R   g285(.A(new_n507), .B(new_n500), .Y(new_n508));
  AO21x1_ASAP7_75t_R   g286(.A1(new_n496), .A2(new_n503), .B(new_n501), .Y(new_n509));
  AO21x1_ASAP7_75t_R   g287(.A1(new_n509), .A2(new_n498), .B(new_n499), .Y(new_n510));
  AOI211x1_ASAP7_75t_R g288(.A1(new_n492), .A2(new_n506), .B(new_n508), .C(new_n510), .Y(po60));
  OR3x1_ASAP7_75t_R    g289(.A(po51), .B(po52), .C(po05), .Y(new_n512));
  NOR2x1_ASAP7_75t_R   g290(.A(new_n512), .B(new_n340), .Y(new_n513));
  NAND3x1_ASAP7_75t_R  g291(.A(po59), .B(new_n513), .C(po56), .Y(po62));
  assign               po61 = 1'b0;
  NAND2x1_ASAP7_75t_R  g292(.A(new_n261), .B(new_n263), .Y(po04));
  INVx1_ASAP7_75t_R    g293(.A(pi018), .Y(po08));
  INVx1_ASAP7_75t_R    g294(.A(pi018), .Y(po09));
  INVx1_ASAP7_75t_R    g295(.A(pi019), .Y(po11));
  INVx1_ASAP7_75t_R    g296(.A(pi020), .Y(po13));
  INVx1_ASAP7_75t_R    g297(.A(pi020), .Y(po14));
  BUFx2_ASAP7_75t_R    g298(.A(pi018), .Y(po25));
  AO21x1_ASAP7_75t_R   g299(.A1(pi078), .A2(po36), .B(new_n319), .Y(po43));
  AO21x1_ASAP7_75t_R   g300(.A1(po30), .A2(pi078), .B(new_n321), .Y(po45));
  OA21x2_ASAP7_75t_R   g301(.A1(pi078), .A2(new_n300), .B(new_n325), .Y(po48));
  OR5x1_ASAP7_75t_R    g302(.A(new_n425), .B(new_n404), .C(new_n393), .D(new_n401), .E(new_n398), .Y(po54));
  OA21x2_ASAP7_75t_R   g303(.A1(pi078), .A2(new_n431), .B(new_n457), .Y(po58));
  NAND3x1_ASAP7_75t_R  g304(.A(po59), .B(new_n513), .C(po56), .Y(po63));
endmodule


