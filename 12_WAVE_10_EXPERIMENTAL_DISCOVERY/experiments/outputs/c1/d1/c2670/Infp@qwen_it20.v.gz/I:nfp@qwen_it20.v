// Benchmark "/w/experiments/inputs/c1/c2/c2670" written by ABC on Fri Sep 25 10:27:06 2026

module \/w/experiments/inputs/c1/c2/c2670  ( 
    pi000, pi001, pi002, pi003, pi004, pi005, pi006, pi007, pi008, pi009,
    pi010, pi011, pi012, pi013, pi014, pi015, pi016, pi017, pi018, pi019,
    pi020, pi021, pi022, pi023, pi024, pi025, pi026, pi027, pi028, pi029,
    pi030, pi031, pi032, pi033, pi034, pi035, pi036, pi037, pi038, pi039,
    pi040, pi041, pi042, pi043, pi044, pi045, pi046, pi047, pi048, pi049,
    pi050, pi051, pi052, pi053, pi054, pi055, pi056, pi057, pi058, pi059,
    pi060, pi061, pi062, pi063, pi064, pi065, pi066, pi067, pi068, pi069,
    pi070, pi071, pi072, pi073, pi074, pi075, pi076, pi077, pi078, pi079,
    pi080, pi081, pi082, pi083, pi084, pi085, pi086, pi087, pi088, pi089,
    pi090, pi091, pi092, pi093, pi094, pi095, pi096, pi097, pi098, pi099,
    pi100, pi101, pi102, pi103, pi104, pi105, pi106, pi107, pi108, pi109,
    pi110, pi111, pi112, pi113, pi114, pi115, pi116, pi117, pi118, pi119,
    pi120, pi121, pi122, pi123, pi124, pi125, pi126, pi127, pi128, pi129,
    pi130, pi131, pi132, pi133, pi134, pi135, pi136, pi137, pi138, pi139,
    pi140, pi141, pi142, pi143, pi144, pi145, pi146, pi147, pi148, pi149,
    pi150, pi151, pi152, pi153, pi154, pi155, pi156,
    po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10, po11,
    po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22, po23,
    po24, po25, po26, po27, po28, po29, po30, po31, po32, po33, po34, po35,
    po36, po37, po38, po39, po40, po41, po42, po43, po44, po45, po46, po47,
    po48, po49, po50, po51, po52, po53, po54, po55, po56, po57, po58, po59,
    po60, po61, po62, po63  );
  input  pi000, pi001, pi002, pi003, pi004, pi005, pi006, pi007, pi008,
    pi009, pi010, pi011, pi012, pi013, pi014, pi015, pi016, pi017, pi018,
    pi019, pi020, pi021, pi022, pi023, pi024, pi025, pi026, pi027, pi028,
    pi029, pi030, pi031, pi032, pi033, pi034, pi035, pi036, pi037, pi038,
    pi039, pi040, pi041, pi042, pi043, pi044, pi045, pi046, pi047, pi048,
    pi049, pi050, pi051, pi052, pi053, pi054, pi055, pi056, pi057, pi058,
    pi059, pi060, pi061, pi062, pi063, pi064, pi065, pi066, pi067, pi068,
    pi069, pi070, pi071, pi072, pi073, pi074, pi075, pi076, pi077, pi078,
    pi079, pi080, pi081, pi082, pi083, pi084, pi085, pi086, pi087, pi088,
    pi089, pi090, pi091, pi092, pi093, pi094, pi095, pi096, pi097, pi098,
    pi099, pi100, pi101, pi102, pi103, pi104, pi105, pi106, pi107, pi108,
    pi109, pi110, pi111, pi112, pi113, pi114, pi115, pi116, pi117, pi118,
    pi119, pi120, pi121, pi122, pi123, pi124, pi125, pi126, pi127, pi128,
    pi129, pi130, pi131, pi132, pi133, pi134, pi135, pi136, pi137, pi138,
    pi139, pi140, pi141, pi142, pi143, pi144, pi145, pi146, pi147, pi148,
    pi149, pi150, pi151, pi152, pi153, pi154, pi155, pi156;
  output po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10,
    po11, po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22,
    po23, po24, po25, po26, po27, po28, po29, po30, po31, po32, po33, po34,
    po35, po36, po37, po38, po39, po40, po41, po42, po43, po44, po45, po46,
    po47, po48, po49, po50, po51, po52, po53, po54, po55, po56, po57, po58,
    po59, po60, po61, po62, po63;
  wire new_n231, new_n232, new_n236, new_n237, new_n238, new_n239, new_n240,
    new_n241, new_n242, new_n243, new_n244, new_n245, new_n246, new_n247,
    new_n248, new_n249, new_n250, new_n251, new_n252, new_n253, new_n254,
    new_n255, new_n256, new_n258, new_n260, new_n262, new_n263, new_n264,
    new_n265, new_n268, new_n269, new_n270, new_n271, new_n272, new_n273,
    new_n274, new_n275, new_n277, new_n279, new_n282, new_n283, new_n285,
    new_n286, new_n287, new_n288, new_n289, new_n291, new_n292, new_n293,
    new_n294, new_n295, new_n298, new_n299, new_n300, new_n303, new_n306,
    new_n307, new_n308, new_n309, new_n311, new_n314, new_n315, new_n316,
    new_n318, new_n320, new_n321, new_n323, new_n325, new_n326, new_n327,
    new_n328, new_n329, new_n331, new_n334, new_n335, new_n337, new_n338,
    new_n339, new_n341, new_n342, new_n343, new_n344, new_n345, new_n346,
    new_n347, new_n348, new_n349, new_n350, new_n352, new_n353, new_n354,
    new_n355, new_n356, new_n357, new_n359, new_n360, new_n361, new_n362,
    new_n363, new_n364, new_n365, new_n366, new_n368, new_n369, new_n370,
    new_n371, new_n372, new_n373, new_n374, new_n375, new_n376, new_n377,
    new_n378, new_n379, new_n380, new_n381, new_n382, new_n383, new_n384,
    new_n385, new_n386, new_n387, new_n388, new_n389, new_n390, new_n391,
    new_n392, new_n393, new_n394, new_n395, new_n396, new_n397, new_n398,
    new_n399, new_n400, new_n401, new_n402, new_n403, new_n404, new_n405,
    new_n406, new_n407, new_n408, new_n409, new_n410, new_n411, new_n412,
    new_n413, new_n414, new_n415, new_n416, new_n417, new_n418, new_n419,
    new_n420, new_n421, new_n422, new_n423, new_n424, new_n425, new_n426,
    new_n427, new_n428, new_n429, new_n430, new_n431, new_n432, new_n433,
    new_n434, new_n435, new_n436, new_n438, new_n439, new_n440, new_n441,
    new_n442, new_n443, new_n444, new_n446, new_n447, new_n448, new_n449,
    new_n450, new_n451, new_n452, new_n453, new_n454, new_n455, new_n456,
    new_n457, new_n458, new_n459, new_n461, new_n462, new_n463, new_n464,
    new_n465, new_n466, new_n467, new_n468, new_n469, new_n470, new_n471,
    new_n472, new_n473, new_n475, new_n476, new_n477, new_n478, new_n479,
    new_n480, new_n481, new_n483, new_n484, new_n485, new_n486, new_n487,
    new_n488, new_n489, new_n490, new_n491, new_n492, new_n493, new_n494,
    new_n495, new_n496, new_n497, new_n498, new_n499, new_n500, new_n501,
    new_n502, new_n503, new_n504, new_n505, new_n506, new_n507, new_n508,
    new_n509, new_n510, new_n511, new_n512, new_n513, new_n514, new_n515,
    new_n516, new_n517, new_n518, new_n519, new_n520, new_n521, new_n522,
    new_n523, new_n524, new_n525, new_n526, new_n527, new_n528, new_n529,
    new_n530, new_n531, new_n532, new_n533, new_n535;
  INVx1_ASAP7_75t_R    g000(.A(pi004), .Y(po19));
  INVx1_ASAP7_75t_R    g001(.A(pi005), .Y(po22));
  INVx1_ASAP7_75t_R    g002(.A(pi006), .Y(po21));
  INVx1_ASAP7_75t_R    g003(.A(pi007), .Y(po20));
  INVx1_ASAP7_75t_R    g004(.A(pi008), .Y(po15));
  INVx1_ASAP7_75t_R    g005(.A(pi009), .Y(po18));
  INVx1_ASAP7_75t_R    g006(.A(pi010), .Y(po17));
  INVx1_ASAP7_75t_R    g007(.A(pi011), .Y(po16));
  INVx1_ASAP7_75t_R    g008(.A(pi012), .Y(new_n231));
  INVx1_ASAP7_75t_R    g009(.A(pi016), .Y(new_n232));
  INVx1_ASAP7_75t_R    g010(.A(pi018), .Y(po07));
  INVx1_ASAP7_75t_R    g011(.A(pi019), .Y(po10));
  INVx1_ASAP7_75t_R    g012(.A(pi020), .Y(po12));
  INVx1_ASAP7_75t_R    g013(.A(pi036), .Y(new_n236));
  INVx1_ASAP7_75t_R    g014(.A(pi050), .Y(new_n237));
  INVx1_ASAP7_75t_R    g015(.A(pi055), .Y(new_n238));
  INVx1_ASAP7_75t_R    g016(.A(pi056), .Y(new_n239));
  INVx1_ASAP7_75t_R    g017(.A(pi078), .Y(new_n240));
  INVx1_ASAP7_75t_R    g018(.A(pi096), .Y(new_n241));
  INVx1_ASAP7_75t_R    g019(.A(pi098), .Y(new_n242));
  INVx1_ASAP7_75t_R    g020(.A(pi101), .Y(new_n243));
  INVx1_ASAP7_75t_R    g021(.A(pi108), .Y(new_n244));
  INVx1_ASAP7_75t_R    g022(.A(pi111), .Y(new_n245));
  INVx1_ASAP7_75t_R    g023(.A(pi113), .Y(new_n246));
  INVx1_ASAP7_75t_R    g024(.A(pi130), .Y(new_n247));
  INVx1_ASAP7_75t_R    g025(.A(pi133), .Y(new_n248));
  INVx1_ASAP7_75t_R    g026(.A(pi134), .Y(new_n249));
  INVx1_ASAP7_75t_R    g027(.A(pi140), .Y(new_n250));
  INVx1_ASAP7_75t_R    g028(.A(pi141), .Y(new_n251));
  INVx1_ASAP7_75t_R    g029(.A(pi142), .Y(new_n252));
  INVx1_ASAP7_75t_R    g030(.A(pi143), .Y(new_n253));
  INVx1_ASAP7_75t_R    g031(.A(pi144), .Y(new_n254));
  INVx1_ASAP7_75t_R    g032(.A(pi153), .Y(new_n255));
  INVx1_ASAP7_75t_R    g033(.A(pi156), .Y(new_n256));
  NAND2x1_ASAP7_75t_R  g034(.A(pi000), .B(pi001), .Y(po00));
  AND3x1_ASAP7_75t_R   g035(.A(pi000), .B(pi001), .C(pi002), .Y(new_n258));
  INVx1_ASAP7_75t_R    g036(.A(new_n258), .Y(po01));
  AND3x1_ASAP7_75t_R   g037(.A(pi000), .B(pi001), .C(pi003), .Y(new_n260));
  INVx1_ASAP7_75t_R    g038(.A(new_n260), .Y(po02));
  AND4x2_ASAP7_75t_R   g039(.A(pi004), .B(pi005), .C(pi006), .D(pi007), .Y(new_n262));
  INVx1_ASAP7_75t_R    g040(.A(new_n262), .Y(new_n263));
  AND4x2_ASAP7_75t_R   g041(.A(pi008), .B(pi009), .C(pi010), .D(pi011), .Y(new_n264));
  INVx1_ASAP7_75t_R    g042(.A(new_n264), .Y(new_n265));
  NAND2x1_ASAP7_75t_R  g043(.A(new_n262), .B(new_n264), .Y(po03));
  AO22x1_ASAP7_75t_R   g044(.A1(new_n265), .A2(pi003), .B1(new_n263), .B2(pi002), .Y(po05));
  NOR2x1_ASAP7_75t_R   g045(.A(pi012), .B(pi013), .Y(new_n268));
  NAND2x1_ASAP7_75t_R  g046(.A(pi014), .B(new_n268), .Y(new_n269));
  AND2x2_ASAP7_75t_R   g047(.A(new_n231), .B(pi013), .Y(new_n270));
  NAND3x1_ASAP7_75t_R  g048(.A(new_n231), .B(pi013), .C(pi015), .Y(new_n271));
  NOR2x1_ASAP7_75t_R   g049(.A(pi013), .B(new_n231), .Y(new_n272));
  OR3x1_ASAP7_75t_R    g050(.A(new_n231), .B(new_n232), .C(pi013), .Y(new_n273));
  AND2x2_ASAP7_75t_R   g051(.A(pi012), .B(pi013), .Y(new_n274));
  NAND2x1_ASAP7_75t_R  g052(.A(pi017), .B(new_n274), .Y(new_n275));
  AND4x2_ASAP7_75t_R   g053(.A(new_n269), .B(new_n271), .C(new_n275), .D(new_n273), .Y(po06));
  AND4x2_ASAP7_75t_R   g054(.A(pi021), .B(pi022), .C(pi023), .D(pi024), .Y(new_n277));
  INVx1_ASAP7_75t_R    g055(.A(new_n277), .Y(po23));
  AND3x1_ASAP7_75t_R   g056(.A(pi001), .B(pi025), .C(pi026), .Y(new_n279));
  INVx1_ASAP7_75t_R    g057(.A(new_n279), .Y(po24));
  AND2x2_ASAP7_75t_R   g058(.A(po07), .B(pi027), .Y(po26));
  AO22x1_ASAP7_75t_R   g059(.A1(new_n270), .A2(pi029), .B1(pi028), .B2(new_n268), .Y(new_n282));
  AO221x2_ASAP7_75t_R  g060(.A1(pi030), .A2(new_n272), .B1(new_n274), .B2(pi031), .C(new_n282), .Y(new_n283));
  INVx1_ASAP7_75t_R    g061(.A(new_n283), .Y(po27));
  AOI22x1_ASAP7_75t_R  g062(.A1(pi032), .A2(new_n268), .B1(new_n270), .B2(pi033), .Y(new_n285));
  AO22x1_ASAP7_75t_R   g063(.A1(new_n270), .A2(pi033), .B1(pi032), .B2(new_n268), .Y(new_n286));
  AND3x1_ASAP7_75t_R   g064(.A(pi012), .B(pi013), .C(pi035), .Y(new_n287));
  AOI21x1_ASAP7_75t_R  g065(.A1(pi034), .A2(new_n272), .B(new_n287), .Y(new_n288));
  AO21x1_ASAP7_75t_R   g066(.A1(new_n272), .A2(pi034), .B(new_n287), .Y(new_n289));
  AND2x2_ASAP7_75t_R   g067(.A(new_n285), .B(new_n288), .Y(po28));
  NOR2x1_ASAP7_75t_R   g068(.A(pi036), .B(pi037), .Y(new_n291));
  AND2x2_ASAP7_75t_R   g069(.A(new_n236), .B(pi037), .Y(new_n292));
  AO22x1_ASAP7_75t_R   g070(.A1(new_n292), .A2(pi039), .B1(pi038), .B2(new_n291), .Y(new_n293));
  NOR2x1_ASAP7_75t_R   g071(.A(pi037), .B(new_n236), .Y(new_n294));
  AND2x2_ASAP7_75t_R   g072(.A(pi036), .B(pi037), .Y(new_n295));
  AO221x2_ASAP7_75t_R  g073(.A1(pi040), .A2(new_n294), .B1(new_n295), .B2(pi041), .C(new_n293), .Y(po38));
  INVx1_ASAP7_75t_R    g074(.A(po38), .Y(po29));
  AO22x1_ASAP7_75t_R   g075(.A1(new_n292), .A2(pi043), .B1(pi042), .B2(new_n291), .Y(new_n298));
  INVx1_ASAP7_75t_R    g076(.A(new_n298), .Y(new_n299));
  AOI22x1_ASAP7_75t_R  g077(.A1(pi045), .A2(new_n295), .B1(new_n294), .B2(pi044), .Y(new_n300));
  NAND2x1_ASAP7_75t_R  g078(.A(new_n300), .B(new_n299), .Y(po37));
  INVx1_ASAP7_75t_R    g079(.A(po37), .Y(po30));
  AO22x1_ASAP7_75t_R   g080(.A1(new_n292), .A2(pi047), .B1(pi046), .B2(new_n291), .Y(new_n303));
  AO221x2_ASAP7_75t_R  g081(.A1(pi048), .A2(new_n294), .B1(new_n295), .B2(pi049), .C(new_n303), .Y(po36));
  INVx1_ASAP7_75t_R    g082(.A(po36), .Y(po31));
  AOI22x1_ASAP7_75t_R  g083(.A1(pi051), .A2(new_n291), .B1(new_n292), .B2(pi052), .Y(new_n306));
  AOI22x1_ASAP7_75t_R  g084(.A1(pi054), .A2(new_n295), .B1(new_n294), .B2(pi053), .Y(new_n307));
  NAND2x1_ASAP7_75t_R  g085(.A(new_n306), .B(new_n307), .Y(new_n308));
  INVx1_ASAP7_75t_R    g086(.A(new_n308), .Y(new_n309));
  NAND2x1_ASAP7_75t_R  g087(.A(pi050), .B(new_n309), .Y(po32));
  OR3x1_ASAP7_75t_R    g088(.A(po05), .B(new_n239), .C(pi001), .Y(new_n311));
  OR4x2_ASAP7_75t_R    g089(.A(po05), .B(new_n239), .C(new_n238), .D(pi001), .Y(po33));
  AO21x1_ASAP7_75t_R   g090(.A1(pi057), .A2(pi058), .B(new_n311), .Y(po34));
  AOI22x1_ASAP7_75t_R  g091(.A1(pi059), .A2(new_n291), .B1(new_n292), .B2(pi060), .Y(new_n314));
  AOI22x1_ASAP7_75t_R  g092(.A1(pi062), .A2(new_n295), .B1(new_n294), .B2(pi061), .Y(new_n315));
  AND2x2_ASAP7_75t_R   g093(.A(new_n315), .B(new_n314), .Y(new_n316));
  INVx1_ASAP7_75t_R    g094(.A(new_n316), .Y(po35));
  AO21x1_ASAP7_75t_R   g095(.A1(pi063), .A2(new_n291), .B(new_n292), .Y(new_n318));
  AO221x2_ASAP7_75t_R  g096(.A1(pi064), .A2(new_n294), .B1(new_n295), .B2(pi065), .C(new_n318), .Y(po39));
  INVx1_ASAP7_75t_R    g097(.A(po39), .Y(new_n320));
  AO22x1_ASAP7_75t_R   g098(.A1(new_n292), .A2(pi067), .B1(pi066), .B2(new_n291), .Y(new_n321));
  AO221x2_ASAP7_75t_R  g099(.A1(pi068), .A2(new_n294), .B1(new_n295), .B2(pi069), .C(new_n321), .Y(po40));
  AO22x1_ASAP7_75t_R   g100(.A1(new_n292), .A2(pi071), .B1(pi070), .B2(new_n291), .Y(new_n323));
  AO221x2_ASAP7_75t_R  g101(.A1(pi072), .A2(new_n294), .B1(new_n295), .B2(pi073), .C(new_n323), .Y(po41));
  INVx1_ASAP7_75t_R    g102(.A(po41), .Y(new_n325));
  AND2x2_ASAP7_75t_R   g103(.A(po36), .B(pi078), .Y(new_n326));
  AO22x1_ASAP7_75t_R   g104(.A1(new_n292), .A2(pi075), .B1(pi074), .B2(new_n291), .Y(new_n327));
  AO221x2_ASAP7_75t_R  g105(.A1(pi076), .A2(new_n294), .B1(new_n295), .B2(pi077), .C(new_n327), .Y(new_n328));
  INVx1_ASAP7_75t_R    g106(.A(new_n328), .Y(new_n329));
  AO21x1_ASAP7_75t_R   g107(.A1(new_n240), .A2(new_n329), .B(new_n326), .Y(po42));
  AND2x2_ASAP7_75t_R   g108(.A(po35), .B(new_n240), .Y(new_n331));
  AO21x1_ASAP7_75t_R   g109(.A1(pi078), .A2(po30), .B(new_n331), .Y(po44));
  AO21x1_ASAP7_75t_R   g110(.A1(new_n237), .A2(pi079), .B(new_n328), .Y(po46));
  OR2x4_ASAP7_75t_R    g111(.A(pi079), .B(new_n328), .Y(new_n334));
  NAND2x1_ASAP7_75t_R  g112(.A(pi078), .B(new_n334), .Y(new_n335));
  OA21x2_ASAP7_75t_R   g113(.A1(pi078), .A2(new_n309), .B(new_n335), .Y(po47));
  AO22x1_ASAP7_75t_R   g114(.A1(new_n270), .A2(pi083), .B1(pi082), .B2(new_n268), .Y(new_n337));
  AO221x2_ASAP7_75t_R  g115(.A1(pi084), .A2(new_n272), .B1(new_n274), .B2(pi085), .C(new_n337), .Y(new_n338));
  AOI21x1_ASAP7_75t_R  g116(.A1(pi081), .A2(new_n338), .B(pi080), .Y(new_n339));
  OAI21x1_ASAP7_75t_R  g117(.A1(pi081), .A2(new_n338), .B(new_n339), .Y(po49));
  XNOR2x2_ASAP7_75t_R  g118(.A(pi088), .B(pi089), .Y(new_n341));
  XNOR2x2_ASAP7_75t_R  g119(.A(pi090), .B(pi091), .Y(new_n342));
  XOR2x2_ASAP7_75t_R   g120(.A(new_n342), .B(pi094), .Y(new_n343));
  XOR2x2_ASAP7_75t_R   g121(.A(pi086), .B(pi087), .Y(new_n344));
  XOR2x2_ASAP7_75t_R   g122(.A(pi092), .B(pi093), .Y(new_n345));
  XOR2x2_ASAP7_75t_R   g123(.A(new_n345), .B(pi095), .Y(new_n346));
  XOR2x2_ASAP7_75t_R   g124(.A(new_n346), .B(new_n344), .Y(new_n347));
  XOR2x2_ASAP7_75t_R   g125(.A(new_n347), .B(new_n343), .Y(new_n348));
  AOI21x1_ASAP7_75t_R  g126(.A1(new_n341), .A2(new_n348), .B(new_n241), .Y(new_n349));
  OA21x2_ASAP7_75t_R   g127(.A1(new_n341), .A2(new_n348), .B(new_n349), .Y(new_n350));
  INVx1_ASAP7_75t_R    g128(.A(new_n350), .Y(po50));
  XOR2x2_ASAP7_75t_R   g129(.A(pi097), .B(pi098), .Y(new_n352));
  XOR2x2_ASAP7_75t_R   g130(.A(pi023), .B(pi024), .Y(new_n353));
  XOR2x2_ASAP7_75t_R   g131(.A(pi021), .B(pi022), .Y(new_n354));
  XOR2x2_ASAP7_75t_R   g132(.A(new_n353), .B(new_n354), .Y(new_n355));
  XNOR2x2_ASAP7_75t_R  g133(.A(pi080), .B(pi081), .Y(new_n356));
  XOR2x2_ASAP7_75t_R   g134(.A(new_n355), .B(new_n356), .Y(new_n357));
  XOR2x2_ASAP7_75t_R   g135(.A(new_n357), .B(new_n352), .Y(po51));
  XOR2x2_ASAP7_75t_R   g136(.A(pi099), .B(pi100), .Y(new_n359));
  XOR2x2_ASAP7_75t_R   g137(.A(pi107), .B(pi108), .Y(new_n360));
  XOR2x2_ASAP7_75t_R   g138(.A(new_n359), .B(new_n360), .Y(new_n361));
  XOR2x2_ASAP7_75t_R   g139(.A(pi105), .B(pi106), .Y(new_n362));
  XOR2x2_ASAP7_75t_R   g140(.A(pi103), .B(pi104), .Y(new_n363));
  XOR2x2_ASAP7_75t_R   g141(.A(new_n362), .B(new_n363), .Y(new_n364));
  XNOR2x2_ASAP7_75t_R  g142(.A(pi101), .B(pi102), .Y(new_n365));
  XOR2x2_ASAP7_75t_R   g143(.A(new_n364), .B(new_n365), .Y(new_n366));
  XOR2x2_ASAP7_75t_R   g144(.A(new_n366), .B(new_n361), .Y(po52));
  AO22x1_ASAP7_75t_R   g145(.A1(new_n270), .A2(pi115), .B1(pi114), .B2(new_n268), .Y(new_n368));
  AO221x2_ASAP7_75t_R  g146(.A1(pi116), .A2(new_n272), .B1(new_n274), .B2(pi117), .C(new_n368), .Y(new_n369));
  NOR2x1_ASAP7_75t_R   g147(.A(pi111), .B(new_n369), .Y(new_n370));
  AO21x1_ASAP7_75t_R   g148(.A1(pi111), .A2(new_n246), .B(new_n370), .Y(new_n371));
  NOR2x1_ASAP7_75t_R   g149(.A(pi102), .B(new_n371), .Y(new_n372));
  NOR2x1_ASAP7_75t_R   g150(.A(pi131), .B(po35), .Y(new_n373));
  AO21x1_ASAP7_75t_R   g151(.A1(pi131), .A2(new_n252), .B(new_n373), .Y(new_n374));
  INVx1_ASAP7_75t_R    g152(.A(new_n374), .Y(new_n375));
  AO22x1_ASAP7_75t_R   g153(.A1(new_n371), .A2(pi102), .B1(pi108), .B2(new_n374), .Y(new_n376));
  NOR2x1_ASAP7_75t_R   g154(.A(pi131), .B(new_n328), .Y(new_n377));
  AO21x1_ASAP7_75t_R   g155(.A1(pi131), .A2(new_n251), .B(new_n377), .Y(new_n378));
  NOR2x1_ASAP7_75t_R   g156(.A(pi131), .B(po36), .Y(new_n379));
  AO21x1_ASAP7_75t_R   g157(.A1(pi131), .A2(new_n253), .B(new_n379), .Y(new_n380));
  OAI22x1_ASAP7_75t_R  g158(.A1(new_n380), .A2(pi105), .B1(new_n378), .B2(pi089), .Y(new_n381));
  NOR2x1_ASAP7_75t_R   g159(.A(pi128), .B(new_n245), .Y(new_n382));
  AO21x1_ASAP7_75t_R   g160(.A1(po28), .A2(new_n245), .B(new_n382), .Y(new_n383));
  NOR2x1_ASAP7_75t_R   g161(.A(pi131), .B(po38), .Y(new_n384));
  AO21x1_ASAP7_75t_R   g162(.A1(new_n247), .A2(pi131), .B(new_n384), .Y(new_n385));
  NOR2x1_ASAP7_75t_R   g163(.A(pi103), .B(new_n385), .Y(new_n386));
  AO21x1_ASAP7_75t_R   g164(.A1(pi022), .A2(new_n383), .B(new_n386), .Y(new_n387));
  AOI22x1_ASAP7_75t_R  g165(.A1(pi136), .A2(new_n268), .B1(new_n270), .B2(pi137), .Y(new_n388));
  AO22x1_ASAP7_75t_R   g166(.A1(new_n270), .A2(pi137), .B1(pi136), .B2(new_n268), .Y(new_n389));
  AOI22x1_ASAP7_75t_R  g167(.A1(pi139), .A2(new_n274), .B1(new_n272), .B2(pi138), .Y(new_n390));
  AO22x1_ASAP7_75t_R   g168(.A1(new_n272), .A2(pi138), .B1(pi139), .B2(new_n274), .Y(new_n391));
  OR3x1_ASAP7_75t_R    g169(.A(new_n391), .B(new_n389), .C(pi111), .Y(new_n392));
  OAI21x1_ASAP7_75t_R  g170(.A1(new_n245), .A2(pi135), .B(new_n392), .Y(new_n393));
  NOR2x1_ASAP7_75t_R   g171(.A(pi118), .B(new_n245), .Y(new_n394));
  AO22x1_ASAP7_75t_R   g172(.A1(new_n270), .A2(pi120), .B1(pi119), .B2(new_n268), .Y(new_n395));
  AO221x2_ASAP7_75t_R  g173(.A1(pi121), .A2(new_n272), .B1(new_n274), .B2(pi122), .C(new_n395), .Y(new_n396));
  INVx1_ASAP7_75t_R    g174(.A(new_n396), .Y(new_n397));
  AO21x1_ASAP7_75t_R   g175(.A1(new_n397), .A2(new_n245), .B(new_n394), .Y(new_n398));
  NOR2x1_ASAP7_75t_R   g176(.A(pi098), .B(new_n398), .Y(new_n399));
  AO21x1_ASAP7_75t_R   g177(.A1(pi101), .A2(new_n393), .B(new_n399), .Y(new_n400));
  NAND2x1_ASAP7_75t_R  g178(.A(pi131), .B(new_n250), .Y(new_n401));
  OAI21x1_ASAP7_75t_R  g179(.A1(pi131), .A2(new_n308), .B(new_n401), .Y(new_n402));
  AO221x2_ASAP7_75t_R  g180(.A1(pi098), .A2(new_n398), .B1(new_n402), .B2(pi088), .C(new_n400), .Y(new_n403));
  OR5x1_ASAP7_75t_R    g181(.A(new_n403), .B(new_n381), .C(new_n376), .D(new_n372), .E(new_n387), .Y(new_n404));
  NOR2x1_ASAP7_75t_R   g182(.A(pi123), .B(new_n245), .Y(new_n405));
  AO22x1_ASAP7_75t_R   g183(.A1(new_n270), .A2(pi125), .B1(pi124), .B2(new_n268), .Y(new_n406));
  AOI221x1_ASAP7_75t_R g184(.A1(pi126), .A2(new_n272), .B1(new_n274), .B2(pi127), .C(new_n406), .Y(new_n407));
  AO21x1_ASAP7_75t_R   g185(.A1(new_n407), .A2(new_n245), .B(new_n405), .Y(new_n408));
  XNOR2x2_ASAP7_75t_R  g186(.A(pi021), .B(new_n408), .Y(new_n409));
  NOR2x1_ASAP7_75t_R   g187(.A(pi129), .B(new_n245), .Y(new_n410));
  AO21x1_ASAP7_75t_R   g188(.A1(po06), .A2(new_n245), .B(new_n410), .Y(new_n411));
  XNOR2x2_ASAP7_75t_R  g189(.A(pi023), .B(new_n411), .Y(new_n412));
  NOR2x1_ASAP7_75t_R   g190(.A(pi112), .B(new_n245), .Y(new_n413));
  AO21x1_ASAP7_75t_R   g191(.A1(po27), .A2(new_n245), .B(new_n413), .Y(new_n414));
  XNOR2x2_ASAP7_75t_R  g192(.A(pi024), .B(new_n414), .Y(new_n415));
  NOR2x1_ASAP7_75t_R   g193(.A(pi131), .B(po37), .Y(new_n416));
  AO21x1_ASAP7_75t_R   g194(.A1(pi131), .A2(new_n254), .B(new_n416), .Y(new_n417));
  AO22x1_ASAP7_75t_R   g195(.A1(new_n417), .A2(pi106), .B1(new_n244), .B2(new_n375), .Y(new_n418));
  NOR2x1_ASAP7_75t_R   g196(.A(pi131), .B(po41), .Y(new_n419));
  AO21x1_ASAP7_75t_R   g197(.A1(pi131), .A2(new_n249), .B(new_n419), .Y(new_n420));
  XNOR2x2_ASAP7_75t_R  g198(.A(pi100), .B(new_n420), .Y(new_n421));
  NAND2x1_ASAP7_75t_R  g199(.A(pi131), .B(pi132), .Y(new_n422));
  OA21x2_ASAP7_75t_R   g200(.A1(new_n320), .A2(pi131), .B(new_n422), .Y(new_n423));
  NOR2x1_ASAP7_75t_R   g201(.A(pi104), .B(new_n423), .Y(new_n424));
  OA21x2_ASAP7_75t_R   g202(.A1(new_n245), .A2(pi110), .B(pi109), .Y(new_n425));
  OAI21x1_ASAP7_75t_R  g203(.A1(pi111), .A2(new_n338), .B(new_n425), .Y(new_n426));
  NOR2x1_ASAP7_75t_R   g204(.A(pi131), .B(po40), .Y(new_n427));
  AO21x1_ASAP7_75t_R   g205(.A1(pi131), .A2(new_n248), .B(new_n427), .Y(new_n428));
  AO22x1_ASAP7_75t_R   g206(.A1(new_n428), .A2(pi099), .B1(pi104), .B2(new_n423), .Y(new_n429));
  OR5x1_ASAP7_75t_R    g207(.A(new_n421), .B(new_n418), .C(new_n426), .D(new_n424), .E(new_n429), .Y(new_n430));
  OAI22x1_ASAP7_75t_R  g208(.A1(pi088), .A2(new_n402), .B1(new_n393), .B2(pi101), .Y(new_n431));
  OAI22x1_ASAP7_75t_R  g209(.A1(pi099), .A2(new_n428), .B1(new_n417), .B2(pi106), .Y(new_n432));
  NOR2x1_ASAP7_75t_R   g210(.A(pi022), .B(new_n383), .Y(new_n433));
  AO21x1_ASAP7_75t_R   g211(.A1(pi103), .A2(new_n385), .B(new_n433), .Y(new_n434));
  AO221x2_ASAP7_75t_R  g212(.A1(pi089), .A2(new_n378), .B1(new_n380), .B2(pi105), .C(new_n434), .Y(new_n435));
  OR4x2_ASAP7_75t_R    g213(.A(new_n430), .B(new_n431), .C(new_n432), .D(new_n435), .Y(new_n436));
  OR5x1_ASAP7_75t_R    g214(.A(new_n436), .B(new_n412), .C(new_n409), .D(new_n404), .E(new_n415), .Y(po53));
  AO21x1_ASAP7_75t_R   g215(.A1(new_n329), .A2(pi079), .B(pi050), .Y(new_n438));
  NAND2x1_ASAP7_75t_R  g216(.A(po32), .B(new_n438), .Y(new_n439));
  AOI22x1_ASAP7_75t_R  g217(.A1(pi145), .A2(new_n291), .B1(new_n292), .B2(pi146), .Y(new_n440));
  AOI22x1_ASAP7_75t_R  g218(.A1(pi148), .A2(new_n295), .B1(new_n294), .B2(pi147), .Y(new_n441));
  AOI22x1_ASAP7_75t_R  g219(.A1(new_n441), .A2(new_n440), .B1(new_n307), .B2(new_n306), .Y(new_n442));
  AND4x2_ASAP7_75t_R   g220(.A(new_n307), .B(new_n441), .C(new_n440), .D(new_n306), .Y(new_n443));
  OR2x4_ASAP7_75t_R    g221(.A(new_n442), .B(new_n443), .Y(new_n444));
  XOR2x2_ASAP7_75t_R   g222(.A(new_n439), .B(new_n444), .Y(po55));
  XOR2x2_ASAP7_75t_R   g223(.A(po06), .B(new_n283), .Y(new_n446));
  XNOR2x2_ASAP7_75t_R  g224(.A(new_n338), .B(new_n446), .Y(new_n447));
  AO22x1_ASAP7_75t_R   g225(.A1(new_n270), .A2(pi150), .B1(pi149), .B2(new_n268), .Y(new_n448));
  AO221x2_ASAP7_75t_R  g226(.A1(pi151), .A2(new_n272), .B1(new_n274), .B2(pi152), .C(new_n448), .Y(new_n449));
  XNOR2x2_ASAP7_75t_R  g227(.A(new_n396), .B(new_n449), .Y(new_n450));
  AO211x2_ASAP7_75t_R  g228(.A1(new_n388), .A2(new_n390), .B(new_n286), .C(new_n289), .Y(new_n451));
  AO211x2_ASAP7_75t_R  g229(.A1(new_n288), .A2(new_n285), .B(new_n389), .C(new_n391), .Y(new_n452));
  AND3x1_ASAP7_75t_R   g230(.A(new_n407), .B(new_n451), .C(new_n452), .Y(new_n453));
  AOI21x1_ASAP7_75t_R  g231(.A1(new_n451), .A2(new_n452), .B(new_n407), .Y(new_n454));
  OR2x4_ASAP7_75t_R    g232(.A(new_n454), .B(new_n453), .Y(new_n455));
  XOR2x2_ASAP7_75t_R   g233(.A(new_n455), .B(new_n369), .Y(new_n456));
  XOR2x2_ASAP7_75t_R   g234(.A(new_n456), .B(new_n450), .Y(new_n457));
  OR2x4_ASAP7_75t_R    g235(.A(new_n447), .B(new_n457), .Y(new_n458));
  AOI21x1_ASAP7_75t_R  g236(.A1(new_n447), .A2(new_n457), .B(pi153), .Y(new_n459));
  NAND2x1_ASAP7_75t_R  g237(.A(new_n459), .B(new_n458), .Y(po56));
  XOR2x2_ASAP7_75t_R   g238(.A(po38), .B(po40), .Y(new_n461));
  XNOR2x2_ASAP7_75t_R  g239(.A(po39), .B(po41), .Y(new_n462));
  XOR2x2_ASAP7_75t_R   g240(.A(new_n462), .B(new_n461), .Y(new_n463));
  INVx1_ASAP7_75t_R    g241(.A(new_n463), .Y(new_n464));
  OAI21x1_ASAP7_75t_R  g242(.A1(new_n442), .A2(new_n443), .B(new_n316), .Y(new_n465));
  AO211x2_ASAP7_75t_R  g243(.A1(new_n314), .A2(new_n315), .B(new_n442), .C(new_n443), .Y(new_n466));
  AO21x1_ASAP7_75t_R   g244(.A1(new_n466), .A2(new_n465), .B(new_n334), .Y(new_n467));
  AOI21x1_ASAP7_75t_R  g245(.A1(new_n465), .A2(new_n466), .B(new_n329), .Y(new_n468));
  AND3x1_ASAP7_75t_R   g246(.A(new_n466), .B(new_n465), .C(new_n329), .Y(new_n469));
  OAI21x1_ASAP7_75t_R  g247(.A1(new_n468), .A2(new_n469), .B(new_n334), .Y(new_n470));
  AND2x2_ASAP7_75t_R   g248(.A(new_n470), .B(new_n467), .Y(new_n471));
  XOR2x2_ASAP7_75t_R   g249(.A(new_n471), .B(new_n463), .Y(new_n472));
  AND3x1_ASAP7_75t_R   g250(.A(new_n441), .B(new_n440), .C(new_n240), .Y(new_n473));
  AOI21x1_ASAP7_75t_R  g251(.A1(pi078), .A2(new_n472), .B(new_n473), .Y(po57));
  OA21x2_ASAP7_75t_R   g252(.A1(new_n469), .A2(new_n468), .B(po30), .Y(new_n475));
  AOI211x1_ASAP7_75t_R g253(.A1(new_n299), .A2(new_n300), .B(new_n469), .C(new_n468), .Y(new_n476));
  OR3x1_ASAP7_75t_R    g254(.A(new_n476), .B(new_n475), .C(po36), .Y(new_n477));
  OAI21x1_ASAP7_75t_R  g255(.A1(new_n475), .A2(new_n476), .B(po36), .Y(new_n478));
  AND2x2_ASAP7_75t_R   g256(.A(new_n477), .B(new_n478), .Y(new_n479));
  NAND2x1_ASAP7_75t_R  g257(.A(new_n464), .B(new_n479), .Y(new_n480));
  OA21x2_ASAP7_75t_R   g258(.A1(new_n479), .A2(new_n464), .B(new_n255), .Y(new_n481));
  NAND2x1_ASAP7_75t_R  g259(.A(new_n481), .B(new_n480), .Y(po59));
  AOI21x1_ASAP7_75t_R  g260(.A1(new_n288), .A2(new_n285), .B(pi155), .Y(new_n483));
  AND5x1_ASAP7_75t_R   g261(.A(new_n269), .B(new_n275), .C(new_n273), .D(new_n271), .E(pi154), .Y(new_n484));
  AND2x2_ASAP7_75t_R   g262(.A(new_n484), .B(new_n483), .Y(new_n485));
  NAND2x1_ASAP7_75t_R  g263(.A(new_n483), .B(new_n484), .Y(new_n486));
  AND3x1_ASAP7_75t_R   g264(.A(new_n484), .B(new_n483), .C(pi022), .Y(new_n487));
  AOI21x1_ASAP7_75t_R  g265(.A1(pi105), .A2(new_n486), .B(new_n487), .Y(new_n488));
  OR2x4_ASAP7_75t_R    g266(.A(po36), .B(new_n488), .Y(new_n489));
  AND2x2_ASAP7_75t_R   g267(.A(new_n486), .B(pi108), .Y(new_n490));
  AND3x1_ASAP7_75t_R   g268(.A(new_n484), .B(new_n483), .C(pi021), .Y(new_n491));
  OR3x1_ASAP7_75t_R    g269(.A(new_n490), .B(new_n491), .C(new_n316), .Y(new_n492));
  OA21x2_ASAP7_75t_R   g270(.A1(new_n490), .A2(new_n491), .B(new_n316), .Y(new_n493));
  AND3x1_ASAP7_75t_R   g271(.A(new_n484), .B(new_n483), .C(pi102), .Y(new_n494));
  AO211x2_ASAP7_75t_R  g272(.A1(pi088), .A2(new_n486), .B(new_n308), .C(new_n494), .Y(new_n495));
  AND3x1_ASAP7_75t_R   g273(.A(new_n484), .B(new_n483), .C(pi098), .Y(new_n496));
  AO21x1_ASAP7_75t_R   g274(.A1(pi089), .A2(new_n486), .B(new_n496), .Y(new_n497));
  MAJx2_ASAP7_75t_R    g275(.A(new_n495), .B(new_n328), .C(new_n497), .Y(new_n498));
  OAI21x1_ASAP7_75t_R  g276(.A1(new_n493), .A2(new_n498), .B(new_n492), .Y(new_n499));
  AND3x1_ASAP7_75t_R   g277(.A(new_n484), .B(new_n483), .C(pi023), .Y(new_n500));
  AOI21x1_ASAP7_75t_R  g278(.A1(pi106), .A2(new_n486), .B(new_n500), .Y(new_n501));
  AO32x1_ASAP7_75t_R   g279(.A1(pi156), .A2(new_n501), .A3(po37), .B1(po36), .B2(new_n488), .Y(new_n502));
  AO21x1_ASAP7_75t_R   g280(.A1(new_n499), .A2(new_n489), .B(new_n502), .Y(new_n503));
  OR3x1_ASAP7_75t_R    g281(.A(new_n501), .B(po37), .C(new_n256), .Y(new_n504));
  AND3x1_ASAP7_75t_R   g282(.A(new_n484), .B(new_n483), .C(pi024), .Y(new_n505));
  AOI21x1_ASAP7_75t_R  g283(.A1(pi103), .A2(new_n486), .B(new_n505), .Y(new_n506));
  AND3x1_ASAP7_75t_R   g284(.A(new_n506), .B(po38), .C(pi156), .Y(new_n507));
  AOI21x1_ASAP7_75t_R  g285(.A1(new_n504), .A2(new_n503), .B(new_n507), .Y(new_n508));
  AND3x1_ASAP7_75t_R   g286(.A(new_n486), .B(pi104), .C(pi099), .Y(new_n509));
  AND2x2_ASAP7_75t_R   g287(.A(po40), .B(po39), .Y(new_n510));
  AO21x1_ASAP7_75t_R   g288(.A1(new_n510), .A2(new_n485), .B(new_n256), .Y(new_n511));
  OR3x1_ASAP7_75t_R    g289(.A(new_n506), .B(po38), .C(new_n256), .Y(new_n512));
  OAI21x1_ASAP7_75t_R  g290(.A1(new_n509), .A2(new_n511), .B(new_n512), .Y(new_n513));
  AO21x1_ASAP7_75t_R   g291(.A1(pi099), .A2(pi104), .B(new_n256), .Y(new_n514));
  OAI22x1_ASAP7_75t_R  g292(.A1(new_n485), .A2(new_n514), .B1(new_n508), .B2(new_n513), .Y(new_n515));
  OA21x2_ASAP7_75t_R   g293(.A1(po28), .A2(pi155), .B(new_n484), .Y(new_n516));
  INVx1_ASAP7_75t_R    g294(.A(new_n516), .Y(new_n517));
  OA211x2_ASAP7_75t_R  g295(.A1(new_n389), .A2(new_n391), .B(new_n516), .C(pi101), .Y(new_n518));
  AND4x2_ASAP7_75t_R   g296(.A(new_n516), .B(new_n390), .C(new_n388), .D(new_n243), .Y(new_n519));
  AND3x1_ASAP7_75t_R   g297(.A(new_n516), .B(new_n397), .C(pi098), .Y(new_n520));
  AND3x1_ASAP7_75t_R   g298(.A(new_n516), .B(new_n396), .C(new_n242), .Y(new_n521));
  OR4x2_ASAP7_75t_R    g299(.A(new_n519), .B(new_n520), .C(new_n521), .D(new_n518), .Y(new_n522));
  NOR3x1_ASAP7_75t_R   g300(.A(new_n517), .B(new_n369), .C(pi102), .Y(new_n523));
  AND2x2_ASAP7_75t_R   g301(.A(new_n369), .B(pi102), .Y(new_n524));
  INVx1_ASAP7_75t_R    g302(.A(new_n524), .Y(new_n525));
  AO21x1_ASAP7_75t_R   g303(.A1(new_n516), .A2(new_n524), .B(new_n523), .Y(new_n526));
  XOR2x2_ASAP7_75t_R   g304(.A(po41), .B(pi100), .Y(new_n527));
  AOI211x1_ASAP7_75t_R g305(.A1(new_n516), .A2(new_n527), .B(new_n526), .C(new_n522), .Y(new_n528));
  OR5x1_ASAP7_75t_R    g306(.A(new_n523), .B(new_n524), .C(pi100), .D(new_n325), .E(new_n517), .Y(new_n529));
  NOR2x1_ASAP7_75t_R   g307(.A(new_n522), .B(new_n529), .Y(new_n530));
  AOI21x1_ASAP7_75t_R  g308(.A1(new_n519), .A2(new_n525), .B(new_n523), .Y(new_n531));
  NOR2x1_ASAP7_75t_R   g309(.A(new_n520), .B(new_n531), .Y(new_n532));
  OR3x1_ASAP7_75t_R    g310(.A(new_n530), .B(new_n532), .C(new_n521), .Y(new_n533));
  AOI21x1_ASAP7_75t_R  g311(.A1(new_n528), .A2(new_n515), .B(new_n533), .Y(po60));
  OR4x2_ASAP7_75t_R    g312(.A(new_n350), .B(po51), .C(po52), .D(po05), .Y(new_n535));
  AO221x2_ASAP7_75t_R  g313(.A1(new_n459), .A2(new_n458), .B1(new_n481), .B2(new_n480), .C(new_n535), .Y(po62));
  assign               po61 = 1'b0;
  NAND2x1_ASAP7_75t_R  g314(.A(new_n262), .B(new_n264), .Y(po04));
  INVx1_ASAP7_75t_R    g315(.A(pi018), .Y(po08));
  INVx1_ASAP7_75t_R    g316(.A(pi018), .Y(po09));
  INVx1_ASAP7_75t_R    g317(.A(pi019), .Y(po11));
  INVx1_ASAP7_75t_R    g318(.A(pi020), .Y(po13));
  INVx1_ASAP7_75t_R    g319(.A(pi020), .Y(po14));
  BUFx2_ASAP7_75t_R    g320(.A(pi018), .Y(po25));
  AO21x1_ASAP7_75t_R   g321(.A1(new_n240), .A2(new_n329), .B(new_n326), .Y(po43));
  AO21x1_ASAP7_75t_R   g322(.A1(pi078), .A2(po30), .B(new_n331), .Y(po45));
  OA21x2_ASAP7_75t_R   g323(.A1(pi078), .A2(new_n309), .B(new_n335), .Y(po48));
  OR5x1_ASAP7_75t_R    g324(.A(new_n436), .B(new_n412), .C(new_n409), .D(new_n404), .E(new_n415), .Y(po54));
  AOI21x1_ASAP7_75t_R  g325(.A1(pi078), .A2(new_n472), .B(new_n473), .Y(po58));
  AO221x2_ASAP7_75t_R  g326(.A1(new_n459), .A2(new_n458), .B1(new_n481), .B2(new_n480), .C(new_n535), .Y(po63));
endmodule


