// Benchmark "/w/experiments/inputs/c1/c2/c2670" written by ABC on Fri Sep 25 10:27:06 2026

module \/w/experiments/inputs/c1/c2/c2670  ( 
    pi000, pi001, pi002, pi003, pi004, pi005, pi006, pi007, pi008, pi009,
    pi010, pi011, pi012, pi013, pi014, pi015, pi016, pi017, pi018, pi019,
    pi020, pi021, pi022, pi023, pi024, pi025, pi026, pi027, pi028, pi029,
    pi030, pi031, pi032, pi033, pi034, pi035, pi036, pi037, pi038, pi039,
    pi040, pi041, pi042, pi043, pi044, pi045, pi046, pi047, pi048, pi049,
    pi050, pi051, pi052, pi053, pi054, pi055, pi056, pi057, pi058, pi059,
    pi060, pi061, pi062, pi063, pi064, pi065, pi066, pi067, pi068, pi069,
    pi070, pi071, pi072, pi073, pi074, pi075, pi076, pi077, pi078, pi079,
    pi080, pi081, pi082, pi083, pi084, pi085, pi086, pi087, pi088, pi089,
    pi090, pi091, pi092, pi093, pi094, pi095, pi096, pi097, pi098, pi099,
    pi100, pi101, pi102, pi103, pi104, pi105, pi106, pi107, pi108, pi109,
    pi110, pi111, pi112, pi113, pi114, pi115, pi116, pi117, pi118, pi119,
    pi120, pi121, pi122, pi123, pi124, pi125, pi126, pi127, pi128, pi129,
    pi130, pi131, pi132, pi133, pi134, pi135, pi136, pi137, pi138, pi139,
    pi140, pi141, pi142, pi143, pi144, pi145, pi146, pi147, pi148, pi149,
    pi150, pi151, pi152, pi153, pi154, pi155, pi156,
    po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10, po11,
    po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22, po23,
    po24, po25, po26, po27, po28, po29, po30, po31, po32, po33, po34, po35,
    po36, po37, po38, po39, po40, po41, po42, po43, po44, po45, po46, po47,
    po48, po49, po50, po51, po52, po53, po54, po55, po56, po57, po58, po59,
    po60, po61, po62, po63  );
  input  pi000, pi001, pi002, pi003, pi004, pi005, pi006, pi007, pi008,
    pi009, pi010, pi011, pi012, pi013, pi014, pi015, pi016, pi017, pi018,
    pi019, pi020, pi021, pi022, pi023, pi024, pi025, pi026, pi027, pi028,
    pi029, pi030, pi031, pi032, pi033, pi034, pi035, pi036, pi037, pi038,
    pi039, pi040, pi041, pi042, pi043, pi044, pi045, pi046, pi047, pi048,
    pi049, pi050, pi051, pi052, pi053, pi054, pi055, pi056, pi057, pi058,
    pi059, pi060, pi061, pi062, pi063, pi064, pi065, pi066, pi067, pi068,
    pi069, pi070, pi071, pi072, pi073, pi074, pi075, pi076, pi077, pi078,
    pi079, pi080, pi081, pi082, pi083, pi084, pi085, pi086, pi087, pi088,
    pi089, pi090, pi091, pi092, pi093, pi094, pi095, pi096, pi097, pi098,
    pi099, pi100, pi101, pi102, pi103, pi104, pi105, pi106, pi107, pi108,
    pi109, pi110, pi111, pi112, pi113, pi114, pi115, pi116, pi117, pi118,
    pi119, pi120, pi121, pi122, pi123, pi124, pi125, pi126, pi127, pi128,
    pi129, pi130, pi131, pi132, pi133, pi134, pi135, pi136, pi137, pi138,
    pi139, pi140, pi141, pi142, pi143, pi144, pi145, pi146, pi147, pi148,
    pi149, pi150, pi151, pi152, pi153, pi154, pi155, pi156;
  output po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10,
    po11, po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22,
    po23, po24, po25, po26, po27, po28, po29, po30, po31, po32, po33, po34,
    po35, po36, po37, po38, po39, po40, po41, po42, po43, po44, po45, po46,
    po47, po48, po49, po50, po51, po52, po53, po54, po55, po56, po57, po58,
    po59, po60, po61, po62, po63;
  wire new_n231, new_n232, new_n236, new_n237, new_n238, new_n239, new_n240,
    new_n241, new_n242, new_n243, new_n244, new_n245, new_n246, new_n247,
    new_n248, new_n249, new_n250, new_n251, new_n252, new_n254, new_n256,
    new_n258, new_n259, new_n260, new_n261, new_n264, new_n265, new_n266,
    new_n267, new_n268, new_n269, new_n270, new_n271, new_n272, new_n274,
    new_n276, new_n279, new_n280, new_n282, new_n283, new_n284, new_n285,
    new_n286, new_n288, new_n289, new_n290, new_n291, new_n292, new_n295,
    new_n298, new_n301, new_n302, new_n303, new_n305, new_n308, new_n309,
    new_n310, new_n311, new_n313, new_n315, new_n317, new_n319, new_n320,
    new_n321, new_n322, new_n323, new_n325, new_n328, new_n329, new_n331,
    new_n332, new_n333, new_n335, new_n336, new_n337, new_n338, new_n339,
    new_n340, new_n341, new_n342, new_n343, new_n344, new_n346, new_n347,
    new_n348, new_n349, new_n350, new_n351, new_n353, new_n354, new_n355,
    new_n356, new_n357, new_n358, new_n359, new_n360, new_n362, new_n363,
    new_n364, new_n365, new_n366, new_n367, new_n368, new_n369, new_n370,
    new_n371, new_n372, new_n373, new_n374, new_n375, new_n376, new_n377,
    new_n378, new_n379, new_n380, new_n381, new_n382, new_n383, new_n384,
    new_n385, new_n386, new_n387, new_n388, new_n389, new_n390, new_n391,
    new_n392, new_n393, new_n394, new_n395, new_n396, new_n397, new_n398,
    new_n399, new_n400, new_n401, new_n402, new_n403, new_n404, new_n405,
    new_n406, new_n407, new_n408, new_n409, new_n410, new_n411, new_n412,
    new_n413, new_n414, new_n415, new_n416, new_n417, new_n418, new_n419,
    new_n420, new_n421, new_n422, new_n423, new_n424, new_n425, new_n426,
    new_n427, new_n428, new_n429, new_n430, new_n431, new_n433, new_n434,
    new_n435, new_n436, new_n437, new_n438, new_n439, new_n441, new_n442,
    new_n443, new_n444, new_n445, new_n446, new_n447, new_n448, new_n449,
    new_n450, new_n451, new_n452, new_n453, new_n454, new_n455, new_n457,
    new_n458, new_n459, new_n460, new_n461, new_n462, new_n463, new_n464,
    new_n465, new_n466, new_n467, new_n468, new_n469, new_n471, new_n472,
    new_n473, new_n474, new_n475, new_n476, new_n478, new_n479, new_n480,
    new_n481, new_n482, new_n483, new_n484, new_n485, new_n486, new_n487,
    new_n488, new_n489, new_n490, new_n491, new_n492, new_n493, new_n494,
    new_n495, new_n496, new_n497, new_n498, new_n499, new_n500, new_n501,
    new_n502, new_n503, new_n504, new_n505, new_n506, new_n507, new_n508,
    new_n509, new_n510, new_n511, new_n512, new_n513, new_n514, new_n515,
    new_n516, new_n517, new_n518, new_n519, new_n520, new_n521, new_n522,
    new_n523, new_n524, new_n525, new_n526, new_n528, new_n529;
  INVx1_ASAP7_75t_R    g000(.A(pi004), .Y(po19));
  INVx1_ASAP7_75t_R    g001(.A(pi005), .Y(po22));
  INVx1_ASAP7_75t_R    g002(.A(pi006), .Y(po21));
  INVx1_ASAP7_75t_R    g003(.A(pi007), .Y(po20));
  INVx1_ASAP7_75t_R    g004(.A(pi008), .Y(po15));
  INVx1_ASAP7_75t_R    g005(.A(pi009), .Y(po18));
  INVx1_ASAP7_75t_R    g006(.A(pi010), .Y(po17));
  INVx1_ASAP7_75t_R    g007(.A(pi011), .Y(po16));
  INVx1_ASAP7_75t_R    g008(.A(pi012), .Y(new_n231));
  INVx1_ASAP7_75t_R    g009(.A(pi013), .Y(new_n232));
  INVx1_ASAP7_75t_R    g010(.A(pi018), .Y(po07));
  INVx1_ASAP7_75t_R    g011(.A(pi019), .Y(po10));
  INVx1_ASAP7_75t_R    g012(.A(pi020), .Y(po12));
  INVx1_ASAP7_75t_R    g013(.A(pi036), .Y(new_n236));
  INVx1_ASAP7_75t_R    g014(.A(pi050), .Y(new_n237));
  INVx1_ASAP7_75t_R    g015(.A(pi055), .Y(new_n238));
  INVx1_ASAP7_75t_R    g016(.A(pi056), .Y(new_n239));
  INVx1_ASAP7_75t_R    g017(.A(pi078), .Y(new_n240));
  INVx1_ASAP7_75t_R    g018(.A(pi088), .Y(new_n241));
  INVx1_ASAP7_75t_R    g019(.A(pi096), .Y(new_n242));
  INVx1_ASAP7_75t_R    g020(.A(pi099), .Y(new_n243));
  INVx1_ASAP7_75t_R    g021(.A(pi101), .Y(new_n244));
  INVx1_ASAP7_75t_R    g022(.A(pi102), .Y(new_n245));
  INVx1_ASAP7_75t_R    g023(.A(pi104), .Y(new_n246));
  INVx1_ASAP7_75t_R    g024(.A(pi111), .Y(new_n247));
  INVx1_ASAP7_75t_R    g025(.A(pi131), .Y(new_n248));
  INVx1_ASAP7_75t_R    g026(.A(pi133), .Y(new_n249));
  INVx1_ASAP7_75t_R    g027(.A(pi153), .Y(new_n250));
  INVx1_ASAP7_75t_R    g028(.A(pi154), .Y(new_n251));
  INVx1_ASAP7_75t_R    g029(.A(pi156), .Y(new_n252));
  NAND2x1_ASAP7_75t_R  g030(.A(pi000), .B(pi001), .Y(po00));
  AND3x1_ASAP7_75t_R   g031(.A(pi000), .B(pi001), .C(pi002), .Y(new_n254));
  INVx1_ASAP7_75t_R    g032(.A(new_n254), .Y(po01));
  AND3x1_ASAP7_75t_R   g033(.A(pi000), .B(pi001), .C(pi003), .Y(new_n256));
  INVx1_ASAP7_75t_R    g034(.A(new_n256), .Y(po02));
  AND4x2_ASAP7_75t_R   g035(.A(pi004), .B(pi005), .C(pi006), .D(pi007), .Y(new_n258));
  INVx1_ASAP7_75t_R    g036(.A(new_n258), .Y(new_n259));
  AND4x2_ASAP7_75t_R   g037(.A(pi008), .B(pi009), .C(pi010), .D(pi011), .Y(new_n260));
  INVx1_ASAP7_75t_R    g038(.A(new_n260), .Y(new_n261));
  NAND2x1_ASAP7_75t_R  g039(.A(new_n258), .B(new_n260), .Y(po03));
  AO22x1_ASAP7_75t_R   g040(.A1(new_n261), .A2(pi003), .B1(new_n259), .B2(pi002), .Y(po05));
  NOR2x1_ASAP7_75t_R   g041(.A(pi012), .B(pi013), .Y(new_n264));
  AND3x1_ASAP7_75t_R   g042(.A(new_n231), .B(new_n232), .C(pi014), .Y(new_n265));
  AND2x2_ASAP7_75t_R   g043(.A(new_n231), .B(pi013), .Y(new_n266));
  AND3x1_ASAP7_75t_R   g044(.A(new_n231), .B(pi013), .C(pi015), .Y(new_n267));
  AND2x2_ASAP7_75t_R   g045(.A(new_n232), .B(pi012), .Y(new_n268));
  AND3x1_ASAP7_75t_R   g046(.A(new_n232), .B(pi016), .C(pi012), .Y(new_n269));
  AND2x2_ASAP7_75t_R   g047(.A(pi012), .B(pi013), .Y(new_n270));
  AND3x1_ASAP7_75t_R   g048(.A(pi012), .B(pi013), .C(pi017), .Y(new_n271));
  OR4x2_ASAP7_75t_R    g049(.A(new_n265), .B(new_n267), .C(new_n269), .D(new_n271), .Y(new_n272));
  INVx1_ASAP7_75t_R    g050(.A(new_n272), .Y(po06));
  AND4x2_ASAP7_75t_R   g051(.A(pi021), .B(pi022), .C(pi023), .D(pi024), .Y(new_n274));
  INVx1_ASAP7_75t_R    g052(.A(new_n274), .Y(po23));
  AND3x1_ASAP7_75t_R   g053(.A(pi001), .B(pi025), .C(pi026), .Y(new_n276));
  INVx1_ASAP7_75t_R    g054(.A(new_n276), .Y(po24));
  AND2x2_ASAP7_75t_R   g055(.A(po07), .B(pi027), .Y(po26));
  AO22x1_ASAP7_75t_R   g056(.A1(new_n266), .A2(pi029), .B1(pi028), .B2(new_n264), .Y(new_n279));
  AO221x2_ASAP7_75t_R  g057(.A1(pi030), .A2(new_n268), .B1(new_n270), .B2(pi031), .C(new_n279), .Y(new_n280));
  INVx1_ASAP7_75t_R    g058(.A(new_n280), .Y(po27));
  AOI22x1_ASAP7_75t_R  g059(.A1(pi032), .A2(new_n264), .B1(new_n266), .B2(pi033), .Y(new_n282));
  AO22x1_ASAP7_75t_R   g060(.A1(new_n266), .A2(pi033), .B1(pi032), .B2(new_n264), .Y(new_n283));
  AOI22x1_ASAP7_75t_R  g061(.A1(pi035), .A2(new_n270), .B1(new_n268), .B2(pi034), .Y(new_n284));
  AO22x1_ASAP7_75t_R   g062(.A1(new_n268), .A2(pi034), .B1(pi035), .B2(new_n270), .Y(new_n285));
  NAND2x1_ASAP7_75t_R  g063(.A(new_n282), .B(new_n284), .Y(new_n286));
  INVx1_ASAP7_75t_R    g064(.A(new_n286), .Y(po28));
  NOR2x1_ASAP7_75t_R   g065(.A(pi036), .B(pi037), .Y(new_n288));
  AND2x2_ASAP7_75t_R   g066(.A(new_n236), .B(pi037), .Y(new_n289));
  AO22x1_ASAP7_75t_R   g067(.A1(new_n289), .A2(pi039), .B1(pi038), .B2(new_n288), .Y(new_n290));
  NOR2x1_ASAP7_75t_R   g068(.A(pi037), .B(new_n236), .Y(new_n291));
  AND2x2_ASAP7_75t_R   g069(.A(pi036), .B(pi037), .Y(new_n292));
  AO221x2_ASAP7_75t_R  g070(.A1(pi040), .A2(new_n291), .B1(new_n292), .B2(pi041), .C(new_n290), .Y(po38));
  INVx1_ASAP7_75t_R    g071(.A(po38), .Y(po29));
  AO22x1_ASAP7_75t_R   g072(.A1(new_n289), .A2(pi043), .B1(pi042), .B2(new_n288), .Y(new_n295));
  AO221x2_ASAP7_75t_R  g073(.A1(pi044), .A2(new_n291), .B1(new_n292), .B2(pi045), .C(new_n295), .Y(po37));
  INVx1_ASAP7_75t_R    g074(.A(po37), .Y(po30));
  AO22x1_ASAP7_75t_R   g075(.A1(new_n289), .A2(pi047), .B1(pi046), .B2(new_n288), .Y(new_n298));
  AO221x2_ASAP7_75t_R  g076(.A1(pi048), .A2(new_n291), .B1(new_n292), .B2(pi049), .C(new_n298), .Y(po36));
  INVx1_ASAP7_75t_R    g077(.A(po36), .Y(po31));
  AOI22x1_ASAP7_75t_R  g078(.A1(pi051), .A2(new_n288), .B1(new_n289), .B2(pi052), .Y(new_n301));
  AOI22x1_ASAP7_75t_R  g079(.A1(pi054), .A2(new_n292), .B1(new_n291), .B2(pi053), .Y(new_n302));
  AND2x2_ASAP7_75t_R   g080(.A(new_n302), .B(new_n301), .Y(new_n303));
  NAND2x1_ASAP7_75t_R  g081(.A(pi050), .B(new_n303), .Y(po32));
  OR3x1_ASAP7_75t_R    g082(.A(po05), .B(new_n239), .C(pi001), .Y(new_n305));
  OR4x2_ASAP7_75t_R    g083(.A(po05), .B(new_n239), .C(new_n238), .D(pi001), .Y(po33));
  AO21x1_ASAP7_75t_R   g084(.A1(pi057), .A2(pi058), .B(new_n305), .Y(po34));
  AO22x1_ASAP7_75t_R   g085(.A1(new_n289), .A2(pi060), .B1(pi059), .B2(new_n288), .Y(new_n308));
  INVx1_ASAP7_75t_R    g086(.A(new_n308), .Y(new_n309));
  AOI22x1_ASAP7_75t_R  g087(.A1(pi062), .A2(new_n292), .B1(new_n291), .B2(pi061), .Y(new_n310));
  AOI221x1_ASAP7_75t_R g088(.A1(pi061), .A2(new_n291), .B1(new_n292), .B2(pi062), .C(new_n308), .Y(new_n311));
  INVx1_ASAP7_75t_R    g089(.A(new_n311), .Y(po35));
  AO21x1_ASAP7_75t_R   g090(.A1(pi063), .A2(new_n288), .B(new_n289), .Y(new_n313));
  AO221x2_ASAP7_75t_R  g091(.A1(pi064), .A2(new_n291), .B1(new_n292), .B2(pi065), .C(new_n313), .Y(po39));
  AO22x1_ASAP7_75t_R   g092(.A1(new_n289), .A2(pi067), .B1(pi066), .B2(new_n288), .Y(new_n315));
  AO221x2_ASAP7_75t_R  g093(.A1(pi068), .A2(new_n291), .B1(new_n292), .B2(pi069), .C(new_n315), .Y(po40));
  AO22x1_ASAP7_75t_R   g094(.A1(new_n289), .A2(pi071), .B1(pi070), .B2(new_n288), .Y(new_n317));
  AO221x2_ASAP7_75t_R  g095(.A1(pi072), .A2(new_n291), .B1(new_n292), .B2(pi073), .C(new_n317), .Y(po41));
  INVx1_ASAP7_75t_R    g096(.A(po41), .Y(new_n319));
  AND2x2_ASAP7_75t_R   g097(.A(po36), .B(pi078), .Y(new_n320));
  AO22x1_ASAP7_75t_R   g098(.A1(new_n289), .A2(pi075), .B1(pi074), .B2(new_n288), .Y(new_n321));
  AOI221x1_ASAP7_75t_R g099(.A1(pi076), .A2(new_n291), .B1(new_n292), .B2(pi077), .C(new_n321), .Y(new_n322));
  AO221x2_ASAP7_75t_R  g100(.A1(pi076), .A2(new_n291), .B1(new_n292), .B2(pi077), .C(new_n321), .Y(new_n323));
  AO21x1_ASAP7_75t_R   g101(.A1(new_n240), .A2(new_n322), .B(new_n320), .Y(po42));
  NOR2x1_ASAP7_75t_R   g102(.A(new_n240), .B(po37), .Y(new_n325));
  AO21x1_ASAP7_75t_R   g103(.A1(new_n240), .A2(po35), .B(new_n325), .Y(po44));
  AO21x1_ASAP7_75t_R   g104(.A1(new_n237), .A2(pi079), .B(new_n323), .Y(po46));
  OR2x4_ASAP7_75t_R    g105(.A(pi079), .B(new_n323), .Y(new_n328));
  NAND2x1_ASAP7_75t_R  g106(.A(pi078), .B(new_n328), .Y(new_n329));
  OA21x2_ASAP7_75t_R   g107(.A1(pi078), .A2(new_n303), .B(new_n329), .Y(po47));
  AO22x1_ASAP7_75t_R   g108(.A1(new_n266), .A2(pi083), .B1(pi082), .B2(new_n264), .Y(new_n331));
  AO221x2_ASAP7_75t_R  g109(.A1(pi084), .A2(new_n268), .B1(new_n270), .B2(pi085), .C(new_n331), .Y(new_n332));
  AOI21x1_ASAP7_75t_R  g110(.A1(pi081), .A2(new_n332), .B(pi080), .Y(new_n333));
  OAI21x1_ASAP7_75t_R  g111(.A1(pi081), .A2(new_n332), .B(new_n333), .Y(po49));
  XNOR2x2_ASAP7_75t_R  g112(.A(pi088), .B(pi089), .Y(new_n335));
  XNOR2x2_ASAP7_75t_R  g113(.A(pi090), .B(pi091), .Y(new_n336));
  XOR2x2_ASAP7_75t_R   g114(.A(new_n336), .B(pi094), .Y(new_n337));
  XOR2x2_ASAP7_75t_R   g115(.A(pi086), .B(pi087), .Y(new_n338));
  XOR2x2_ASAP7_75t_R   g116(.A(pi092), .B(pi093), .Y(new_n339));
  XOR2x2_ASAP7_75t_R   g117(.A(new_n339), .B(pi095), .Y(new_n340));
  XOR2x2_ASAP7_75t_R   g118(.A(new_n340), .B(new_n338), .Y(new_n341));
  XOR2x2_ASAP7_75t_R   g119(.A(new_n341), .B(new_n337), .Y(new_n342));
  AOI21x1_ASAP7_75t_R  g120(.A1(new_n335), .A2(new_n342), .B(new_n242), .Y(new_n343));
  OA21x2_ASAP7_75t_R   g121(.A1(new_n335), .A2(new_n342), .B(new_n343), .Y(new_n344));
  INVx1_ASAP7_75t_R    g122(.A(new_n344), .Y(po50));
  XOR2x2_ASAP7_75t_R   g123(.A(pi097), .B(pi098), .Y(new_n346));
  XOR2x2_ASAP7_75t_R   g124(.A(pi023), .B(pi024), .Y(new_n347));
  XOR2x2_ASAP7_75t_R   g125(.A(pi021), .B(pi022), .Y(new_n348));
  XOR2x2_ASAP7_75t_R   g126(.A(new_n347), .B(new_n348), .Y(new_n349));
  XNOR2x2_ASAP7_75t_R  g127(.A(pi080), .B(pi081), .Y(new_n350));
  XOR2x2_ASAP7_75t_R   g128(.A(new_n349), .B(new_n350), .Y(new_n351));
  XOR2x2_ASAP7_75t_R   g129(.A(new_n351), .B(new_n346), .Y(po51));
  XOR2x2_ASAP7_75t_R   g130(.A(pi099), .B(pi100), .Y(new_n353));
  XOR2x2_ASAP7_75t_R   g131(.A(pi107), .B(pi108), .Y(new_n354));
  XOR2x2_ASAP7_75t_R   g132(.A(new_n353), .B(new_n354), .Y(new_n355));
  XOR2x2_ASAP7_75t_R   g133(.A(pi105), .B(pi106), .Y(new_n356));
  XOR2x2_ASAP7_75t_R   g134(.A(pi103), .B(pi104), .Y(new_n357));
  XOR2x2_ASAP7_75t_R   g135(.A(new_n356), .B(new_n357), .Y(new_n358));
  XNOR2x2_ASAP7_75t_R  g136(.A(pi101), .B(pi102), .Y(new_n359));
  XOR2x2_ASAP7_75t_R   g137(.A(new_n358), .B(new_n359), .Y(new_n360));
  XOR2x2_ASAP7_75t_R   g138(.A(new_n360), .B(new_n355), .Y(po52));
  NOR2x1_ASAP7_75t_R   g139(.A(pi113), .B(new_n247), .Y(new_n362));
  AO22x1_ASAP7_75t_R   g140(.A1(new_n266), .A2(pi115), .B1(pi114), .B2(new_n264), .Y(new_n363));
  AO221x2_ASAP7_75t_R  g141(.A1(pi116), .A2(new_n268), .B1(new_n270), .B2(pi117), .C(new_n363), .Y(new_n364));
  INVx1_ASAP7_75t_R    g142(.A(new_n364), .Y(new_n365));
  AO21x1_ASAP7_75t_R   g143(.A1(new_n365), .A2(new_n247), .B(new_n362), .Y(new_n366));
  NOR2x1_ASAP7_75t_R   g144(.A(pi102), .B(new_n366), .Y(new_n367));
  NOR2x1_ASAP7_75t_R   g145(.A(pi142), .B(new_n248), .Y(new_n368));
  AO21x1_ASAP7_75t_R   g146(.A1(new_n311), .A2(new_n248), .B(new_n368), .Y(new_n369));
  AO22x1_ASAP7_75t_R   g147(.A1(new_n366), .A2(pi102), .B1(pi108), .B2(new_n369), .Y(new_n370));
  NOR2x1_ASAP7_75t_R   g148(.A(pi141), .B(new_n248), .Y(new_n371));
  AO21x1_ASAP7_75t_R   g149(.A1(new_n322), .A2(new_n248), .B(new_n371), .Y(new_n372));
  NOR2x1_ASAP7_75t_R   g150(.A(pi143), .B(new_n248), .Y(new_n373));
  AO21x1_ASAP7_75t_R   g151(.A1(po31), .A2(new_n248), .B(new_n373), .Y(new_n374));
  OAI22x1_ASAP7_75t_R  g152(.A1(pi089), .A2(new_n372), .B1(new_n374), .B2(pi105), .Y(new_n375));
  OR3x1_ASAP7_75t_R    g153(.A(new_n283), .B(new_n285), .C(pi111), .Y(new_n376));
  OAI21x1_ASAP7_75t_R  g154(.A1(new_n247), .A2(pi128), .B(new_n376), .Y(new_n377));
  NOR2x1_ASAP7_75t_R   g155(.A(pi130), .B(new_n248), .Y(new_n378));
  AO21x1_ASAP7_75t_R   g156(.A1(po29), .A2(new_n248), .B(new_n378), .Y(new_n379));
  NOR2x1_ASAP7_75t_R   g157(.A(pi103), .B(new_n379), .Y(new_n380));
  AO21x1_ASAP7_75t_R   g158(.A1(pi022), .A2(new_n377), .B(new_n380), .Y(new_n381));
  AOI22x1_ASAP7_75t_R  g159(.A1(pi136), .A2(new_n264), .B1(new_n266), .B2(pi137), .Y(new_n382));
  AO22x1_ASAP7_75t_R   g160(.A1(new_n266), .A2(pi137), .B1(pi136), .B2(new_n264), .Y(new_n383));
  AOI22x1_ASAP7_75t_R  g161(.A1(pi139), .A2(new_n270), .B1(new_n268), .B2(pi138), .Y(new_n384));
  AO22x1_ASAP7_75t_R   g162(.A1(new_n268), .A2(pi138), .B1(pi139), .B2(new_n270), .Y(new_n385));
  OR3x1_ASAP7_75t_R    g163(.A(new_n383), .B(new_n385), .C(pi111), .Y(new_n386));
  OAI21x1_ASAP7_75t_R  g164(.A1(new_n247), .A2(pi135), .B(new_n386), .Y(new_n387));
  NOR2x1_ASAP7_75t_R   g165(.A(pi118), .B(new_n247), .Y(new_n388));
  AO22x1_ASAP7_75t_R   g166(.A1(new_n266), .A2(pi120), .B1(pi119), .B2(new_n264), .Y(new_n389));
  AO221x2_ASAP7_75t_R  g167(.A1(pi121), .A2(new_n268), .B1(new_n270), .B2(pi122), .C(new_n389), .Y(new_n390));
  INVx1_ASAP7_75t_R    g168(.A(new_n390), .Y(new_n391));
  AO21x1_ASAP7_75t_R   g169(.A1(new_n391), .A2(new_n247), .B(new_n388), .Y(new_n392));
  NOR2x1_ASAP7_75t_R   g170(.A(pi098), .B(new_n392), .Y(new_n393));
  AO21x1_ASAP7_75t_R   g171(.A1(pi101), .A2(new_n387), .B(new_n393), .Y(new_n394));
  NOR2x1_ASAP7_75t_R   g172(.A(pi140), .B(new_n248), .Y(new_n395));
  AO21x1_ASAP7_75t_R   g173(.A1(new_n303), .A2(new_n248), .B(new_n395), .Y(new_n396));
  AO221x2_ASAP7_75t_R  g174(.A1(pi098), .A2(new_n392), .B1(new_n396), .B2(pi088), .C(new_n394), .Y(new_n397));
  OR5x1_ASAP7_75t_R    g175(.A(new_n397), .B(new_n375), .C(new_n370), .D(new_n367), .E(new_n381), .Y(new_n398));
  NOR2x1_ASAP7_75t_R   g176(.A(pi123), .B(new_n247), .Y(new_n399));
  AO22x1_ASAP7_75t_R   g177(.A1(new_n266), .A2(pi125), .B1(pi124), .B2(new_n264), .Y(new_n400));
  AOI221x1_ASAP7_75t_R g178(.A1(pi126), .A2(new_n268), .B1(new_n270), .B2(pi127), .C(new_n400), .Y(new_n401));
  AO21x1_ASAP7_75t_R   g179(.A1(new_n401), .A2(new_n247), .B(new_n399), .Y(new_n402));
  XNOR2x2_ASAP7_75t_R  g180(.A(pi021), .B(new_n402), .Y(new_n403));
  NOR2x1_ASAP7_75t_R   g181(.A(pi129), .B(new_n247), .Y(new_n404));
  AO21x1_ASAP7_75t_R   g182(.A1(po06), .A2(new_n247), .B(new_n404), .Y(new_n405));
  XNOR2x2_ASAP7_75t_R  g183(.A(pi023), .B(new_n405), .Y(new_n406));
  NOR2x1_ASAP7_75t_R   g184(.A(pi112), .B(new_n247), .Y(new_n407));
  AO21x1_ASAP7_75t_R   g185(.A1(po27), .A2(new_n247), .B(new_n407), .Y(new_n408));
  XNOR2x2_ASAP7_75t_R  g186(.A(pi024), .B(new_n408), .Y(new_n409));
  NOR2x1_ASAP7_75t_R   g187(.A(pi108), .B(new_n369), .Y(new_n410));
  NOR2x1_ASAP7_75t_R   g188(.A(pi144), .B(new_n248), .Y(new_n411));
  AO21x1_ASAP7_75t_R   g189(.A1(po30), .A2(new_n248), .B(new_n411), .Y(new_n412));
  AO21x1_ASAP7_75t_R   g190(.A1(pi106), .A2(new_n412), .B(new_n410), .Y(new_n413));
  NOR2x1_ASAP7_75t_R   g191(.A(pi134), .B(new_n248), .Y(new_n414));
  AO21x1_ASAP7_75t_R   g192(.A1(new_n319), .A2(new_n248), .B(new_n414), .Y(new_n415));
  XNOR2x2_ASAP7_75t_R  g193(.A(pi100), .B(new_n415), .Y(new_n416));
  AND2x2_ASAP7_75t_R   g194(.A(pi131), .B(pi132), .Y(new_n417));
  AOI21x1_ASAP7_75t_R  g195(.A1(new_n248), .A2(po39), .B(new_n417), .Y(new_n418));
  NOR2x1_ASAP7_75t_R   g196(.A(pi104), .B(new_n418), .Y(new_n419));
  OA21x2_ASAP7_75t_R   g197(.A1(new_n247), .A2(pi110), .B(pi109), .Y(new_n420));
  OAI21x1_ASAP7_75t_R  g198(.A1(pi111), .A2(new_n332), .B(new_n420), .Y(new_n421));
  NOR2x1_ASAP7_75t_R   g199(.A(pi131), .B(po40), .Y(new_n422));
  AO21x1_ASAP7_75t_R   g200(.A1(pi131), .A2(new_n249), .B(new_n422), .Y(new_n423));
  AO22x1_ASAP7_75t_R   g201(.A1(new_n423), .A2(pi099), .B1(pi104), .B2(new_n418), .Y(new_n424));
  OR5x1_ASAP7_75t_R    g202(.A(new_n416), .B(new_n419), .C(new_n421), .D(new_n424), .E(new_n413), .Y(new_n425));
  OAI22x1_ASAP7_75t_R  g203(.A1(pi088), .A2(new_n396), .B1(new_n387), .B2(pi101), .Y(new_n426));
  OAI22x1_ASAP7_75t_R  g204(.A1(pi106), .A2(new_n412), .B1(new_n423), .B2(pi099), .Y(new_n427));
  NAND2x1_ASAP7_75t_R  g205(.A(pi103), .B(new_n379), .Y(new_n428));
  OAI21x1_ASAP7_75t_R  g206(.A1(pi022), .A2(new_n377), .B(new_n428), .Y(new_n429));
  AO221x2_ASAP7_75t_R  g207(.A1(pi089), .A2(new_n372), .B1(new_n374), .B2(pi105), .C(new_n429), .Y(new_n430));
  OR4x2_ASAP7_75t_R    g208(.A(new_n425), .B(new_n426), .C(new_n430), .D(new_n427), .Y(new_n431));
  OR5x1_ASAP7_75t_R    g209(.A(new_n398), .B(new_n406), .C(new_n431), .D(new_n409), .E(new_n403), .Y(po53));
  AO21x1_ASAP7_75t_R   g210(.A1(new_n322), .A2(pi079), .B(pi050), .Y(new_n433));
  AND2x2_ASAP7_75t_R   g211(.A(new_n433), .B(po32), .Y(new_n434));
  AOI22x1_ASAP7_75t_R  g212(.A1(pi145), .A2(new_n288), .B1(new_n289), .B2(pi146), .Y(new_n435));
  AOI22x1_ASAP7_75t_R  g213(.A1(pi148), .A2(new_n292), .B1(new_n291), .B2(pi147), .Y(new_n436));
  AOI22x1_ASAP7_75t_R  g214(.A1(new_n436), .A2(new_n435), .B1(new_n302), .B2(new_n301), .Y(new_n437));
  AND4x2_ASAP7_75t_R   g215(.A(new_n302), .B(new_n436), .C(new_n435), .D(new_n301), .Y(new_n438));
  NOR2x1_ASAP7_75t_R   g216(.A(new_n437), .B(new_n438), .Y(new_n439));
  XOR2x2_ASAP7_75t_R   g217(.A(new_n434), .B(new_n439), .Y(po55));
  XOR2x2_ASAP7_75t_R   g218(.A(po06), .B(new_n280), .Y(new_n441));
  XOR2x2_ASAP7_75t_R   g219(.A(new_n441), .B(new_n332), .Y(new_n442));
  AO22x1_ASAP7_75t_R   g220(.A1(new_n266), .A2(pi150), .B1(pi149), .B2(new_n264), .Y(new_n443));
  AO221x2_ASAP7_75t_R  g221(.A1(pi151), .A2(new_n268), .B1(new_n270), .B2(pi152), .C(new_n443), .Y(new_n444));
  XNOR2x2_ASAP7_75t_R  g222(.A(new_n390), .B(new_n444), .Y(new_n445));
  AO211x2_ASAP7_75t_R  g223(.A1(new_n382), .A2(new_n384), .B(new_n283), .C(new_n285), .Y(new_n446));
  AO211x2_ASAP7_75t_R  g224(.A1(new_n282), .A2(new_n284), .B(new_n383), .C(new_n385), .Y(new_n447));
  AND3x1_ASAP7_75t_R   g225(.A(new_n401), .B(new_n446), .C(new_n447), .Y(new_n448));
  AOI21x1_ASAP7_75t_R  g226(.A1(new_n446), .A2(new_n447), .B(new_n401), .Y(new_n449));
  OA21x2_ASAP7_75t_R   g227(.A1(new_n448), .A2(new_n449), .B(new_n365), .Y(new_n450));
  NOR3x1_ASAP7_75t_R   g228(.A(new_n448), .B(new_n449), .C(new_n365), .Y(new_n451));
  NOR2x1_ASAP7_75t_R   g229(.A(new_n450), .B(new_n451), .Y(new_n452));
  XOR2x2_ASAP7_75t_R   g230(.A(new_n452), .B(new_n445), .Y(new_n453));
  NAND2x1_ASAP7_75t_R  g231(.A(new_n442), .B(new_n453), .Y(new_n454));
  OA21x2_ASAP7_75t_R   g232(.A1(new_n453), .A2(new_n442), .B(new_n250), .Y(new_n455));
  NAND2x1_ASAP7_75t_R  g233(.A(new_n455), .B(new_n454), .Y(po56));
  XOR2x2_ASAP7_75t_R   g234(.A(po38), .B(po40), .Y(new_n457));
  XNOR2x2_ASAP7_75t_R  g235(.A(po39), .B(po41), .Y(new_n458));
  XOR2x2_ASAP7_75t_R   g236(.A(new_n458), .B(new_n457), .Y(new_n459));
  INVx1_ASAP7_75t_R    g237(.A(new_n459), .Y(new_n460));
  OAI21x1_ASAP7_75t_R  g238(.A1(new_n437), .A2(new_n438), .B(new_n311), .Y(new_n461));
  AO211x2_ASAP7_75t_R  g239(.A1(new_n309), .A2(new_n310), .B(new_n437), .C(new_n438), .Y(new_n462));
  AND2x2_ASAP7_75t_R   g240(.A(new_n462), .B(new_n461), .Y(new_n463));
  AOI21x1_ASAP7_75t_R  g241(.A1(new_n461), .A2(new_n462), .B(new_n322), .Y(new_n464));
  AND3x1_ASAP7_75t_R   g242(.A(new_n462), .B(new_n461), .C(new_n322), .Y(new_n465));
  OAI21x1_ASAP7_75t_R  g243(.A1(new_n464), .A2(new_n465), .B(new_n328), .Y(new_n466));
  OAI21x1_ASAP7_75t_R  g244(.A1(new_n328), .A2(new_n463), .B(new_n466), .Y(new_n467));
  XOR2x2_ASAP7_75t_R   g245(.A(new_n467), .B(new_n460), .Y(new_n468));
  AND3x1_ASAP7_75t_R   g246(.A(new_n436), .B(new_n435), .C(new_n240), .Y(new_n469));
  AOI21x1_ASAP7_75t_R  g247(.A1(pi078), .A2(new_n468), .B(new_n469), .Y(po57));
  OAI21x1_ASAP7_75t_R  g248(.A1(new_n464), .A2(new_n465), .B(po30), .Y(new_n471));
  OR3x1_ASAP7_75t_R    g249(.A(new_n465), .B(new_n464), .C(po30), .Y(new_n472));
  AND2x2_ASAP7_75t_R   g250(.A(new_n472), .B(new_n471), .Y(new_n473));
  XOR2x2_ASAP7_75t_R   g251(.A(new_n473), .B(po31), .Y(new_n474));
  AND2x2_ASAP7_75t_R   g252(.A(new_n474), .B(new_n460), .Y(new_n475));
  OAI21x1_ASAP7_75t_R  g253(.A1(new_n460), .A2(new_n474), .B(new_n250), .Y(new_n476));
  AO21x1_ASAP7_75t_R   g254(.A1(new_n460), .A2(new_n474), .B(new_n476), .Y(po59));
  AO21x1_ASAP7_75t_R   g255(.A1(new_n282), .A2(new_n284), .B(pi155), .Y(new_n478));
  OR5x1_ASAP7_75t_R    g256(.A(new_n265), .B(new_n267), .C(new_n269), .D(new_n271), .E(new_n251), .Y(new_n479));
  INVx1_ASAP7_75t_R    g257(.A(new_n479), .Y(new_n480));
  NOR2x1_ASAP7_75t_R   g258(.A(new_n479), .B(new_n478), .Y(new_n481));
  OA21x2_ASAP7_75t_R   g259(.A1(new_n478), .A2(new_n479), .B(pi105), .Y(new_n482));
  AOI21x1_ASAP7_75t_R  g260(.A1(pi022), .A2(new_n481), .B(new_n482), .Y(new_n483));
  NOR2x1_ASAP7_75t_R   g261(.A(po36), .B(new_n483), .Y(new_n484));
  OA21x2_ASAP7_75t_R   g262(.A1(new_n478), .A2(new_n479), .B(pi108), .Y(new_n485));
  AO21x1_ASAP7_75t_R   g263(.A1(pi021), .A2(new_n481), .B(new_n485), .Y(new_n486));
  OA31x2_ASAP7_75t_R   g264(.A1(new_n245), .A2(new_n478), .A3(new_n479), .B1(new_n303), .Y(new_n487));
  OAI21x1_ASAP7_75t_R  g265(.A1(new_n241), .A2(new_n481), .B(new_n487), .Y(new_n488));
  OA21x2_ASAP7_75t_R   g266(.A1(new_n478), .A2(new_n479), .B(pi089), .Y(new_n489));
  AO21x1_ASAP7_75t_R   g267(.A1(new_n481), .A2(pi098), .B(new_n489), .Y(new_n490));
  MAJx2_ASAP7_75t_R    g268(.A(new_n490), .B(new_n323), .C(new_n488), .Y(new_n491));
  MAJx2_ASAP7_75t_R    g269(.A(new_n491), .B(new_n486), .C(new_n311), .Y(new_n492));
  OA21x2_ASAP7_75t_R   g270(.A1(new_n478), .A2(new_n479), .B(pi106), .Y(new_n493));
  AOI21x1_ASAP7_75t_R  g271(.A1(pi023), .A2(new_n481), .B(new_n493), .Y(new_n494));
  AO32x1_ASAP7_75t_R   g272(.A1(pi156), .A2(new_n494), .A3(po37), .B1(po36), .B2(new_n483), .Y(new_n495));
  INVx1_ASAP7_75t_R    g273(.A(new_n495), .Y(new_n496));
  OAI21x1_ASAP7_75t_R  g274(.A1(new_n484), .A2(new_n492), .B(new_n496), .Y(new_n497));
  OR3x1_ASAP7_75t_R    g275(.A(new_n494), .B(po37), .C(new_n252), .Y(new_n498));
  OA21x2_ASAP7_75t_R   g276(.A1(new_n478), .A2(new_n479), .B(pi103), .Y(new_n499));
  AO21x1_ASAP7_75t_R   g277(.A1(pi024), .A2(new_n481), .B(new_n499), .Y(new_n500));
  NOR3x1_ASAP7_75t_R   g278(.A(new_n500), .B(po29), .C(new_n252), .Y(new_n501));
  AOI21x1_ASAP7_75t_R  g279(.A1(new_n498), .A2(new_n497), .B(new_n501), .Y(new_n502));
  OR3x1_ASAP7_75t_R    g280(.A(new_n481), .B(new_n246), .C(new_n243), .Y(new_n503));
  AND3x1_ASAP7_75t_R   g281(.A(new_n481), .B(po40), .C(po39), .Y(new_n504));
  NOR2x1_ASAP7_75t_R   g282(.A(new_n252), .B(new_n504), .Y(new_n505));
  AO32x1_ASAP7_75t_R   g283(.A1(pi156), .A2(po29), .A3(new_n500), .B1(new_n503), .B2(new_n505), .Y(new_n506));
  AO21x1_ASAP7_75t_R   g284(.A1(pi099), .A2(pi104), .B(new_n252), .Y(new_n507));
  OA22x2_ASAP7_75t_R   g285(.A1(new_n481), .A2(new_n507), .B1(new_n502), .B2(new_n506), .Y(new_n508));
  AND3x1_ASAP7_75t_R   g286(.A(po06), .B(new_n478), .C(pi154), .Y(new_n509));
  NAND2x1_ASAP7_75t_R  g287(.A(new_n478), .B(new_n480), .Y(new_n510));
  OA211x2_ASAP7_75t_R  g288(.A1(new_n383), .A2(new_n385), .B(new_n509), .C(pi101), .Y(new_n511));
  AND5x1_ASAP7_75t_R   g289(.A(new_n480), .B(new_n384), .C(new_n382), .D(new_n244), .E(new_n478), .Y(new_n512));
  AND3x1_ASAP7_75t_R   g290(.A(new_n509), .B(new_n391), .C(pi098), .Y(new_n513));
  OR2x4_ASAP7_75t_R    g291(.A(pi098), .B(new_n391), .Y(new_n514));
  NOR2x1_ASAP7_75t_R   g292(.A(new_n514), .B(new_n510), .Y(new_n515));
  OR4x2_ASAP7_75t_R    g293(.A(new_n511), .B(new_n513), .C(new_n515), .D(new_n512), .Y(new_n516));
  AND3x1_ASAP7_75t_R   g294(.A(new_n509), .B(new_n365), .C(new_n245), .Y(new_n517));
  AND2x2_ASAP7_75t_R   g295(.A(new_n364), .B(pi102), .Y(new_n518));
  INVx1_ASAP7_75t_R    g296(.A(new_n518), .Y(new_n519));
  AO21x1_ASAP7_75t_R   g297(.A1(new_n509), .A2(new_n518), .B(new_n517), .Y(new_n520));
  XOR2x2_ASAP7_75t_R   g298(.A(po41), .B(pi100), .Y(new_n521));
  AND2x2_ASAP7_75t_R   g299(.A(new_n521), .B(new_n509), .Y(new_n522));
  OR3x1_ASAP7_75t_R    g300(.A(new_n516), .B(new_n520), .C(new_n522), .Y(new_n523));
  OR5x1_ASAP7_75t_R    g301(.A(new_n517), .B(new_n518), .C(pi100), .D(new_n319), .E(new_n510), .Y(new_n524));
  AOI21x1_ASAP7_75t_R  g302(.A1(new_n512), .A2(new_n519), .B(new_n517), .Y(new_n525));
  OA222x2_ASAP7_75t_R  g303(.A1(new_n516), .A2(new_n524), .B1(new_n525), .B2(new_n513), .C1(new_n510), .C2(new_n514), .Y(new_n526));
  OA21x2_ASAP7_75t_R   g304(.A1(new_n508), .A2(new_n523), .B(new_n526), .Y(po60));
  OR4x2_ASAP7_75t_R    g305(.A(new_n344), .B(po51), .C(po52), .D(po05), .Y(new_n528));
  AOI21x1_ASAP7_75t_R  g306(.A1(new_n455), .A2(new_n454), .B(new_n528), .Y(new_n529));
  OAI21x1_ASAP7_75t_R  g307(.A1(new_n476), .A2(new_n475), .B(new_n529), .Y(po62));
  assign               po61 = 1'b0;
  NAND2x1_ASAP7_75t_R  g308(.A(new_n258), .B(new_n260), .Y(po04));
  INVx1_ASAP7_75t_R    g309(.A(pi018), .Y(po08));
  INVx1_ASAP7_75t_R    g310(.A(pi018), .Y(po09));
  INVx1_ASAP7_75t_R    g311(.A(pi019), .Y(po11));
  INVx1_ASAP7_75t_R    g312(.A(pi020), .Y(po13));
  INVx1_ASAP7_75t_R    g313(.A(pi020), .Y(po14));
  BUFx2_ASAP7_75t_R    g314(.A(pi018), .Y(po25));
  AO21x1_ASAP7_75t_R   g315(.A1(new_n240), .A2(new_n322), .B(new_n320), .Y(po43));
  AO21x1_ASAP7_75t_R   g316(.A1(new_n240), .A2(po35), .B(new_n325), .Y(po45));
  OA21x2_ASAP7_75t_R   g317(.A1(pi078), .A2(new_n303), .B(new_n329), .Y(po48));
  OR5x1_ASAP7_75t_R    g318(.A(new_n398), .B(new_n406), .C(new_n431), .D(new_n409), .E(new_n403), .Y(po54));
  AOI21x1_ASAP7_75t_R  g319(.A1(pi078), .A2(new_n468), .B(new_n469), .Y(po58));
  OAI21x1_ASAP7_75t_R  g320(.A1(new_n476), .A2(new_n475), .B(new_n529), .Y(po63));
endmodule


