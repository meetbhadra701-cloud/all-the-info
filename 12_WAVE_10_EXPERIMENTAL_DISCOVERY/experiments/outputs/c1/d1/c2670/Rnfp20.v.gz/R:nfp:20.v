// Benchmark "/w/experiments/inputs/c1/c2/c2670" written by ABC on Fri Sep 25 10:27:09 2026

module \/w/experiments/inputs/c1/c2/c2670  ( 
    pi000, pi001, pi002, pi003, pi004, pi005, pi006, pi007, pi008, pi009,
    pi010, pi011, pi012, pi013, pi014, pi015, pi016, pi017, pi018, pi019,
    pi020, pi021, pi022, pi023, pi024, pi025, pi026, pi027, pi028, pi029,
    pi030, pi031, pi032, pi033, pi034, pi035, pi036, pi037, pi038, pi039,
    pi040, pi041, pi042, pi043, pi044, pi045, pi046, pi047, pi048, pi049,
    pi050, pi051, pi052, pi053, pi054, pi055, pi056, pi057, pi058, pi059,
    pi060, pi061, pi062, pi063, pi064, pi065, pi066, pi067, pi068, pi069,
    pi070, pi071, pi072, pi073, pi074, pi075, pi076, pi077, pi078, pi079,
    pi080, pi081, pi082, pi083, pi084, pi085, pi086, pi087, pi088, pi089,
    pi090, pi091, pi092, pi093, pi094, pi095, pi096, pi097, pi098, pi099,
    pi100, pi101, pi102, pi103, pi104, pi105, pi106, pi107, pi108, pi109,
    pi110, pi111, pi112, pi113, pi114, pi115, pi116, pi117, pi118, pi119,
    pi120, pi121, pi122, pi123, pi124, pi125, pi126, pi127, pi128, pi129,
    pi130, pi131, pi132, pi133, pi134, pi135, pi136, pi137, pi138, pi139,
    pi140, pi141, pi142, pi143, pi144, pi145, pi146, pi147, pi148, pi149,
    pi150, pi151, pi152, pi153, pi154, pi155, pi156,
    po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10, po11,
    po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22, po23,
    po24, po25, po26, po27, po28, po29, po30, po31, po32, po33, po34, po35,
    po36, po37, po38, po39, po40, po41, po42, po43, po44, po45, po46, po47,
    po48, po49, po50, po51, po52, po53, po54, po55, po56, po57, po58, po59,
    po60, po61, po62, po63  );
  input  pi000, pi001, pi002, pi003, pi004, pi005, pi006, pi007, pi008,
    pi009, pi010, pi011, pi012, pi013, pi014, pi015, pi016, pi017, pi018,
    pi019, pi020, pi021, pi022, pi023, pi024, pi025, pi026, pi027, pi028,
    pi029, pi030, pi031, pi032, pi033, pi034, pi035, pi036, pi037, pi038,
    pi039, pi040, pi041, pi042, pi043, pi044, pi045, pi046, pi047, pi048,
    pi049, pi050, pi051, pi052, pi053, pi054, pi055, pi056, pi057, pi058,
    pi059, pi060, pi061, pi062, pi063, pi064, pi065, pi066, pi067, pi068,
    pi069, pi070, pi071, pi072, pi073, pi074, pi075, pi076, pi077, pi078,
    pi079, pi080, pi081, pi082, pi083, pi084, pi085, pi086, pi087, pi088,
    pi089, pi090, pi091, pi092, pi093, pi094, pi095, pi096, pi097, pi098,
    pi099, pi100, pi101, pi102, pi103, pi104, pi105, pi106, pi107, pi108,
    pi109, pi110, pi111, pi112, pi113, pi114, pi115, pi116, pi117, pi118,
    pi119, pi120, pi121, pi122, pi123, pi124, pi125, pi126, pi127, pi128,
    pi129, pi130, pi131, pi132, pi133, pi134, pi135, pi136, pi137, pi138,
    pi139, pi140, pi141, pi142, pi143, pi144, pi145, pi146, pi147, pi148,
    pi149, pi150, pi151, pi152, pi153, pi154, pi155, pi156;
  output po00, po01, po02, po03, po04, po05, po06, po07, po08, po09, po10,
    po11, po12, po13, po14, po15, po16, po17, po18, po19, po20, po21, po22,
    po23, po24, po25, po26, po27, po28, po29, po30, po31, po32, po33, po34,
    po35, po36, po37, po38, po39, po40, po41, po42, po43, po44, po45, po46,
    po47, po48, po49, po50, po51, po52, po53, po54, po55, po56, po57, po58,
    po59, po60, po61, po62, po63;
  wire new_n231, new_n232, new_n233, new_n234, new_n235, new_n239, new_n240,
    new_n241, new_n242, new_n243, new_n244, new_n245, new_n246, new_n247,
    new_n248, new_n249, new_n250, new_n251, new_n252, new_n253, new_n254,
    new_n255, new_n256, new_n257, new_n258, new_n259, new_n260, new_n261,
    new_n263, new_n265, new_n267, new_n268, new_n269, new_n270, new_n273,
    new_n274, new_n275, new_n276, new_n277, new_n278, new_n279, new_n280,
    new_n282, new_n284, new_n287, new_n288, new_n290, new_n291, new_n292,
    new_n293, new_n294, new_n296, new_n297, new_n298, new_n299, new_n300,
    new_n303, new_n306, new_n309, new_n310, new_n311, new_n312, new_n313,
    new_n315, new_n318, new_n319, new_n320, new_n322, new_n323, new_n325,
    new_n326, new_n328, new_n330, new_n331, new_n332, new_n333, new_n335,
    new_n338, new_n339, new_n341, new_n342, new_n343, new_n345, new_n346,
    new_n347, new_n348, new_n349, new_n350, new_n351, new_n352, new_n353,
    new_n354, new_n356, new_n357, new_n358, new_n359, new_n360, new_n361,
    new_n363, new_n364, new_n365, new_n366, new_n367, new_n368, new_n369,
    new_n370, new_n372, new_n373, new_n374, new_n375, new_n376, new_n377,
    new_n378, new_n379, new_n380, new_n381, new_n382, new_n383, new_n384,
    new_n385, new_n386, new_n387, new_n388, new_n389, new_n390, new_n391,
    new_n392, new_n393, new_n394, new_n395, new_n396, new_n397, new_n398,
    new_n399, new_n400, new_n401, new_n402, new_n403, new_n404, new_n405,
    new_n406, new_n407, new_n408, new_n409, new_n410, new_n411, new_n412,
    new_n413, new_n414, new_n415, new_n416, new_n417, new_n418, new_n419,
    new_n420, new_n421, new_n422, new_n423, new_n424, new_n425, new_n426,
    new_n427, new_n428, new_n429, new_n430, new_n431, new_n432, new_n433,
    new_n434, new_n435, new_n436, new_n437, new_n438, new_n439, new_n440,
    new_n441, new_n442, new_n444, new_n445, new_n446, new_n447, new_n448,
    new_n449, new_n450, new_n451, new_n452, new_n453, new_n455, new_n456,
    new_n457, new_n458, new_n459, new_n460, new_n461, new_n462, new_n463,
    new_n464, new_n466, new_n467, new_n468, new_n469, new_n470, new_n471,
    new_n472, new_n473, new_n474, new_n475, new_n476, new_n477, new_n479,
    new_n480, new_n481, new_n482, new_n483, new_n484, new_n486, new_n487,
    new_n488, new_n489, new_n490, new_n491, new_n492, new_n493, new_n494,
    new_n495, new_n496, new_n497, new_n498, new_n499, new_n500, new_n501,
    new_n502, new_n503, new_n504, new_n505, new_n506, new_n507, new_n508,
    new_n509, new_n510, new_n511, new_n512, new_n513, new_n514, new_n515,
    new_n516, new_n517, new_n518, new_n519, new_n520, new_n521, new_n522,
    new_n523, new_n524, new_n525, new_n526, new_n527, new_n528, new_n529,
    new_n530, new_n531, new_n532, new_n533, new_n534, new_n535, new_n537,
    new_n538;
  INVx1_ASAP7_75t_R    g000(.A(pi004), .Y(po19));
  INVx1_ASAP7_75t_R    g001(.A(pi005), .Y(po22));
  INVx1_ASAP7_75t_R    g002(.A(pi006), .Y(po21));
  INVx1_ASAP7_75t_R    g003(.A(pi007), .Y(po20));
  INVx1_ASAP7_75t_R    g004(.A(pi008), .Y(po15));
  INVx1_ASAP7_75t_R    g005(.A(pi009), .Y(po18));
  INVx1_ASAP7_75t_R    g006(.A(pi010), .Y(po17));
  INVx1_ASAP7_75t_R    g007(.A(pi011), .Y(po16));
  INVx1_ASAP7_75t_R    g008(.A(pi012), .Y(new_n231));
  INVx1_ASAP7_75t_R    g009(.A(pi013), .Y(new_n232));
  INVx1_ASAP7_75t_R    g010(.A(pi014), .Y(new_n233));
  INVx1_ASAP7_75t_R    g011(.A(pi015), .Y(new_n234));
  INVx1_ASAP7_75t_R    g012(.A(pi016), .Y(new_n235));
  INVx1_ASAP7_75t_R    g013(.A(pi018), .Y(po07));
  INVx1_ASAP7_75t_R    g014(.A(pi019), .Y(po10));
  INVx1_ASAP7_75t_R    g015(.A(pi020), .Y(po12));
  INVx1_ASAP7_75t_R    g016(.A(pi036), .Y(new_n239));
  INVx1_ASAP7_75t_R    g017(.A(pi037), .Y(new_n240));
  INVx1_ASAP7_75t_R    g018(.A(pi050), .Y(new_n241));
  INVx1_ASAP7_75t_R    g019(.A(pi055), .Y(new_n242));
  INVx1_ASAP7_75t_R    g020(.A(pi056), .Y(new_n243));
  INVx1_ASAP7_75t_R    g021(.A(pi078), .Y(new_n244));
  INVx1_ASAP7_75t_R    g022(.A(pi096), .Y(new_n245));
  INVx1_ASAP7_75t_R    g023(.A(pi098), .Y(new_n246));
  INVx1_ASAP7_75t_R    g024(.A(pi100), .Y(new_n247));
  INVx1_ASAP7_75t_R    g025(.A(pi102), .Y(new_n248));
  INVx1_ASAP7_75t_R    g026(.A(pi111), .Y(new_n249));
  INVx1_ASAP7_75t_R    g027(.A(pi123), .Y(new_n250));
  INVx1_ASAP7_75t_R    g028(.A(pi130), .Y(new_n251));
  INVx1_ASAP7_75t_R    g029(.A(pi133), .Y(new_n252));
  INVx1_ASAP7_75t_R    g030(.A(pi134), .Y(new_n253));
  INVx1_ASAP7_75t_R    g031(.A(pi135), .Y(new_n254));
  INVx1_ASAP7_75t_R    g032(.A(pi140), .Y(new_n255));
  INVx1_ASAP7_75t_R    g033(.A(pi141), .Y(new_n256));
  INVx1_ASAP7_75t_R    g034(.A(pi142), .Y(new_n257));
  INVx1_ASAP7_75t_R    g035(.A(pi143), .Y(new_n258));
  INVx1_ASAP7_75t_R    g036(.A(pi144), .Y(new_n259));
  INVx1_ASAP7_75t_R    g037(.A(pi155), .Y(new_n260));
  INVx1_ASAP7_75t_R    g038(.A(pi156), .Y(new_n261));
  NAND2x1_ASAP7_75t_R  g039(.A(pi000), .B(pi001), .Y(po00));
  AND3x1_ASAP7_75t_R   g040(.A(pi000), .B(pi001), .C(pi002), .Y(new_n263));
  INVx1_ASAP7_75t_R    g041(.A(new_n263), .Y(po01));
  AND3x1_ASAP7_75t_R   g042(.A(pi000), .B(pi001), .C(pi003), .Y(new_n265));
  INVx1_ASAP7_75t_R    g043(.A(new_n265), .Y(po02));
  AND4x2_ASAP7_75t_R   g044(.A(pi004), .B(pi005), .C(pi006), .D(pi007), .Y(new_n267));
  INVx1_ASAP7_75t_R    g045(.A(new_n267), .Y(new_n268));
  AND4x2_ASAP7_75t_R   g046(.A(pi008), .B(pi009), .C(pi010), .D(pi011), .Y(new_n269));
  INVx1_ASAP7_75t_R    g047(.A(new_n269), .Y(new_n270));
  NAND2x1_ASAP7_75t_R  g048(.A(new_n267), .B(new_n269), .Y(po03));
  AO22x1_ASAP7_75t_R   g049(.A1(new_n270), .A2(pi003), .B1(new_n268), .B2(pi002), .Y(po05));
  NOR2x1_ASAP7_75t_R   g050(.A(pi012), .B(pi013), .Y(new_n273));
  OR3x1_ASAP7_75t_R    g051(.A(new_n233), .B(pi013), .C(pi012), .Y(new_n274));
  AND2x2_ASAP7_75t_R   g052(.A(new_n231), .B(pi013), .Y(new_n275));
  OR3x1_ASAP7_75t_R    g053(.A(new_n232), .B(new_n234), .C(pi012), .Y(new_n276));
  AND2x2_ASAP7_75t_R   g054(.A(new_n232), .B(pi012), .Y(new_n277));
  OR3x1_ASAP7_75t_R    g055(.A(new_n231), .B(new_n235), .C(pi013), .Y(new_n278));
  AND2x2_ASAP7_75t_R   g056(.A(pi012), .B(pi013), .Y(new_n279));
  NAND2x1_ASAP7_75t_R  g057(.A(pi017), .B(new_n279), .Y(new_n280));
  AND4x2_ASAP7_75t_R   g058(.A(new_n280), .B(new_n278), .C(new_n276), .D(new_n274), .Y(po06));
  AND4x2_ASAP7_75t_R   g059(.A(pi021), .B(pi022), .C(pi023), .D(pi024), .Y(new_n282));
  INVx1_ASAP7_75t_R    g060(.A(new_n282), .Y(po23));
  AND3x1_ASAP7_75t_R   g061(.A(pi001), .B(pi025), .C(pi026), .Y(new_n284));
  INVx1_ASAP7_75t_R    g062(.A(new_n284), .Y(po24));
  AND2x2_ASAP7_75t_R   g063(.A(po07), .B(pi027), .Y(po26));
  AO22x1_ASAP7_75t_R   g064(.A1(new_n275), .A2(pi029), .B1(pi028), .B2(new_n273), .Y(new_n287));
  AO221x2_ASAP7_75t_R  g065(.A1(pi030), .A2(new_n277), .B1(new_n279), .B2(pi031), .C(new_n287), .Y(new_n288));
  INVx1_ASAP7_75t_R    g066(.A(new_n288), .Y(po27));
  AND3x1_ASAP7_75t_R   g067(.A(new_n231), .B(new_n232), .C(pi032), .Y(new_n290));
  AND3x1_ASAP7_75t_R   g068(.A(new_n231), .B(pi013), .C(pi033), .Y(new_n291));
  AND3x1_ASAP7_75t_R   g069(.A(new_n232), .B(pi034), .C(pi012), .Y(new_n292));
  AND3x1_ASAP7_75t_R   g070(.A(pi012), .B(pi013), .C(pi035), .Y(new_n293));
  OR4x2_ASAP7_75t_R    g071(.A(new_n290), .B(new_n291), .C(new_n292), .D(new_n293), .Y(new_n294));
  INVx1_ASAP7_75t_R    g072(.A(new_n294), .Y(po28));
  NOR2x1_ASAP7_75t_R   g073(.A(pi036), .B(pi037), .Y(new_n296));
  AND2x2_ASAP7_75t_R   g074(.A(new_n239), .B(pi037), .Y(new_n297));
  AO22x1_ASAP7_75t_R   g075(.A1(new_n297), .A2(pi039), .B1(pi038), .B2(new_n296), .Y(new_n298));
  AND2x2_ASAP7_75t_R   g076(.A(new_n240), .B(pi036), .Y(new_n299));
  AND2x2_ASAP7_75t_R   g077(.A(pi036), .B(pi037), .Y(new_n300));
  AO221x2_ASAP7_75t_R  g078(.A1(pi040), .A2(new_n299), .B1(new_n300), .B2(pi041), .C(new_n298), .Y(po38));
  INVx1_ASAP7_75t_R    g079(.A(po38), .Y(po29));
  AO22x1_ASAP7_75t_R   g080(.A1(new_n297), .A2(pi043), .B1(pi042), .B2(new_n296), .Y(new_n303));
  AO221x2_ASAP7_75t_R  g081(.A1(pi044), .A2(new_n299), .B1(new_n300), .B2(pi045), .C(new_n303), .Y(po37));
  INVx1_ASAP7_75t_R    g082(.A(po37), .Y(po30));
  AO22x1_ASAP7_75t_R   g083(.A1(new_n297), .A2(pi047), .B1(pi046), .B2(new_n296), .Y(new_n306));
  AO221x2_ASAP7_75t_R  g084(.A1(pi048), .A2(new_n299), .B1(new_n300), .B2(pi049), .C(new_n306), .Y(po36));
  INVx1_ASAP7_75t_R    g085(.A(po36), .Y(po31));
  AND3x1_ASAP7_75t_R   g086(.A(new_n239), .B(new_n240), .C(pi051), .Y(new_n309));
  AND3x1_ASAP7_75t_R   g087(.A(new_n239), .B(pi037), .C(pi052), .Y(new_n310));
  AND3x1_ASAP7_75t_R   g088(.A(new_n240), .B(pi053), .C(pi036), .Y(new_n311));
  AND3x1_ASAP7_75t_R   g089(.A(pi036), .B(pi037), .C(pi054), .Y(new_n312));
  OR4x2_ASAP7_75t_R    g090(.A(new_n309), .B(new_n310), .C(new_n311), .D(new_n312), .Y(new_n313));
  OR5x1_ASAP7_75t_R    g091(.A(new_n309), .B(new_n310), .C(new_n311), .D(new_n312), .E(new_n241), .Y(po32));
  OR3x1_ASAP7_75t_R    g092(.A(po05), .B(new_n243), .C(pi001), .Y(new_n315));
  OR4x2_ASAP7_75t_R    g093(.A(po05), .B(new_n243), .C(new_n242), .D(pi001), .Y(po33));
  AO21x1_ASAP7_75t_R   g094(.A1(pi057), .A2(pi058), .B(new_n315), .Y(po34));
  AO22x1_ASAP7_75t_R   g095(.A1(new_n297), .A2(pi060), .B1(pi059), .B2(new_n296), .Y(new_n318));
  INVx1_ASAP7_75t_R    g096(.A(new_n318), .Y(new_n319));
  AOI22x1_ASAP7_75t_R  g097(.A1(pi062), .A2(new_n300), .B1(new_n299), .B2(pi061), .Y(new_n320));
  NAND2x1_ASAP7_75t_R  g098(.A(new_n320), .B(new_n319), .Y(po35));
  INVx1_ASAP7_75t_R    g099(.A(po35), .Y(new_n322));
  AO21x1_ASAP7_75t_R   g100(.A1(pi063), .A2(new_n296), .B(new_n297), .Y(new_n323));
  AO221x2_ASAP7_75t_R  g101(.A1(pi064), .A2(new_n299), .B1(new_n300), .B2(pi065), .C(new_n323), .Y(po39));
  INVx1_ASAP7_75t_R    g102(.A(po39), .Y(new_n325));
  AO22x1_ASAP7_75t_R   g103(.A1(new_n297), .A2(pi067), .B1(pi066), .B2(new_n296), .Y(new_n326));
  AO221x2_ASAP7_75t_R  g104(.A1(pi068), .A2(new_n299), .B1(new_n300), .B2(pi069), .C(new_n326), .Y(po40));
  AO22x1_ASAP7_75t_R   g105(.A1(new_n297), .A2(pi071), .B1(pi070), .B2(new_n296), .Y(new_n328));
  AO221x2_ASAP7_75t_R  g106(.A1(pi072), .A2(new_n299), .B1(new_n300), .B2(pi073), .C(new_n328), .Y(po41));
  AND2x2_ASAP7_75t_R   g107(.A(po36), .B(pi078), .Y(new_n330));
  AO22x1_ASAP7_75t_R   g108(.A1(new_n297), .A2(pi075), .B1(pi074), .B2(new_n296), .Y(new_n331));
  AO221x2_ASAP7_75t_R  g109(.A1(pi076), .A2(new_n299), .B1(new_n300), .B2(pi077), .C(new_n331), .Y(new_n332));
  INVx1_ASAP7_75t_R    g110(.A(new_n332), .Y(new_n333));
  AO21x1_ASAP7_75t_R   g111(.A1(new_n244), .A2(new_n333), .B(new_n330), .Y(po42));
  NOR2x1_ASAP7_75t_R   g112(.A(new_n244), .B(po37), .Y(new_n335));
  AO21x1_ASAP7_75t_R   g113(.A1(new_n244), .A2(po35), .B(new_n335), .Y(po44));
  AO21x1_ASAP7_75t_R   g114(.A1(new_n241), .A2(pi079), .B(new_n332), .Y(po46));
  NOR2x1_ASAP7_75t_R   g115(.A(pi079), .B(new_n332), .Y(new_n338));
  NAND2x1_ASAP7_75t_R  g116(.A(new_n244), .B(new_n313), .Y(new_n339));
  OA21x2_ASAP7_75t_R   g117(.A1(new_n338), .A2(new_n244), .B(new_n339), .Y(po47));
  AO22x1_ASAP7_75t_R   g118(.A1(new_n275), .A2(pi083), .B1(pi082), .B2(new_n273), .Y(new_n341));
  AO221x2_ASAP7_75t_R  g119(.A1(pi084), .A2(new_n277), .B1(new_n279), .B2(pi085), .C(new_n341), .Y(new_n342));
  AOI21x1_ASAP7_75t_R  g120(.A1(pi081), .A2(new_n342), .B(pi080), .Y(new_n343));
  OAI21x1_ASAP7_75t_R  g121(.A1(pi081), .A2(new_n342), .B(new_n343), .Y(po49));
  XNOR2x2_ASAP7_75t_R  g122(.A(pi088), .B(pi089), .Y(new_n345));
  XNOR2x2_ASAP7_75t_R  g123(.A(pi090), .B(pi091), .Y(new_n346));
  XOR2x2_ASAP7_75t_R   g124(.A(new_n346), .B(pi094), .Y(new_n347));
  XOR2x2_ASAP7_75t_R   g125(.A(pi086), .B(pi087), .Y(new_n348));
  XOR2x2_ASAP7_75t_R   g126(.A(pi092), .B(pi093), .Y(new_n349));
  XOR2x2_ASAP7_75t_R   g127(.A(new_n349), .B(pi095), .Y(new_n350));
  XOR2x2_ASAP7_75t_R   g128(.A(new_n350), .B(new_n348), .Y(new_n351));
  XOR2x2_ASAP7_75t_R   g129(.A(new_n351), .B(new_n347), .Y(new_n352));
  AOI21x1_ASAP7_75t_R  g130(.A1(new_n345), .A2(new_n352), .B(new_n245), .Y(new_n353));
  OA21x2_ASAP7_75t_R   g131(.A1(new_n345), .A2(new_n352), .B(new_n353), .Y(new_n354));
  INVx1_ASAP7_75t_R    g132(.A(new_n354), .Y(po50));
  XOR2x2_ASAP7_75t_R   g133(.A(pi097), .B(pi098), .Y(new_n356));
  XOR2x2_ASAP7_75t_R   g134(.A(pi023), .B(pi024), .Y(new_n357));
  XOR2x2_ASAP7_75t_R   g135(.A(pi021), .B(pi022), .Y(new_n358));
  XOR2x2_ASAP7_75t_R   g136(.A(new_n357), .B(new_n358), .Y(new_n359));
  XNOR2x2_ASAP7_75t_R  g137(.A(pi080), .B(pi081), .Y(new_n360));
  XOR2x2_ASAP7_75t_R   g138(.A(new_n359), .B(new_n360), .Y(new_n361));
  XOR2x2_ASAP7_75t_R   g139(.A(new_n361), .B(new_n356), .Y(po51));
  XOR2x2_ASAP7_75t_R   g140(.A(pi099), .B(pi100), .Y(new_n363));
  XOR2x2_ASAP7_75t_R   g141(.A(pi107), .B(pi108), .Y(new_n364));
  XOR2x2_ASAP7_75t_R   g142(.A(new_n363), .B(new_n364), .Y(new_n365));
  XOR2x2_ASAP7_75t_R   g143(.A(pi105), .B(pi106), .Y(new_n366));
  XOR2x2_ASAP7_75t_R   g144(.A(pi103), .B(pi104), .Y(new_n367));
  XOR2x2_ASAP7_75t_R   g145(.A(new_n366), .B(new_n367), .Y(new_n368));
  XNOR2x2_ASAP7_75t_R  g146(.A(pi101), .B(pi102), .Y(new_n369));
  XOR2x2_ASAP7_75t_R   g147(.A(new_n368), .B(new_n369), .Y(new_n370));
  XOR2x2_ASAP7_75t_R   g148(.A(new_n370), .B(new_n365), .Y(po52));
  NOR2x1_ASAP7_75t_R   g149(.A(pi113), .B(new_n249), .Y(new_n372));
  AO22x1_ASAP7_75t_R   g150(.A1(new_n275), .A2(pi115), .B1(pi114), .B2(new_n273), .Y(new_n373));
  AO221x2_ASAP7_75t_R  g151(.A1(pi116), .A2(new_n277), .B1(new_n279), .B2(pi117), .C(new_n373), .Y(new_n374));
  INVx1_ASAP7_75t_R    g152(.A(new_n374), .Y(new_n375));
  AO21x1_ASAP7_75t_R   g153(.A1(new_n375), .A2(new_n249), .B(new_n372), .Y(new_n376));
  NOR2x1_ASAP7_75t_R   g154(.A(pi102), .B(new_n376), .Y(new_n377));
  NOR2x1_ASAP7_75t_R   g155(.A(pi131), .B(po35), .Y(new_n378));
  AO21x1_ASAP7_75t_R   g156(.A1(pi131), .A2(new_n257), .B(new_n378), .Y(new_n379));
  AO22x1_ASAP7_75t_R   g157(.A1(new_n376), .A2(pi102), .B1(pi108), .B2(new_n379), .Y(new_n380));
  NOR2x1_ASAP7_75t_R   g158(.A(pi131), .B(new_n332), .Y(new_n381));
  AO21x1_ASAP7_75t_R   g159(.A1(pi131), .A2(new_n256), .B(new_n381), .Y(new_n382));
  NOR2x1_ASAP7_75t_R   g160(.A(pi131), .B(po36), .Y(new_n383));
  AO21x1_ASAP7_75t_R   g161(.A1(pi131), .A2(new_n258), .B(new_n383), .Y(new_n384));
  OAI22x1_ASAP7_75t_R  g162(.A1(new_n384), .A2(pi105), .B1(new_n382), .B2(pi089), .Y(new_n385));
  NOR2x1_ASAP7_75t_R   g163(.A(pi128), .B(new_n249), .Y(new_n386));
  AO21x1_ASAP7_75t_R   g164(.A1(po28), .A2(new_n249), .B(new_n386), .Y(new_n387));
  NAND2x1_ASAP7_75t_R  g165(.A(pi022), .B(new_n387), .Y(new_n388));
  NOR2x1_ASAP7_75t_R   g166(.A(pi131), .B(po38), .Y(new_n389));
  AO21x1_ASAP7_75t_R   g167(.A1(new_n251), .A2(pi131), .B(new_n389), .Y(new_n390));
  OAI21x1_ASAP7_75t_R  g168(.A1(pi103), .A2(new_n390), .B(new_n388), .Y(new_n391));
  AND3x1_ASAP7_75t_R   g169(.A(new_n231), .B(new_n232), .C(pi136), .Y(new_n392));
  AND3x1_ASAP7_75t_R   g170(.A(new_n231), .B(pi013), .C(pi137), .Y(new_n393));
  AND3x1_ASAP7_75t_R   g171(.A(new_n232), .B(pi138), .C(pi012), .Y(new_n394));
  AND3x1_ASAP7_75t_R   g172(.A(pi012), .B(pi013), .C(pi139), .Y(new_n395));
  OR4x2_ASAP7_75t_R    g173(.A(new_n392), .B(new_n393), .C(new_n394), .D(new_n395), .Y(new_n396));
  NOR2x1_ASAP7_75t_R   g174(.A(pi111), .B(new_n396), .Y(new_n397));
  AO21x1_ASAP7_75t_R   g175(.A1(pi111), .A2(new_n254), .B(new_n397), .Y(new_n398));
  NOR2x1_ASAP7_75t_R   g176(.A(pi118), .B(new_n249), .Y(new_n399));
  AO22x1_ASAP7_75t_R   g177(.A1(new_n275), .A2(pi120), .B1(pi119), .B2(new_n273), .Y(new_n400));
  AO221x2_ASAP7_75t_R  g178(.A1(pi121), .A2(new_n277), .B1(new_n279), .B2(pi122), .C(new_n400), .Y(new_n401));
  INVx1_ASAP7_75t_R    g179(.A(new_n401), .Y(new_n402));
  AO21x1_ASAP7_75t_R   g180(.A1(new_n402), .A2(new_n249), .B(new_n399), .Y(new_n403));
  NOR2x1_ASAP7_75t_R   g181(.A(pi098), .B(new_n403), .Y(new_n404));
  AO21x1_ASAP7_75t_R   g182(.A1(pi101), .A2(new_n398), .B(new_n404), .Y(new_n405));
  NAND2x1_ASAP7_75t_R  g183(.A(pi131), .B(new_n255), .Y(new_n406));
  OAI21x1_ASAP7_75t_R  g184(.A1(pi131), .A2(new_n313), .B(new_n406), .Y(new_n407));
  AO221x2_ASAP7_75t_R  g185(.A1(pi098), .A2(new_n403), .B1(new_n407), .B2(pi088), .C(new_n405), .Y(new_n408));
  OR5x1_ASAP7_75t_R    g186(.A(new_n408), .B(new_n385), .C(new_n380), .D(new_n377), .E(new_n391), .Y(new_n409));
  AO22x1_ASAP7_75t_R   g187(.A1(new_n275), .A2(pi125), .B1(pi124), .B2(new_n273), .Y(new_n410));
  AO221x2_ASAP7_75t_R  g188(.A1(pi126), .A2(new_n277), .B1(new_n279), .B2(pi127), .C(new_n410), .Y(new_n411));
  NOR2x1_ASAP7_75t_R   g189(.A(pi111), .B(new_n411), .Y(new_n412));
  AO21x1_ASAP7_75t_R   g190(.A1(pi111), .A2(new_n250), .B(new_n412), .Y(new_n413));
  XNOR2x2_ASAP7_75t_R  g191(.A(pi021), .B(new_n413), .Y(new_n414));
  NOR2x1_ASAP7_75t_R   g192(.A(pi129), .B(new_n249), .Y(new_n415));
  AO21x1_ASAP7_75t_R   g193(.A1(po06), .A2(new_n249), .B(new_n415), .Y(new_n416));
  XNOR2x2_ASAP7_75t_R  g194(.A(pi023), .B(new_n416), .Y(new_n417));
  NOR2x1_ASAP7_75t_R   g195(.A(pi112), .B(new_n249), .Y(new_n418));
  AO21x1_ASAP7_75t_R   g196(.A1(po27), .A2(new_n249), .B(new_n418), .Y(new_n419));
  XNOR2x2_ASAP7_75t_R  g197(.A(pi024), .B(new_n419), .Y(new_n420));
  NOR2x1_ASAP7_75t_R   g198(.A(pi108), .B(new_n379), .Y(new_n421));
  NOR2x1_ASAP7_75t_R   g199(.A(pi131), .B(po37), .Y(new_n422));
  AO21x1_ASAP7_75t_R   g200(.A1(pi131), .A2(new_n259), .B(new_n422), .Y(new_n423));
  AO21x1_ASAP7_75t_R   g201(.A1(pi106), .A2(new_n423), .B(new_n421), .Y(new_n424));
  NOR2x1_ASAP7_75t_R   g202(.A(pi131), .B(po41), .Y(new_n425));
  AO21x1_ASAP7_75t_R   g203(.A1(pi131), .A2(new_n253), .B(new_n425), .Y(new_n426));
  XOR2x2_ASAP7_75t_R   g204(.A(new_n426), .B(new_n247), .Y(new_n427));
  NAND2x1_ASAP7_75t_R  g205(.A(pi131), .B(pi132), .Y(new_n428));
  OA21x2_ASAP7_75t_R   g206(.A1(new_n325), .A2(pi131), .B(new_n428), .Y(new_n429));
  NOR2x1_ASAP7_75t_R   g207(.A(pi104), .B(new_n429), .Y(new_n430));
  OA21x2_ASAP7_75t_R   g208(.A1(new_n249), .A2(pi110), .B(pi109), .Y(new_n431));
  OAI21x1_ASAP7_75t_R  g209(.A1(pi111), .A2(new_n342), .B(new_n431), .Y(new_n432));
  NOR2x1_ASAP7_75t_R   g210(.A(pi131), .B(po40), .Y(new_n433));
  AO21x1_ASAP7_75t_R   g211(.A1(pi131), .A2(new_n252), .B(new_n433), .Y(new_n434));
  AO22x1_ASAP7_75t_R   g212(.A1(new_n434), .A2(pi099), .B1(pi104), .B2(new_n429), .Y(new_n435));
  OR5x1_ASAP7_75t_R    g213(.A(new_n427), .B(new_n432), .C(new_n435), .D(new_n424), .E(new_n430), .Y(new_n436));
  OAI22x1_ASAP7_75t_R  g214(.A1(pi088), .A2(new_n407), .B1(new_n398), .B2(pi101), .Y(new_n437));
  OAI22x1_ASAP7_75t_R  g215(.A1(new_n434), .A2(pi099), .B1(new_n423), .B2(pi106), .Y(new_n438));
  NAND2x1_ASAP7_75t_R  g216(.A(pi103), .B(new_n390), .Y(new_n439));
  OAI21x1_ASAP7_75t_R  g217(.A1(pi022), .A2(new_n387), .B(new_n439), .Y(new_n440));
  AO221x2_ASAP7_75t_R  g218(.A1(pi089), .A2(new_n382), .B1(new_n384), .B2(pi105), .C(new_n440), .Y(new_n441));
  OR4x2_ASAP7_75t_R    g219(.A(new_n436), .B(new_n437), .C(new_n438), .D(new_n441), .Y(new_n442));
  OR5x1_ASAP7_75t_R    g220(.A(new_n442), .B(new_n420), .C(new_n409), .D(new_n417), .E(new_n414), .Y(po53));
  AO21x1_ASAP7_75t_R   g221(.A1(new_n333), .A2(pi079), .B(pi050), .Y(new_n444));
  AND2x2_ASAP7_75t_R   g222(.A(new_n444), .B(po32), .Y(new_n445));
  AND3x1_ASAP7_75t_R   g223(.A(new_n239), .B(new_n240), .C(pi145), .Y(new_n446));
  AND3x1_ASAP7_75t_R   g224(.A(new_n239), .B(pi037), .C(pi146), .Y(new_n447));
  AND3x1_ASAP7_75t_R   g225(.A(new_n240), .B(pi147), .C(pi036), .Y(new_n448));
  AND3x1_ASAP7_75t_R   g226(.A(pi036), .B(pi037), .C(pi148), .Y(new_n449));
  OR4x2_ASAP7_75t_R    g227(.A(new_n446), .B(new_n447), .C(new_n448), .D(new_n449), .Y(new_n450));
  AND2x2_ASAP7_75t_R   g228(.A(new_n313), .B(new_n450), .Y(new_n451));
  NOR2x1_ASAP7_75t_R   g229(.A(new_n313), .B(new_n450), .Y(new_n452));
  NOR2x1_ASAP7_75t_R   g230(.A(new_n451), .B(new_n452), .Y(new_n453));
  XOR2x2_ASAP7_75t_R   g231(.A(new_n445), .B(new_n453), .Y(po55));
  XOR2x2_ASAP7_75t_R   g232(.A(new_n288), .B(po06), .Y(new_n455));
  XNOR2x2_ASAP7_75t_R  g233(.A(new_n342), .B(new_n455), .Y(new_n456));
  AO22x1_ASAP7_75t_R   g234(.A1(new_n275), .A2(pi150), .B1(pi149), .B2(new_n273), .Y(new_n457));
  AO221x2_ASAP7_75t_R  g235(.A1(pi151), .A2(new_n277), .B1(new_n279), .B2(pi152), .C(new_n457), .Y(new_n458));
  XOR2x2_ASAP7_75t_R   g236(.A(new_n401), .B(new_n458), .Y(new_n459));
  XOR2x2_ASAP7_75t_R   g237(.A(new_n294), .B(new_n396), .Y(new_n460));
  XOR2x2_ASAP7_75t_R   g238(.A(new_n460), .B(new_n411), .Y(new_n461));
  XOR2x2_ASAP7_75t_R   g239(.A(new_n461), .B(new_n374), .Y(new_n462));
  XOR2x2_ASAP7_75t_R   g240(.A(new_n462), .B(new_n459), .Y(new_n463));
  AOI21x1_ASAP7_75t_R  g241(.A1(new_n456), .A2(new_n463), .B(pi153), .Y(new_n464));
  OAI21x1_ASAP7_75t_R  g242(.A1(new_n456), .A2(new_n463), .B(new_n464), .Y(po56));
  XOR2x2_ASAP7_75t_R   g243(.A(po38), .B(po40), .Y(new_n466));
  XNOR2x2_ASAP7_75t_R  g244(.A(po39), .B(po41), .Y(new_n467));
  XOR2x2_ASAP7_75t_R   g245(.A(new_n467), .B(new_n466), .Y(new_n468));
  OA211x2_ASAP7_75t_R  g246(.A1(new_n452), .A2(new_n451), .B(new_n320), .C(new_n319), .Y(new_n469));
  AOI211x1_ASAP7_75t_R g247(.A1(new_n319), .A2(new_n320), .B(new_n452), .C(new_n451), .Y(new_n470));
  OR2x4_ASAP7_75t_R    g248(.A(new_n470), .B(new_n469), .Y(new_n471));
  OAI21x1_ASAP7_75t_R  g249(.A1(new_n470), .A2(new_n469), .B(new_n332), .Y(new_n472));
  OR3x1_ASAP7_75t_R    g250(.A(new_n469), .B(new_n470), .C(new_n332), .Y(new_n473));
  AOI21x1_ASAP7_75t_R  g251(.A1(new_n472), .A2(new_n473), .B(new_n338), .Y(new_n474));
  AO21x1_ASAP7_75t_R   g252(.A1(new_n338), .A2(new_n471), .B(new_n474), .Y(new_n475));
  XNOR2x2_ASAP7_75t_R  g253(.A(new_n468), .B(new_n475), .Y(new_n476));
  NAND2x1_ASAP7_75t_R  g254(.A(pi078), .B(new_n476), .Y(new_n477));
  OA21x2_ASAP7_75t_R   g255(.A1(pi078), .A2(new_n450), .B(new_n477), .Y(po57));
  AOI21x1_ASAP7_75t_R  g256(.A1(new_n472), .A2(new_n473), .B(po37), .Y(new_n479));
  AND3x1_ASAP7_75t_R   g257(.A(new_n473), .B(new_n472), .C(po37), .Y(new_n480));
  OR3x1_ASAP7_75t_R    g258(.A(new_n480), .B(new_n479), .C(po36), .Y(new_n481));
  OAI21x1_ASAP7_75t_R  g259(.A1(new_n479), .A2(new_n480), .B(po36), .Y(new_n482));
  NAND2x1_ASAP7_75t_R  g260(.A(new_n482), .B(new_n481), .Y(new_n483));
  AOI21x1_ASAP7_75t_R  g261(.A1(new_n468), .A2(new_n483), .B(pi153), .Y(new_n484));
  OAI21x1_ASAP7_75t_R  g262(.A1(new_n468), .A2(new_n483), .B(new_n484), .Y(po59));
  AND2x2_ASAP7_75t_R   g263(.A(new_n294), .B(new_n260), .Y(new_n486));
  AND5x1_ASAP7_75t_R   g264(.A(new_n276), .B(new_n280), .C(new_n278), .D(new_n274), .E(pi154), .Y(new_n487));
  AND4x2_ASAP7_75t_R   g265(.A(po06), .B(new_n294), .C(pi154), .D(new_n260), .Y(new_n488));
  INVx1_ASAP7_75t_R    g266(.A(new_n488), .Y(new_n489));
  AND3x1_ASAP7_75t_R   g267(.A(new_n486), .B(new_n487), .C(pi022), .Y(new_n490));
  AOI21x1_ASAP7_75t_R  g268(.A1(pi105), .A2(new_n489), .B(new_n490), .Y(new_n491));
  NOR2x1_ASAP7_75t_R   g269(.A(po36), .B(new_n491), .Y(new_n492));
  AND3x1_ASAP7_75t_R   g270(.A(new_n486), .B(new_n487), .C(pi021), .Y(new_n493));
  AO21x1_ASAP7_75t_R   g271(.A1(pi108), .A2(new_n489), .B(new_n493), .Y(new_n494));
  AO21x1_ASAP7_75t_R   g272(.A1(new_n488), .A2(pi102), .B(new_n313), .Y(new_n495));
  AO21x1_ASAP7_75t_R   g273(.A1(pi088), .A2(new_n489), .B(new_n495), .Y(new_n496));
  AND3x1_ASAP7_75t_R   g274(.A(new_n486), .B(new_n487), .C(pi098), .Y(new_n497));
  AO21x1_ASAP7_75t_R   g275(.A1(pi089), .A2(new_n489), .B(new_n497), .Y(new_n498));
  MAJx2_ASAP7_75t_R    g276(.A(new_n496), .B(new_n332), .C(new_n498), .Y(new_n499));
  MAJx2_ASAP7_75t_R    g277(.A(new_n499), .B(new_n494), .C(new_n322), .Y(new_n500));
  AND3x1_ASAP7_75t_R   g278(.A(new_n486), .B(new_n487), .C(pi023), .Y(new_n501));
  AOI21x1_ASAP7_75t_R  g279(.A1(pi106), .A2(new_n489), .B(new_n501), .Y(new_n502));
  AO32x1_ASAP7_75t_R   g280(.A1(pi156), .A2(new_n502), .A3(po37), .B1(po36), .B2(new_n491), .Y(new_n503));
  INVx1_ASAP7_75t_R    g281(.A(new_n503), .Y(new_n504));
  OAI21x1_ASAP7_75t_R  g282(.A1(new_n492), .A2(new_n500), .B(new_n504), .Y(new_n505));
  OR3x1_ASAP7_75t_R    g283(.A(new_n502), .B(po37), .C(new_n261), .Y(new_n506));
  AND3x1_ASAP7_75t_R   g284(.A(new_n486), .B(new_n487), .C(pi024), .Y(new_n507));
  AOI21x1_ASAP7_75t_R  g285(.A1(pi103), .A2(new_n489), .B(new_n507), .Y(new_n508));
  AO32x1_ASAP7_75t_R   g286(.A1(pi156), .A2(po38), .A3(new_n508), .B1(new_n506), .B2(new_n505), .Y(new_n509));
  AND3x1_ASAP7_75t_R   g287(.A(new_n489), .B(pi104), .C(pi099), .Y(new_n510));
  AND3x1_ASAP7_75t_R   g288(.A(new_n488), .B(po40), .C(po39), .Y(new_n511));
  OR3x1_ASAP7_75t_R    g289(.A(new_n510), .B(new_n511), .C(new_n261), .Y(new_n512));
  OR3x1_ASAP7_75t_R    g290(.A(new_n508), .B(po38), .C(new_n261), .Y(new_n513));
  AOI21x1_ASAP7_75t_R  g291(.A1(pi099), .A2(pi104), .B(new_n261), .Y(new_n514));
  AO32x1_ASAP7_75t_R   g292(.A1(new_n513), .A2(new_n509), .A3(new_n512), .B1(new_n514), .B2(new_n489), .Y(new_n515));
  OA21x2_ASAP7_75t_R   g293(.A1(po28), .A2(pi155), .B(new_n487), .Y(new_n516));
  INVx1_ASAP7_75t_R    g294(.A(new_n516), .Y(new_n517));
  AND3x1_ASAP7_75t_R   g295(.A(new_n516), .B(new_n396), .C(pi101), .Y(new_n518));
  NOR3x1_ASAP7_75t_R   g296(.A(new_n517), .B(new_n396), .C(pi101), .Y(new_n519));
  AND3x1_ASAP7_75t_R   g297(.A(new_n516), .B(new_n402), .C(pi098), .Y(new_n520));
  AND3x1_ASAP7_75t_R   g298(.A(new_n516), .B(new_n401), .C(new_n246), .Y(new_n521));
  OR4x2_ASAP7_75t_R    g299(.A(new_n519), .B(new_n520), .C(new_n521), .D(new_n518), .Y(new_n522));
  INVx1_ASAP7_75t_R    g300(.A(new_n522), .Y(new_n523));
  AND3x1_ASAP7_75t_R   g301(.A(new_n516), .B(new_n375), .C(new_n248), .Y(new_n524));
  INVx1_ASAP7_75t_R    g302(.A(new_n524), .Y(new_n525));
  AND2x2_ASAP7_75t_R   g303(.A(new_n374), .B(pi102), .Y(new_n526));
  AO21x1_ASAP7_75t_R   g304(.A1(new_n516), .A2(new_n526), .B(new_n524), .Y(new_n527));
  INVx1_ASAP7_75t_R    g305(.A(new_n527), .Y(new_n528));
  XOR2x2_ASAP7_75t_R   g306(.A(po41), .B(new_n247), .Y(new_n529));
  OA211x2_ASAP7_75t_R  g307(.A1(new_n517), .A2(new_n529), .B(new_n523), .C(new_n528), .Y(new_n530));
  AND5x1_ASAP7_75t_R   g308(.A(new_n523), .B(new_n528), .C(new_n247), .D(po41), .E(new_n516), .Y(new_n531));
  OR4x2_ASAP7_75t_R    g309(.A(new_n517), .B(new_n526), .C(pi101), .D(new_n396), .Y(new_n532));
  AO21x1_ASAP7_75t_R   g310(.A1(new_n532), .A2(new_n525), .B(new_n520), .Y(new_n533));
  INVx1_ASAP7_75t_R    g311(.A(new_n533), .Y(new_n534));
  OR3x1_ASAP7_75t_R    g312(.A(new_n531), .B(new_n534), .C(new_n521), .Y(new_n535));
  AOI21x1_ASAP7_75t_R  g313(.A1(new_n530), .A2(new_n515), .B(new_n535), .Y(po60));
  OR3x1_ASAP7_75t_R    g314(.A(po51), .B(po52), .C(po05), .Y(new_n537));
  NOR2x1_ASAP7_75t_R   g315(.A(new_n537), .B(new_n354), .Y(new_n538));
  NAND3x1_ASAP7_75t_R  g316(.A(po59), .B(new_n538), .C(po56), .Y(po62));
  assign               po61 = 1'b0;
  NAND2x1_ASAP7_75t_R  g317(.A(new_n267), .B(new_n269), .Y(po04));
  INVx1_ASAP7_75t_R    g318(.A(pi018), .Y(po08));
  INVx1_ASAP7_75t_R    g319(.A(pi018), .Y(po09));
  INVx1_ASAP7_75t_R    g320(.A(pi019), .Y(po11));
  INVx1_ASAP7_75t_R    g321(.A(pi020), .Y(po13));
  INVx1_ASAP7_75t_R    g322(.A(pi020), .Y(po14));
  BUFx2_ASAP7_75t_R    g323(.A(pi018), .Y(po25));
  AO21x1_ASAP7_75t_R   g324(.A1(new_n244), .A2(new_n333), .B(new_n330), .Y(po43));
  AO21x1_ASAP7_75t_R   g325(.A1(new_n244), .A2(po35), .B(new_n335), .Y(po45));
  OA21x2_ASAP7_75t_R   g326(.A1(new_n338), .A2(new_n244), .B(new_n339), .Y(po48));
  OR5x1_ASAP7_75t_R    g327(.A(new_n442), .B(new_n420), .C(new_n409), .D(new_n417), .E(new_n414), .Y(po54));
  OA21x2_ASAP7_75t_R   g328(.A1(pi078), .A2(new_n450), .B(new_n477), .Y(po58));
  NAND3x1_ASAP7_75t_R  g329(.A(po59), .B(new_n538), .C(po56), .Y(po63));
endmodule


