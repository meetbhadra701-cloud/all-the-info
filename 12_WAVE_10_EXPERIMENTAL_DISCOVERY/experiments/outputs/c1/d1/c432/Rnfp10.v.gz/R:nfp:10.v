// Benchmark "/w/experiments/inputs/c1/c2/c432" written by ABC on Fri Sep 25 10:26:25 2026

module \/w/experiments/inputs/c1/c2/c432  ( 
    pi00, pi01, pi02, pi03, pi04, pi05, pi06, pi07, pi08, pi09, pi10, pi11,
    pi12, pi13, pi14, pi15, pi16, pi17, pi18, pi19, pi20, pi21, pi22, pi23,
    pi24, pi25, pi26, pi27, pi28, pi29, pi30, pi31, pi32, pi33, pi34, pi35,
    po0, po1, po2, po3, po4, po5, po6  );
  input  pi00, pi01, pi02, pi03, pi04, pi05, pi06, pi07, pi08, pi09,
    pi10, pi11, pi12, pi13, pi14, pi15, pi16, pi17, pi18, pi19, pi20, pi21,
    pi22, pi23, pi24, pi25, pi26, pi27, pi28, pi29, pi30, pi31, pi32, pi33,
    pi34, pi35;
  output po0, po1, po2, po3, po4, po5, po6;
  wire new_n44, new_n45, new_n46, new_n47, new_n48, new_n49, new_n50,
    new_n51, new_n52, new_n53, new_n54, new_n55, new_n56, new_n57, new_n58,
    new_n59, new_n60, new_n61, new_n62, new_n63, new_n64, new_n65, new_n66,
    new_n67, new_n68, new_n69, new_n70, new_n71, new_n72, new_n73, new_n74,
    new_n75, new_n77, new_n78, new_n79, new_n80, new_n81, new_n82, new_n83,
    new_n84, new_n85, new_n86, new_n87, new_n88, new_n89, new_n90, new_n91,
    new_n92, new_n93, new_n94, new_n95, new_n96, new_n97, new_n98, new_n99,
    new_n100, new_n101, new_n102, new_n103, new_n105, new_n106, new_n107,
    new_n108, new_n109, new_n110, new_n111, new_n112, new_n113, new_n114,
    new_n115, new_n116, new_n117, new_n118, new_n119, new_n120, new_n121,
    new_n122, new_n123, new_n124, new_n125, new_n126, new_n127, new_n128,
    new_n129, new_n130, new_n131, new_n132, new_n133, new_n135, new_n136,
    new_n137, new_n138, new_n139, new_n140, new_n141, new_n143, new_n144,
    new_n145, new_n146, new_n147, new_n148, new_n149, new_n151, new_n153,
    new_n154;
  INVx1_ASAP7_75t_R    g000(.A(pi00), .Y(new_n44));
  INVx1_ASAP7_75t_R    g001(.A(pi02), .Y(new_n45));
  INVx1_ASAP7_75t_R    g002(.A(pi04), .Y(new_n46));
  INVx1_ASAP7_75t_R    g003(.A(pi06), .Y(new_n47));
  INVx1_ASAP7_75t_R    g004(.A(pi07), .Y(new_n48));
  INVx1_ASAP7_75t_R    g005(.A(pi08), .Y(new_n49));
  INVx1_ASAP7_75t_R    g006(.A(pi10), .Y(new_n50));
  INVx1_ASAP7_75t_R    g007(.A(pi11), .Y(new_n51));
  INVx1_ASAP7_75t_R    g008(.A(pi12), .Y(new_n52));
  INVx1_ASAP7_75t_R    g009(.A(pi14), .Y(new_n53));
  INVx1_ASAP7_75t_R    g010(.A(pi16), .Y(new_n54));
  INVx1_ASAP7_75t_R    g011(.A(pi18), .Y(new_n55));
  INVx1_ASAP7_75t_R    g012(.A(pi19), .Y(new_n56));
  INVx1_ASAP7_75t_R    g013(.A(pi20), .Y(new_n57));
  INVx1_ASAP7_75t_R    g014(.A(pi21), .Y(new_n58));
  INVx1_ASAP7_75t_R    g015(.A(pi23), .Y(new_n59));
  INVx1_ASAP7_75t_R    g016(.A(pi24), .Y(new_n60));
  INVx1_ASAP7_75t_R    g017(.A(pi25), .Y(new_n61));
  INVx1_ASAP7_75t_R    g018(.A(pi26), .Y(new_n62));
  INVx1_ASAP7_75t_R    g019(.A(pi29), .Y(new_n63));
  INVx1_ASAP7_75t_R    g020(.A(pi30), .Y(new_n64));
  INVx1_ASAP7_75t_R    g021(.A(pi31), .Y(new_n65));
  INVx1_ASAP7_75t_R    g022(.A(pi32), .Y(new_n66));
  INVx1_ASAP7_75t_R    g023(.A(pi33), .Y(new_n67));
  INVx1_ASAP7_75t_R    g024(.A(pi34), .Y(new_n68));
  NAND2x1_ASAP7_75t_R  g025(.A(pi05), .B(new_n46), .Y(new_n69));
  AOI22x1_ASAP7_75t_R  g026(.A1(new_n47), .A2(pi07), .B1(new_n50), .B2(pi11), .Y(new_n70));
  AOI22x1_ASAP7_75t_R  g027(.A1(new_n52), .A2(pi13), .B1(new_n54), .B2(pi17), .Y(new_n71));
  AOI22x1_ASAP7_75t_R  g028(.A1(new_n44), .A2(pi01), .B1(new_n53), .B2(pi15), .Y(new_n72));
  AOI22x1_ASAP7_75t_R  g029(.A1(new_n45), .A2(pi03), .B1(new_n49), .B2(pi09), .Y(new_n73));
  AND4x2_ASAP7_75t_R   g030(.A(new_n70), .B(new_n71), .C(new_n72), .D(new_n73), .Y(new_n74));
  AND5x1_ASAP7_75t_R   g031(.A(new_n70), .B(new_n71), .C(new_n72), .D(new_n73), .E(new_n69), .Y(new_n75));
  INVx1_ASAP7_75t_R    g032(.A(new_n75), .Y(po0));
  OAI21x1_ASAP7_75t_R  g033(.A1(new_n49), .A2(new_n75), .B(pi09), .Y(new_n77));
  NOR2x1_ASAP7_75t_R   g034(.A(pi22), .B(new_n77), .Y(new_n78));
  OR2x4_ASAP7_75t_R    g035(.A(pi22), .B(new_n77), .Y(new_n79));
  AOI21x1_ASAP7_75t_R  g036(.A1(new_n69), .A2(new_n74), .B(new_n47), .Y(new_n80));
  AO21x1_ASAP7_75t_R   g037(.A1(po0), .A2(pi06), .B(new_n48), .Y(new_n81));
  OA211x2_ASAP7_75t_R  g038(.A1(new_n75), .A2(new_n47), .B(pi07), .C(new_n58), .Y(new_n82));
  AOI21x1_ASAP7_75t_R  g039(.A1(new_n69), .A2(new_n74), .B(new_n50), .Y(new_n83));
  AO21x1_ASAP7_75t_R   g040(.A1(po0), .A2(pi10), .B(new_n51), .Y(new_n84));
  OA211x2_ASAP7_75t_R  g041(.A1(new_n75), .A2(new_n50), .B(pi11), .C(new_n59), .Y(new_n85));
  OA33x2_ASAP7_75t_R   g042(.A1(new_n48), .A2(pi21), .A3(new_n80), .B1(new_n83), .B2(pi23), .B3(new_n51), .Y(new_n86));
  OAI21x1_ASAP7_75t_R  g043(.A1(new_n54), .A2(new_n75), .B(pi17), .Y(new_n87));
  OA211x2_ASAP7_75t_R  g044(.A1(new_n75), .A2(new_n54), .B(pi17), .C(new_n62), .Y(new_n88));
  OAI21x1_ASAP7_75t_R  g045(.A1(new_n44), .A2(new_n75), .B(pi01), .Y(new_n89));
  OA211x2_ASAP7_75t_R  g046(.A1(new_n75), .A2(new_n44), .B(pi01), .C(new_n55), .Y(new_n90));
  OA221x2_ASAP7_75t_R  g047(.A1(pi26), .A2(new_n87), .B1(new_n89), .B2(pi18), .C(new_n86), .Y(new_n91));
  OR4x2_ASAP7_75t_R    g048(.A(new_n82), .B(new_n85), .C(new_n88), .D(new_n90), .Y(new_n92));
  OAI21x1_ASAP7_75t_R  g049(.A1(new_n52), .A2(new_n75), .B(pi13), .Y(new_n93));
  OA211x2_ASAP7_75t_R  g050(.A1(new_n75), .A2(new_n52), .B(pi13), .C(new_n60), .Y(new_n94));
  OA21x2_ASAP7_75t_R   g051(.A1(new_n74), .A2(new_n46), .B(pi05), .Y(new_n95));
  OA211x2_ASAP7_75t_R  g052(.A1(new_n74), .A2(new_n46), .B(pi05), .C(new_n57), .Y(new_n96));
  OAI21x1_ASAP7_75t_R  g053(.A1(new_n45), .A2(new_n75), .B(pi03), .Y(new_n97));
  OA211x2_ASAP7_75t_R  g054(.A1(new_n75), .A2(new_n45), .B(pi03), .C(new_n56), .Y(new_n98));
  OAI21x1_ASAP7_75t_R  g055(.A1(new_n53), .A2(new_n75), .B(pi15), .Y(new_n99));
  OA211x2_ASAP7_75t_R  g056(.A1(new_n75), .A2(new_n53), .B(pi15), .C(new_n61), .Y(new_n100));
  OAI22x1_ASAP7_75t_R  g057(.A1(new_n99), .A2(pi25), .B1(new_n97), .B2(pi19), .Y(new_n101));
  AOI211x1_ASAP7_75t_R g058(.A1(new_n57), .A2(new_n95), .B(new_n101), .C(new_n94), .Y(new_n102));
  OR4x2_ASAP7_75t_R    g059(.A(new_n94), .B(new_n98), .C(new_n100), .D(new_n96), .Y(new_n103));
  OR3x1_ASAP7_75t_R    g060(.A(new_n92), .B(new_n103), .C(new_n78), .Y(po1));
  AO21x1_ASAP7_75t_R   g061(.A1(po1), .A2(pi18), .B(new_n89), .Y(new_n105));
  INVx1_ASAP7_75t_R    g062(.A(new_n105), .Y(new_n106));
  AOI211x1_ASAP7_75t_R g063(.A1(po1), .A2(pi18), .B(pi27), .C(new_n89), .Y(new_n107));
  INVx1_ASAP7_75t_R    g064(.A(new_n107), .Y(new_n108));
  OA31x2_ASAP7_75t_R   g065(.A1(new_n103), .A2(new_n92), .A3(new_n78), .B1(pi25), .Y(new_n109));
  NOR2x1_ASAP7_75t_R   g066(.A(new_n99), .B(new_n109), .Y(new_n110));
  OA31x2_ASAP7_75t_R   g067(.A1(new_n103), .A2(new_n92), .A3(new_n78), .B1(pi26), .Y(new_n111));
  OA33x2_ASAP7_75t_R   g068(.A1(pi34), .A2(new_n99), .A3(new_n109), .B1(new_n111), .B2(new_n87), .B3(pi35), .Y(new_n112));
  OA31x2_ASAP7_75t_R   g069(.A1(new_n103), .A2(new_n92), .A3(new_n78), .B1(pi21), .Y(new_n113));
  NOR2x1_ASAP7_75t_R   g070(.A(new_n81), .B(new_n113), .Y(new_n114));
  OA31x2_ASAP7_75t_R   g071(.A1(new_n103), .A2(new_n92), .A3(new_n78), .B1(pi23), .Y(new_n115));
  NOR2x1_ASAP7_75t_R   g072(.A(new_n84), .B(new_n115), .Y(new_n116));
  OA33x2_ASAP7_75t_R   g073(.A1(pi30), .A2(new_n81), .A3(new_n113), .B1(new_n115), .B2(new_n84), .B3(pi32), .Y(new_n117));
  NAND2x1_ASAP7_75t_R  g074(.A(new_n112), .B(new_n117), .Y(new_n118));
  OA31x2_ASAP7_75t_R   g075(.A1(new_n103), .A2(new_n92), .A3(new_n78), .B1(pi24), .Y(new_n119));
  NOR2x1_ASAP7_75t_R   g076(.A(new_n93), .B(new_n119), .Y(new_n120));
  OA21x2_ASAP7_75t_R   g077(.A1(new_n92), .A2(new_n103), .B(pi22), .Y(new_n121));
  NOR2x1_ASAP7_75t_R   g078(.A(new_n77), .B(new_n121), .Y(new_n122));
  OA33x2_ASAP7_75t_R   g079(.A1(pi31), .A2(new_n77), .A3(new_n121), .B1(new_n93), .B2(new_n119), .B3(pi33), .Y(new_n123));
  OA31x2_ASAP7_75t_R   g080(.A1(new_n103), .A2(new_n92), .A3(new_n78), .B1(pi19), .Y(new_n124));
  AND4x2_ASAP7_75t_R   g081(.A(new_n102), .B(new_n91), .C(new_n79), .D(new_n56), .Y(new_n125));
  OR2x4_ASAP7_75t_R    g082(.A(pi28), .B(new_n97), .Y(new_n126));
  OA31x2_ASAP7_75t_R   g083(.A1(new_n103), .A2(new_n92), .A3(new_n78), .B1(pi20), .Y(new_n127));
  NAND2x1_ASAP7_75t_R  g084(.A(pi20), .B(po1), .Y(new_n128));
  AND4x2_ASAP7_75t_R   g085(.A(new_n102), .B(new_n91), .C(new_n79), .D(new_n57), .Y(new_n129));
  NAND2x1_ASAP7_75t_R  g086(.A(new_n63), .B(new_n95), .Y(new_n130));
  OA33x2_ASAP7_75t_R   g087(.A1(new_n127), .A2(new_n130), .A3(new_n129), .B1(new_n125), .B2(new_n126), .B3(new_n124), .Y(new_n131));
  NAND2x1_ASAP7_75t_R  g088(.A(new_n123), .B(new_n131), .Y(new_n132));
  AND5x1_ASAP7_75t_R   g089(.A(new_n108), .B(new_n112), .C(new_n117), .D(new_n123), .E(new_n131), .Y(new_n133));
  INVx1_ASAP7_75t_R    g090(.A(new_n133), .Y(po2));
  AND2x2_ASAP7_75t_R   g091(.A(po2), .B(pi35), .Y(new_n135));
  OA21x2_ASAP7_75t_R   g092(.A1(new_n133), .A2(new_n67), .B(new_n120), .Y(new_n136));
  OAI21x1_ASAP7_75t_R  g093(.A1(new_n67), .A2(new_n133), .B(new_n120), .Y(new_n137));
  OA21x2_ASAP7_75t_R   g094(.A1(new_n133), .A2(new_n68), .B(new_n110), .Y(new_n138));
  OA21x2_ASAP7_75t_R   g095(.A1(new_n133), .A2(new_n66), .B(new_n116), .Y(new_n139));
  OAI21x1_ASAP7_75t_R  g096(.A1(new_n66), .A2(new_n133), .B(new_n116), .Y(new_n140));
  OA21x2_ASAP7_75t_R   g097(.A1(new_n133), .A2(new_n65), .B(new_n122), .Y(new_n141));
  OR4x2_ASAP7_75t_R    g098(.A(new_n136), .B(new_n138), .C(new_n139), .D(new_n141), .Y(po4));
  OAI21x1_ASAP7_75t_R  g099(.A1(new_n64), .A2(new_n133), .B(new_n114), .Y(new_n143));
  AND2x2_ASAP7_75t_R   g100(.A(new_n128), .B(new_n95), .Y(new_n144));
  OAI21x1_ASAP7_75t_R  g101(.A1(new_n63), .A2(new_n133), .B(new_n144), .Y(new_n145));
  NAND2x1_ASAP7_75t_R  g102(.A(new_n143), .B(new_n145), .Y(new_n146));
  AOI211x1_ASAP7_75t_R g103(.A1(po2), .A2(pi28), .B(new_n97), .C(new_n124), .Y(new_n147));
  OAI21x1_ASAP7_75t_R  g104(.A1(new_n118), .A2(new_n132), .B(pi27), .Y(new_n148));
  AO21x1_ASAP7_75t_R   g105(.A1(new_n106), .A2(new_n148), .B(new_n147), .Y(new_n149));
  OA33x2_ASAP7_75t_R   g106(.A1(new_n87), .A2(new_n111), .A3(new_n135), .B1(po4), .B2(new_n149), .B3(new_n146), .Y(po3));
  AOI211x1_ASAP7_75t_R g107(.A1(new_n143), .A2(new_n145), .B(new_n139), .C(new_n141), .Y(new_n151));
  OR3x1_ASAP7_75t_R    g108(.A(new_n151), .B(new_n138), .C(new_n136), .Y(po5));
  OAI21x1_ASAP7_75t_R  g109(.A1(new_n143), .A2(new_n141), .B(new_n140), .Y(new_n153));
  AO21x1_ASAP7_75t_R   g110(.A1(new_n145), .A2(new_n147), .B(new_n153), .Y(new_n154));
  AO21x1_ASAP7_75t_R   g111(.A1(new_n154), .A2(new_n137), .B(new_n138), .Y(po6));
endmodule


