// Benchmark "/w/experiments/inputs/c1/c2/c432" written by ABC on Fri Sep 25 10:26:25 2026

module \/w/experiments/inputs/c1/c2/c432  ( 
    pi00, pi01, pi02, pi03, pi04, pi05, pi06, pi07, pi08, pi09, pi10, pi11,
    pi12, pi13, pi14, pi15, pi16, pi17, pi18, pi19, pi20, pi21, pi22, pi23,
    pi24, pi25, pi26, pi27, pi28, pi29, pi30, pi31, pi32, pi33, pi34, pi35,
    po0, po1, po2, po3, po4, po5, po6  );
  input  pi00, pi01, pi02, pi03, pi04, pi05, pi06, pi07, pi08, pi09,
    pi10, pi11, pi12, pi13, pi14, pi15, pi16, pi17, pi18, pi19, pi20, pi21,
    pi22, pi23, pi24, pi25, pi26, pi27, pi28, pi29, pi30, pi31, pi32, pi33,
    pi34, pi35;
  output po0, po1, po2, po3, po4, po5, po6;
  wire new_n44, new_n45, new_n46, new_n47, new_n48, new_n49, new_n50,
    new_n51, new_n52, new_n53, new_n54, new_n55, new_n56, new_n57, new_n58,
    new_n59, new_n60, new_n61, new_n62, new_n63, new_n64, new_n65, new_n66,
    new_n67, new_n68, new_n69, new_n70, new_n71, new_n72, new_n73, new_n74,
    new_n76, new_n77, new_n78, new_n79, new_n80, new_n81, new_n82, new_n83,
    new_n84, new_n85, new_n86, new_n87, new_n88, new_n89, new_n90, new_n91,
    new_n92, new_n93, new_n94, new_n96, new_n97, new_n98, new_n99,
    new_n100, new_n101, new_n102, new_n103, new_n104, new_n105, new_n106,
    new_n107, new_n108, new_n109, new_n110, new_n111, new_n112, new_n113,
    new_n114, new_n115, new_n116, new_n117, new_n119, new_n120, new_n121,
    new_n122, new_n123, new_n124, new_n125, new_n127, new_n128, new_n129,
    new_n130, new_n131, new_n132, new_n134, new_n136, new_n137;
  INVx1_ASAP7_75t_R    g00(.A(pi00), .Y(new_n44));
  INVx1_ASAP7_75t_R    g01(.A(pi01), .Y(new_n45));
  INVx1_ASAP7_75t_R    g02(.A(pi02), .Y(new_n46));
  INVx1_ASAP7_75t_R    g03(.A(pi04), .Y(new_n47));
  INVx1_ASAP7_75t_R    g04(.A(pi06), .Y(new_n48));
  INVx1_ASAP7_75t_R    g05(.A(pi08), .Y(new_n49));
  INVx1_ASAP7_75t_R    g06(.A(pi10), .Y(new_n50));
  INVx1_ASAP7_75t_R    g07(.A(pi12), .Y(new_n51));
  INVx1_ASAP7_75t_R    g08(.A(pi14), .Y(new_n52));
  INVx1_ASAP7_75t_R    g09(.A(pi16), .Y(new_n53));
  INVx1_ASAP7_75t_R    g10(.A(pi18), .Y(new_n54));
  INVx1_ASAP7_75t_R    g11(.A(pi19), .Y(new_n55));
  INVx1_ASAP7_75t_R    g12(.A(pi20), .Y(new_n56));
  INVx1_ASAP7_75t_R    g13(.A(pi21), .Y(new_n57));
  INVx1_ASAP7_75t_R    g14(.A(pi22), .Y(new_n58));
  INVx1_ASAP7_75t_R    g15(.A(pi23), .Y(new_n59));
  INVx1_ASAP7_75t_R    g16(.A(pi24), .Y(new_n60));
  INVx1_ASAP7_75t_R    g17(.A(pi25), .Y(new_n61));
  INVx1_ASAP7_75t_R    g18(.A(pi26), .Y(new_n62));
  INVx1_ASAP7_75t_R    g19(.A(pi28), .Y(new_n63));
  INVx1_ASAP7_75t_R    g20(.A(pi30), .Y(new_n64));
  INVx1_ASAP7_75t_R    g21(.A(pi32), .Y(new_n65));
  INVx1_ASAP7_75t_R    g22(.A(pi34), .Y(new_n66));
  INVx1_ASAP7_75t_R    g23(.A(pi35), .Y(new_n67));
  NAND2x1_ASAP7_75t_R  g24(.A(pi05), .B(new_n47), .Y(new_n68));
  AOI22x1_ASAP7_75t_R  g25(.A1(new_n48), .A2(pi07), .B1(new_n50), .B2(pi11), .Y(new_n69));
  AOI22x1_ASAP7_75t_R  g26(.A1(new_n51), .A2(pi13), .B1(new_n53), .B2(pi17), .Y(new_n70));
  AOI22x1_ASAP7_75t_R  g27(.A1(new_n44), .A2(pi01), .B1(new_n52), .B2(pi15), .Y(new_n71));
  AOI22x1_ASAP7_75t_R  g28(.A1(new_n46), .A2(pi03), .B1(new_n49), .B2(pi09), .Y(new_n72));
  AND4x2_ASAP7_75t_R   g29(.A(new_n69), .B(new_n70), .C(new_n71), .D(new_n72), .Y(new_n73));
  AND5x1_ASAP7_75t_R   g30(.A(new_n69), .B(new_n70), .C(new_n71), .D(new_n72), .E(new_n68), .Y(new_n74));
  INVx1_ASAP7_75t_R    g31(.A(new_n74), .Y(po0));
  OA21x2_ASAP7_75t_R   g32(.A1(new_n74), .A2(new_n49), .B(pi09), .Y(new_n76));
  OA21x2_ASAP7_75t_R   g33(.A1(new_n74), .A2(new_n48), .B(pi07), .Y(new_n77));
  OA211x2_ASAP7_75t_R  g34(.A1(new_n74), .A2(new_n48), .B(pi07), .C(new_n57), .Y(new_n78));
  OA21x2_ASAP7_75t_R   g35(.A1(new_n74), .A2(new_n50), .B(pi11), .Y(new_n79));
  OA211x2_ASAP7_75t_R  g36(.A1(new_n74), .A2(new_n50), .B(pi11), .C(new_n59), .Y(new_n80));
  OA21x2_ASAP7_75t_R   g37(.A1(new_n74), .A2(new_n53), .B(pi17), .Y(new_n81));
  OA211x2_ASAP7_75t_R  g38(.A1(new_n74), .A2(new_n53), .B(pi17), .C(new_n62), .Y(new_n82));
  OA211x2_ASAP7_75t_R  g39(.A1(new_n74), .A2(new_n44), .B(pi01), .C(new_n54), .Y(new_n83));
  OR4x2_ASAP7_75t_R    g40(.A(new_n78), .B(new_n80), .C(new_n82), .D(new_n83), .Y(new_n84));
  OA21x2_ASAP7_75t_R   g41(.A1(new_n74), .A2(new_n51), .B(pi13), .Y(new_n85));
  OA211x2_ASAP7_75t_R  g42(.A1(new_n74), .A2(new_n51), .B(pi13), .C(new_n60), .Y(new_n86));
  OAI21x1_ASAP7_75t_R  g43(.A1(new_n47), .A2(new_n73), .B(pi05), .Y(new_n87));
  OA211x2_ASAP7_75t_R  g44(.A1(new_n73), .A2(new_n47), .B(pi05), .C(new_n56), .Y(new_n88));
  OA21x2_ASAP7_75t_R   g45(.A1(new_n74), .A2(new_n46), .B(pi03), .Y(new_n89));
  OA211x2_ASAP7_75t_R  g46(.A1(new_n74), .A2(new_n46), .B(pi03), .C(new_n55), .Y(new_n90));
  OA21x2_ASAP7_75t_R   g47(.A1(new_n74), .A2(new_n52), .B(pi15), .Y(new_n91));
  OA211x2_ASAP7_75t_R  g48(.A1(new_n74), .A2(new_n52), .B(pi15), .C(new_n61), .Y(new_n92));
  OR4x2_ASAP7_75t_R    g49(.A(new_n86), .B(new_n90), .C(new_n92), .D(new_n88), .Y(new_n93));
  AOI211x1_ASAP7_75t_R g50(.A1(new_n58), .A2(new_n76), .B(new_n84), .C(new_n93), .Y(new_n94));
  INVx1_ASAP7_75t_R    g51(.A(new_n94), .Y(po1));
  AO221x2_ASAP7_75t_R  g52(.A1(pi00), .A2(po0), .B1(pi18), .B2(po1), .C(new_n45), .Y(new_n96));
  INVx1_ASAP7_75t_R    g53(.A(new_n96), .Y(new_n97));
  OA21x2_ASAP7_75t_R   g54(.A1(new_n94), .A2(new_n61), .B(new_n91), .Y(new_n98));
  OA21x2_ASAP7_75t_R   g55(.A1(new_n94), .A2(new_n62), .B(new_n81), .Y(new_n99));
  AOI22x1_ASAP7_75t_R  g56(.A1(new_n99), .A2(new_n67), .B1(new_n98), .B2(new_n66), .Y(new_n100));
  OA21x2_ASAP7_75t_R   g57(.A1(new_n94), .A2(new_n57), .B(new_n77), .Y(new_n101));
  OA21x2_ASAP7_75t_R   g58(.A1(new_n94), .A2(new_n59), .B(new_n79), .Y(new_n102));
  AOI22x1_ASAP7_75t_R  g59(.A1(new_n102), .A2(new_n65), .B1(new_n101), .B2(new_n64), .Y(new_n103));
  OA21x2_ASAP7_75t_R   g60(.A1(new_n94), .A2(new_n60), .B(new_n85), .Y(new_n104));
  INVx1_ASAP7_75t_R    g61(.A(new_n104), .Y(new_n105));
  OAI21x1_ASAP7_75t_R  g62(.A1(new_n93), .A2(new_n84), .B(pi22), .Y(new_n106));
  NAND2x1_ASAP7_75t_R  g63(.A(new_n76), .B(new_n106), .Y(new_n107));
  OA22x2_ASAP7_75t_R   g64(.A1(pi31), .A2(new_n107), .B1(new_n105), .B2(pi33), .Y(new_n108));
  NAND2x1_ASAP7_75t_R  g65(.A(pi19), .B(po1), .Y(new_n109));
  AND2x2_ASAP7_75t_R   g66(.A(new_n89), .B(new_n63), .Y(new_n110));
  OA21x2_ASAP7_75t_R   g67(.A1(po1), .A2(pi19), .B(new_n110), .Y(new_n111));
  NAND2x1_ASAP7_75t_R  g68(.A(pi20), .B(po1), .Y(new_n112));
  AOI211x1_ASAP7_75t_R g69(.A1(new_n94), .A2(new_n56), .B(pi29), .C(new_n87), .Y(new_n113));
  AOI22x1_ASAP7_75t_R  g70(.A1(new_n109), .A2(new_n111), .B1(new_n112), .B2(new_n113), .Y(new_n114));
  AND4x2_ASAP7_75t_R   g71(.A(new_n114), .B(new_n108), .C(new_n103), .D(new_n100), .Y(new_n115));
  INVx1_ASAP7_75t_R    g72(.A(new_n115), .Y(new_n116));
  OA21x2_ASAP7_75t_R   g73(.A1(pi27), .A2(new_n96), .B(new_n115), .Y(new_n117));
  INVx1_ASAP7_75t_R    g74(.A(new_n117), .Y(po2));
  OAI21x1_ASAP7_75t_R  g75(.A1(new_n67), .A2(new_n117), .B(new_n99), .Y(new_n119));
  AOI21x1_ASAP7_75t_R  g76(.A1(pi33), .A2(po2), .B(new_n105), .Y(new_n120));
  AO21x1_ASAP7_75t_R   g77(.A1(po2), .A2(pi33), .B(new_n105), .Y(new_n121));
  OA21x2_ASAP7_75t_R   g78(.A1(new_n117), .A2(new_n66), .B(new_n98), .Y(new_n122));
  OA21x2_ASAP7_75t_R   g79(.A1(new_n117), .A2(new_n65), .B(new_n102), .Y(new_n123));
  OAI21x1_ASAP7_75t_R  g80(.A1(new_n65), .A2(new_n117), .B(new_n102), .Y(new_n124));
  AOI21x1_ASAP7_75t_R  g81(.A1(pi31), .A2(po2), .B(new_n107), .Y(new_n125));
  OR4x2_ASAP7_75t_R    g82(.A(new_n120), .B(new_n122), .C(new_n123), .D(new_n125), .Y(po4));
  OAI21x1_ASAP7_75t_R  g83(.A1(new_n64), .A2(new_n117), .B(new_n101), .Y(new_n127));
  AO221x2_ASAP7_75t_R  g84(.A1(pi20), .A2(po1), .B1(pi29), .B2(po2), .C(new_n87), .Y(new_n128));
  NAND2x1_ASAP7_75t_R  g85(.A(new_n127), .B(new_n128), .Y(new_n129));
  OA211x2_ASAP7_75t_R  g86(.A1(new_n117), .A2(new_n63), .B(new_n89), .C(new_n109), .Y(new_n130));
  NAND2x1_ASAP7_75t_R  g87(.A(pi27), .B(new_n116), .Y(new_n131));
  AO21x1_ASAP7_75t_R   g88(.A1(new_n97), .A2(new_n131), .B(new_n130), .Y(new_n132));
  OA31x2_ASAP7_75t_R   g89(.A1(new_n132), .A2(po4), .A3(new_n129), .B1(new_n119), .Y(po3));
  AOI211x1_ASAP7_75t_R g90(.A1(new_n128), .A2(new_n127), .B(new_n125), .C(new_n123), .Y(new_n134));
  OR3x1_ASAP7_75t_R    g91(.A(new_n134), .B(new_n122), .C(new_n120), .Y(po5));
  OAI21x1_ASAP7_75t_R  g92(.A1(new_n125), .A2(new_n127), .B(new_n124), .Y(new_n136));
  AO21x1_ASAP7_75t_R   g93(.A1(new_n128), .A2(new_n130), .B(new_n136), .Y(new_n137));
  AO21x1_ASAP7_75t_R   g94(.A1(new_n137), .A2(new_n121), .B(new_n122), .Y(po6));
endmodule


